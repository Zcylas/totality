# Changed files (task-owned only)

## New files

- `src/main/java/zcylas/totality/api/rpg/classes/ClassChangeReconciler.java` — the universal
  post-class-mutation reconciliation seam. Resource/spell-slot-agnostic; calls
  `ResourceGrantReconciliation.reconcileAndSync`, a defensive scalar-maximum clamp sweep, and
  `SpellSlotRecalculator.recalculate`, in that order.
- `src/main/java/zcylas/totality/api/rpg/resources/integration/ResourceGrantReconciliation.java` — the
  one shared "reconcile every registered `ResourceGrantProvider`, then mark changes dirty" facade,
  factored out of the near-identical private wiring `PlayerBaselineResources` and
  `BarbarianRageResources` each used to duplicate.

## Modified files (production)

- `src/main/java/zcylas/totality/api/rpg/resources/integration/PlayerBaselineResources.java` — `reconcile`
  now delegates to `ResourceGrantReconciliation.reconcileAndSync` instead of constructing its own
  `ResourceGrantReconciler`. Behavior-preserving (pure dedup).
- `src/main/java/zcylas/totality/api/rpg/resources/integration/BarbarianRageResources.java` — same dedup;
  also corrected a stale Javadoc claim that `REMOVE_STATE` was "never actually exercised" (it now is,
  via the new seam).
- `src/main/java/zcylas/totality/networking/classes/SelectClassHandler.java` — replaced the standalone
  `SpellSlotRecalculator.recalculate` call and the Barbarian-only `BarbarianRageAbility.registerChargePool`
  call with one unconditional `ClassChangeReconciler.reconcile(player)`. The (unrelated) ability-unlock
  lines under the Barbarian-only branch are untouched.
- `src/main/java/zcylas/totality/networking/classes/AddClassLevelHandler.java` — replaced the standalone
  `SpellSlotRecalculator.recalculate` call (after `ClassLevelUpRegistry.fire`) with
  `ClassChangeReconciler.reconcile(player)`.
- `src/main/java/zcylas/totality/networking/classes/SelectSubclassHandler.java` — added
  `ClassChangeReconciler.reconcile(player)` after a successful subclass application (previously ran no
  reconciliation of any kind).
- `src/main/java/zcylas/totality/init/TotalityCommands.java` — **mixed-hunks file, see
  `REVIEW_BASELINE.md`.** This task's only contribution: one import + one
  `ClassChangeReconciler.reconcile(player);` call inside the `showclass` command block, immediately
  after `ClassComponents.get(player).resetClass()`. This is the fix for the reported crash.
- `src/main/java/zcylas/totality/networking/resource/ResourceSyncManager.java` — `queryOutcome`'s
  `ScalarOutcome` construction now catches `IllegalArgumentException` from
  `ResourceScalarWireSnapshot.from` and rethrows an `IllegalStateException` carrying the resource id and
  player identity, cause preserved. Diagnostic-only; nothing is swallowed or normalized.
- `src/main/java/zcylas/totality/api/rpg/resources/verification/BarbarianRageMigrationVerification.java` —
  five new dev-server-gated self-test checks reproducing the exact discovered bug end-to-end against a
  real `ServerPlayer`.

## Modified files (tests)

- `src/test/java/zcylas/totality/api/rpg/resources/integration/ResourceGrantReconcilerTest.java` — one
  new test: `reacquiringAClassOwnedGrantAtALowerResolvedMaximumSeedsFreshValidStateNotAStaleHighValue`.
- `src/test/java/zcylas/totality/api/rpg/resources/PlayerResourceServiceMaximumResolutionTest.java` — one
  new test: `maximumDecreaseWithClampCurrentLeavesStateSafeToSerializeOntoTheWire`.
