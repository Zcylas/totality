# Review summary

## What this task fixed

A Barbarian's `totality:rage` Generic Resource state could survive `/totality showclass` losing the
Barbarian class entirely, then get silently reactivated — at its old, stale `current` value — against a
freshly resolved (and possibly much lower) maximum when Barbarian was later re-acquired. The stale
current-above-maximum state crashed `ResourceScalarWireSnapshot`'s own
`currentUnits <= maximumUnits + overflowUnits` invariant the next time it was synced to the client.

Root cause: `showclass`'s `PlayerClassComponent.resetClass()` call had zero accompanying
reconciliation — nothing ever told the Generic Resource system "this player's class ownership just
changed, re-evaluate every grant."

## What this task did NOT do

- No Rage-specific "if Barbarian, clean up Rage" logic was added anywhere. The fix is one universal,
  class-agnostic reconciliation seam (`ClassChangeReconciler`) that re-evaluates every registered
  `ResourceGrantProvider` generically. In fact, the one piece of Rage-specific logic that previously
  existed at a class-mutation call site (`SelectClassHandler`'s `if (classId.equals(BARBARIAN_ID))
  BarbarianRageAbility.registerChargePool(...)`) was **removed** as redundant with the universal call.
- No respec system was invented. `resetClass()`/`selectClass()`/`addClassLevel()` are the exact same
  `PlayerClassComponent` mutators that already existed; this task only ensured every caller of them also
  triggers the reconciliation seam.
- `resetall`/`resetstats`/`resetlevel` were not changed — confirmed by reading `TotalityCommands.java`
  that none of them touch `PlayerClassComponent` at all, so class-owned resource grants are unaffected
  by them regardless.
- `showclass`'s user-facing "reset and reopen class selection" behavior is unchanged.
- Phase 6 Spell Slot migration, Ki, Pact Magic, Hit Dice, Food, and the Minecraft version migration were
  not started.

## Isolating this task's diff from pre-existing dirty state

The repository had 109 pre-existing, unrelated dirty paths before this task began (confirmed via
`git_status_short_baseline.txt`). Exactly one of this task's files —
`src/main/java/zcylas/totality/init/TotalityCommands.java` — was already among them. Its pre-existing
portion is isolated in `TotalityCommands.java.pre-existing.diff`; this task's entire contribution to
that file is two lines (see `REVIEW_CHANGED_FILES.md`). Every other file in `REVIEW_GIT_DIFF.patch` is
either newly created by this task or was untouched (clean) before this task began, so its diff in that
patch is entirely this task's own work.

## Test/build evidence

- `./gradlew test` (full suite): **1590 tests, 0 failures, 0 errors.**
- `./gradlew clean build`: **BUILD SUCCESSFUL.**
- `git diff --check`: clean (only benign pre-existing CRLF-normalization warnings).
- Bounded dedicated-server run (`./gradlew runServer`, see `runServer_bounded_verification.log`):
  `[BarbarianRageMigrationVerification] All 18 self-test checks passed.` — 13 pre-existing + 5 new
  checks added by this task, which reproduce the exact discovered bug end-to-end against a real
  `ServerPlayer` and confirm it no longer occurs. The only two failures in the log
  (`ProvisionerEntityBackedSmokeTest`, `OffhandAttackVerification`) are pre-existing and unrelated —
  identical to the ones documented as pre-existing baseline failures in the Phase 5 Rage migration
  report, and neither references any file this task touched.

## Manual test result (2026-09-16): PASS

The original development world that first exposed this bug was already left in an invalid persisted
state (`current > maximum`) from before this fix existed, and crashes immediately on open regardless of
this correction — it is not a valid fixture for testing a preventative fix, and repairing/migrating
already-corrupted saves is explicitly out of scope for this task. That world was not opened, modified,
or otherwise touched. The relevant lifecycle was instead reproduced end-to-end in a fresh, disposable
world: high-level Barbarian with high Rage → class reset/reselection → Wizard → later multiclass back
into a low-level Barbarian → **no crash**, Rage returned with a valid low-level current/maximum rather
than the stale high-level value. This matches the dedicated-server `BarbarianRageMigrationVerification`
regression above and confirms the fix holds in live gameplay for newly executed class-reset/reacquisition
transitions.

## Files in this bundle

See `REVIEW_CHANGED_FILES.md` for the full list and per-file description. See
`TOTALITY_CLASS_CHANGE_RESOURCE_RECONCILIATION_IMPLEMENTATION_REPORT_2026-09-16.md` for the complete
root-cause trace, design rationale, and manual test checklist.
