package zcylas.totality.init;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import zcylas.totality.api.ability.Ability;
import zcylas.totality.api.ability.AbilityComponents;
import zcylas.totality.api.ability.AbilityRegistry;
import zcylas.totality.api.core.component.ComponentProvider;
import zcylas.totality.api.economy.currency.CreditPaymentHelper;
import zcylas.totality.api.economy.currency.CurrencyComponents;
import zcylas.totality.api.rpg.ancestry.AncestryComponents;
import zcylas.totality.api.rpg.ancestry.OriginData;
import zcylas.totality.api.rpg.classes.ClassChangeReconciler;
import zcylas.totality.api.rpg.classes.ClassComponents;
import zcylas.totality.api.rpg.classes.PlayerClassComponent;
import zcylas.totality.networking.notification.SendNotificationPayload;
import zcylas.totality.api.rpg.combat.ProficiencyBonus;
import zcylas.totality.api.rpg.combat.weapon.TotalityWeaponItem;
import zcylas.totality.api.rpg.mana.PlayerManaManager;
import zcylas.totality.api.rpg.rest.RestManager;
import zcylas.totality.api.rpg.skills.core.*;
import zcylas.totality.api.rpg.stamina.PlayerStaminaManager;
import zcylas.totality.api.rpg.stats.AbilityScore;
import zcylas.totality.api.rpg.stats.PlayerStats;
import zcylas.totality.api.rpg.stats.StatAttributeApplier;
import zcylas.totality.api.equipment.EquipmentComponents;
import zcylas.totality.api.rpg.stats.StatsComponents;
import zcylas.totality.networking.ancestry.OpenAncestrySelectionPayload;
import zcylas.totality.networking.classes.OpenClassSelectionPayload;
import zcylas.totality.networking.mana.SyncManaPayload;
import zcylas.totality.networking.stamina.StaminaServerTick;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import zcylas.totality.networking.stats.OpenStatusScreenPayload;

import java.util.Set;

public class TotalityCommands {

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(
                    Commands.literal("totality")
                            .requires(source -> {
                                ServerPlayer p = source.getPlayer();
                                return p != null && source.getServer().getPlayerList().isOp(p.nameAndId());
                            })

                            // ── /totality resetskills ─────────────────────────────────
                            .then(Commands.literal("resetskills")
                                    .executes(ctx -> {
                                        ServerPlayer player = ctx.getSource().getPlayerOrException();
                                        var component = SkillsComponents.get(player);
                                        for (Skill skill : Skill.values()) {
                                            SkillData data = component.getSkills().getData(skill);
                                            data.setLevelDirectly(10);
                                            data.setXpDirectly(0);
                                        }
                                        component.sync();
                                        AncestryComponents.get(player).reapplyBonuses();
                                        ctx.getSource().sendSuccess(() ->
                                                Component.literal("All skills reset to level 10."), false);
                                        return 1;
                                    })
                            )

                            // ── /totality resetstats ──────────────────────────────────
                            .then(Commands.literal("resetstats")
                                    .executes(ctx -> {
                                        ServerPlayer player = ctx.getSource().getPlayerOrException();
                                        PlayerStats stats = StatsComponents.getStats(player);

                                        // Reset all ability scores and level
                                        stats.setLevelDirectly(1);
                                        stats.setCharacterXpDirectly(0);
                                        stats.setUnspentAttributePointsDirectly(0);
                                        stats.clearOriginBonus();
                                        stats.clearClassBonus();
                                        stats.clearItemBonus();
                                        for (AbilityScore score : AbilityScore.values()) {
                                            stats.setSpentPointsDirectly(score, 0);
                                        }
                                        stats.recalculate();

                                        // Reapply attribute modifiers (CON → HP etc.)
                                        StatAttributeApplier.apply(player);
                                        StatsComponents.get(player).sync();

                                        // Clamp stamina to new max (END reset → lower max stamina)
                                        int newMaxStamina = PlayerStaminaManager.getMaxStamina(player);
                                        PlayerStaminaManager.setStamina(player, newMaxStamina);
                                        StaminaServerTick.syncStamina(player);

                                        // Clamp mana to new max (INT reset → lower max mana)
                                        int newMaxMana = PlayerManaManager.getMaxMana(player);
                                        PlayerManaManager.setMana(player, newMaxMana);
                                        ServerPlayNetworking.send(player, new SyncManaPayload(
                                                PlayerManaManager.getMana(player),
                                                newMaxMana));

                                        // Clamp HP to new max (CON reset → lower max HP)
                                        player.setHealth(player.getMaxHealth());

                                        ctx.getSource().sendSuccess(() ->
                                                Component.literal("Character stats reset to defaults."), false);
                                        return 1;
                                    })
                            )


                            // ── /totality resetlevel ──────────────────────────────────
                            .then(Commands.literal("resetlevel")
                                    .executes(ctx -> {
                                        ServerPlayer player = ctx.getSource().getPlayerOrException();
                                        PlayerStats stats = StatsComponents.getStats(player);
                                        stats.setLevelDirectly(1);
                                        stats.setCharacterXpDirectly(0);
                                        stats.setUnspentAttributePointsDirectly(0);
                                        StatsComponents.get(player).sync();
                                        ctx.getSource().sendSuccess(() ->
                                                Component.literal("Character level reset to 1."), false);
                                        return 1;
                                    })
                            )

                            // ── /totality addskillxp <skill> <amount> ─────────────────
                            .then(Commands.literal("addskillxp")
                                    .then(Commands.argument("skill", StringArgumentType.word())
                                            .then(Commands.argument("amount", IntegerArgumentType.integer(1))
                                                    .executes(ctx -> {
                                                        ServerPlayer player = ctx.getSource().getPlayerOrException();
                                                        String skillName = StringArgumentType.getString(ctx, "skill")
                                                                .toUpperCase();
                                                        int amount = IntegerArgumentType.getInteger(ctx, "amount");
                                                        try {
                                                            Skill skill = Skill.valueOf(skillName);
                                                            SkillsComponents.get(player).addSkillXp(skill, amount);
                                                            ctx.getSource().sendSuccess(() ->
                                                                    Component.literal("Added " + amount + " XP to " +
                                                                            skill.getDisplayName() + "."), false);
                                                        } catch (IllegalArgumentException e) {
                                                            ctx.getSource().sendFailure(
                                                                    Component.literal("Unknown skill: " + skillName));
                                                        }
                                                        return 1;
                                                    })
                                            )
                                    )
                            )
                            // ── /totality showracemenu ────────────────────────────────────
                            // Replace showracemenu:
                            .then(Commands.literal("showancestry")
                                    .executes(ctx -> {
                                        ServerPlayer player = ctx.getSource().getPlayerOrException();

                                        // Only forget abilities from the previous origin
                                        var ancestryComp = AncestryComponents.get(player);
                                        OriginData previousOrigin = ancestryComp.getOriginData();
                                        if (previousOrigin != null && !previousOrigin.getStartingAbilities().isEmpty()) {
                                            var abilityComp = AbilityComponents.ABILITIES.get((ComponentProvider) player);
                                            for (Identifier id : previousOrigin.getStartingAbilities()) {
                                                abilityComp.forget(id);
                                            }
                                        }

                                        // Then clear ancestry
                                        ancestryComp.clearAncestry();

                                        ServerPlayNetworking.send(player, new OpenAncestrySelectionPayload());
                                        ctx.getSource().sendSuccess(() ->
                                                Component.literal("Ancestry selection reset. Reopening menu..."), false);
                                        return 1;
                                    })
                            )
                            // ── /totality showclass ───────────────────────────────────────
                            .then(Commands.literal("showclass")
                                    .executes(ctx -> {
                                        ServerPlayer player = ctx.getSource().getPlayerOrException();
                                        ClassComponents.get(player).resetClass();
                                        ClassChangeReconciler.reconcile(player);
                                        ServerPlayNetworking.send(player, new OpenClassSelectionPayload());
                                        ctx.getSource().sendSuccess(() ->
                                                Component.literal("Class selection reset. Reopening menu..."), false);
                                        return 1;
                                    })
                            )
                            .then(Commands.literal("ancestry")
                                    .executes(ctx -> {
                                        ServerPlayer player = ctx.getSource().getPlayerOrException();
                                        var comp = AncestryComponents.get(player);
                                        if (!comp.hasAncestry()) {
                                            ctx.getSource().sendSuccess(() ->
                                                    Component.literal("No ancestry selected."), false);
                                            return 0;
                                        }
                                        String originName = comp.getOriginData() != null
                                                ? comp.getOriginData().getDisplayName()
                                                : "None";
                                        ctx.getSource().sendSuccess(() ->
                                                Component.literal("Species: " + comp.getSpeciesData().getDisplayName() +
                                                        " | Origin: " + originName +
                                                        " | Height Scale: " + String.format("%.3f", comp.getHeightScale())), false);
                                        return 1;
                                    })
                            )
                            // ── /totality addcharxp <amount> ──────────────────────────
                            .then(Commands.literal("addcharxp")
                                    .then(Commands.argument("amount", IntegerArgumentType.integer(1))
                                            .executes(ctx -> {
                                                ServerPlayer player = ctx.getSource().getPlayerOrException();
                                                int amount = IntegerArgumentType.getInteger(ctx, "amount");
                                                PlayerStats stats = StatsComponents.getStats(player);
                                                boolean leveledUp = stats.addCharacterXp(amount);
                                                StatsComponents.get(player).sync();
                                                String msg = "Added " + amount + " character XP." +
                                                        (leveledUp ? " Level up! Now level " + stats.getLevel() : "");
                                                ctx.getSource().sendSuccess(() ->
                                                        Component.literal(msg), false);
                                                return 1;
                                            })
                                    )
                            )

                            // ── /totality setstat <score> <value> ─────────────────────
                            .then(Commands.literal("setstat")
                                    .then(Commands.argument("score", StringArgumentType.word())
                                            .then(Commands.argument("value", IntegerArgumentType.integer(1))
                                                    .executes(ctx -> {
                                                        ServerPlayer player = ctx.getSource().getPlayerOrException();
                                                        String scoreName = StringArgumentType.getString(ctx, "score")
                                                                .toUpperCase();
                                                        int value = IntegerArgumentType.getInteger(ctx, "value");
                                                        try {
                                                            AbilityScore score = AbilityScore.valueOf(scoreName);
                                                            // Set as spent points offset from base
                                                            StatsComponents.getStats(player).setSpentPointsDirectly(score, value - PlayerStats.BASE_SCORE);
                                                            StatsComponents.getStats(player).recalculate();
                                                            StatAttributeApplier.apply(player);
                                                            StatsComponents.get(player).sync();
                                                            ctx.getSource().sendSuccess(() ->
                                                                    Component.literal("Set " + score.getDisplayName() +
                                                                            " to " + value + "."), false);
                                                        } catch (IllegalArgumentException e) {
                                                            ctx.getSource().sendFailure(
                                                                    Component.literal("Unknown score: " + scoreName));
                                                        }
                                                        return 1;
                                                    })
                                            )
                                    )
                            )

                            // ── /totality setlevel <level> ────────────────────────────
                            .then(Commands.literal("setlevel")
                                    .then(Commands.argument("level", IntegerArgumentType.integer(1, PlayerStats.MAX_LEVEL))
                                            .executes(ctx -> {
                                                ServerPlayer player = ctx.getSource().getPlayerOrException();
                                                int level = IntegerArgumentType.getInteger(ctx, "level");
                                                int oldLevel = StatsComponents.getStats(player).getLevel();
                                                StatsComponents.getStats(player).setLevelDirectly(level);
                                                StatsComponents.get(player).sync();
                                                // Notify if class points increased
                                                int oldPts = PlayerClassComponent.toClassLevel(oldLevel);
                                                int newPts = PlayerClassComponent.toClassLevel(level);
                                                if (newPts > oldPts) {
                                                    int unspent = newPts - ClassComponents.get(player).getSpentClassPoints();
                                                    if (unspent > 0) {
                                                        SendNotificationPayload.send(player,
                                                                "✦ " + unspent + " Class Point" + (unspent > 1 ? "s" : "") + " available! Press SHIFT+C to spend.",
                                                                0xFFFFD700);
                                                    }
                                                }
                                                ctx.getSource().sendSuccess(() ->
                                                        Component.literal("Set character level to " + level + "."), false);
                                                return 1;
                                            })
                                    )
                            )
                            .then(Commands.literal("stats")
                                    .executes(ctx -> {
                                        ServerPlayer player = ctx.getSource().getPlayerOrException();
                                        ServerPlayNetworking.send(player, new OpenStatusScreenPayload());
                                        return 1;
                                    })
                            )
                            .then(Commands.literal("wallet")
                                    .executes(ctx -> {
                                        ServerPlayer player = ctx.getSource().getPlayerOrException();

                                        var wallet = CurrencyComponents.WALLET
                                                .maybeGet((ComponentProvider) player)
                                                .orElse(null);

                                        if (wallet == null) {
                                            ctx.getSource().sendFailure(
                                                    Component.literal("Wallet component not found on player."));
                                            return 0;
                                        }

                                        long raw = wallet.getValue();
                                        String msg = "Wallet: " + raw + "₵";
                                        ctx.getSource().sendSuccess(() -> Component.literal(msg), false);
                                        return 1;
                                    })
                                    .then(Commands.literal("set")
                                            .then(Commands.argument("amount", IntegerArgumentType.integer(0))
                                                    .executes(ctx -> {
                                                        ServerPlayer player = ctx.getSource().getPlayerOrException();
                                                        int amount = IntegerArgumentType.getInteger(ctx, "amount");

                                                        CurrencyComponents.WALLET
                                                                .get((ComponentProvider) player)
                                                                .setValue(amount);

                                                        String msg = "Wallet set to " + amount + "₵";
                                                        ctx.getSource().sendSuccess(() -> Component.literal(msg), false);
                                                        return 1;
                                                    })
                                            )
                                    )
                            )
                            // ── /totality credits physical|bank give <player> <amount> ────
                            // Targets an arbitrary online player (unlike the self-only `wallet`
                            // commands above) through the canonical economy authorities rather
                            // than re-deriving inventory/balance mutation here: physical Credits
                            // go through CreditPaymentHelper.receivePhysical (the same helper the
                            // Banker's withdraw path uses — item-stack creation, MAX_PER_STACK
                            // splitting, and drop-on-full fallback all stay centralized there),
                            // and banked Credits go through CreditPaymentHelper.receive, which
                            // credits the player's WalletComponent balance (persisted via that
                            // component's own writeData, the same path normal deposits use).
                            .then(Commands.literal("credits")
                                    .then(Commands.literal("physical")
                                            .then(Commands.literal("give")
                                                    .then(Commands.argument("player", EntityArgument.player())
                                                            .then(Commands.argument("amount", IntegerArgumentType.integer(1))
                                                                    .executes(ctx -> {
                                                                        ServerPlayer target = EntityArgument.getPlayer(ctx, "player");
                                                                        long amount = IntegerArgumentType.getInteger(ctx, "amount");
                                                                        CreditPaymentHelper.receivePhysical(target, amount);
                                                                        String msg = "Gave " + amount + "₵ in physical Credits to "
                                                                                + target.getName().getString() + ".";
                                                                        ctx.getSource().sendSuccess(() -> Component.literal(msg), true);
                                                                        return 1;
                                                                    })
                                                            )
                                                    )
                                            )
                                    )
                                    .then(Commands.literal("bank")
                                            .then(Commands.literal("give")
                                                    .then(Commands.argument("player", EntityArgument.player())
                                                            .then(Commands.argument("amount", IntegerArgumentType.integer(1))
                                                                    .executes(ctx -> {
                                                                        ServerPlayer target = EntityArgument.getPlayer(ctx, "player");
                                                                        long amount = IntegerArgumentType.getInteger(ctx, "amount");
                                                                        if (!CreditPaymentHelper.receive(target, amount)) {
                                                                            ctx.getSource().sendFailure(Component.literal(
                                                                                    "Could not credit " + target.getName().getString()
                                                                                            + "'s bank balance (overflow)."));
                                                                            return 0;
                                                                        }
                                                                        String msg = "Gave " + amount + "₵ in banked Credits to "
                                                                                + target.getName().getString() + ".";
                                                                        ctx.getSource().sendSuccess(() -> Component.literal(msg), true);
                                                                        return 1;
                                                                    })
                                                            )
                                                    )
                                            )
                                    )
                            )
                            // ── /totality quest reset [id] ────────────────────────────────
                            .then(Commands.literal("quest")
                                    .then(Commands.literal("reset")
                                            .executes(ctx -> {
                                                ServerPlayer player = ctx.getSource().getPlayerOrException();
                                                zcylas.totality.api.quest.QuestComponents.PROGRESS
                                                        .get((ComponentProvider) player)
                                                        .clear();
                                                ctx.getSource().sendSuccess(() ->
                                                        Component.literal("Cleared all quest progress."), false);
                                                return 1;
                                            })
                                            .then(Commands.argument("id", StringArgumentType.word())
                                                    .executes(ctx -> {
                                                        ServerPlayer player = ctx.getSource().getPlayerOrException();
                                                        String idStr = StringArgumentType.getString(ctx, "id");
                                                        Identifier questId = Identifier.tryParse("totality:" + idStr);
                                                        if (questId == null) {
                                                            ctx.getSource().sendFailure(Component.literal("Invalid quest id: " + idStr));
                                                            return 0;
                                                        }
                                                        zcylas.totality.api.quest.QuestComponents.PROGRESS
                                                                .get((ComponentProvider) player)
                                                                .remove(questId);
                                                        ctx.getSource().sendSuccess(() ->
                                                                Component.literal("Cleared progress for " + questId), false);
                                                        return 1;
                                                    })
                                            )
                                    )
                            )
                            // ── /totality phone reset ─────────────────────────────────────
                            .then(Commands.literal("phone")
                                    .then(Commands.literal("reset")
                                            .executes(ctx -> {
                                                ServerPlayer player = ctx.getSource().getPlayerOrException();
                                                var equipment = EquipmentComponents.get(player);
                                                ItemStack equipped = equipment.getItem(
                                                        zcylas.totality.api.equipment.PlayerEquipmentComponent.IDX_PHONE);
                                                if (!equipped.isEmpty()) {
                                                    equipped.remove(zcylas.totality.api.item.TotalityItemComponents.PHONE_SETUP_COMPLETE);
                                                    equipment.setItem(
                                                            zcylas.totality.api.equipment.PlayerEquipmentComponent.IDX_PHONE,
                                                            ItemStack.EMPTY);
                                                    if (!player.getInventory().add(equipped)) {
                                                        player.drop(equipped, false);
                                                    }
                                                    equipment.sync();
                                                }
                                                for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
                                                    ItemStack stack = player.getInventory().getItem(i);
                                                    if (stack.getItem() instanceof zcylas.totality.item.energy.PhoneItem) {
                                                        stack.remove(zcylas.totality.api.item.TotalityItemComponents.PHONE_SETUP_COMPLETE);
                                                    }
                                                }
                                                ctx.getSource().sendSuccess(() ->
                                                        Component.literal("Reset phone setup and unequipped phone."), false);
                                                return 1;
                                            })
                                    )
                            )
                            // ── /totality reset quest <id> — full reset (progress + declared flags) ──
                            .then(Commands.literal("reset")
                                    .then(Commands.literal("quest")
                                            .then(Commands.argument("id", StringArgumentType.word())
                                                    .executes(ctx -> {
                                                        ServerPlayer player = ctx.getSource().getPlayerOrException();
                                                        String idStr = StringArgumentType.getString(ctx, "id");
                                                        Identifier questId = Identifier.tryParse("totality:" + idStr);
                                                        if (questId == null) {
                                                            ctx.getSource().sendFailure(Component.literal("Invalid quest id: " + idStr));
                                                            return 0;
                                                        }
                                                        zcylas.totality.api.quest.QuestManager.fullReset(player, questId);
                                                        ctx.getSource().sendSuccess(() ->
                                                                Component.literal("Fully reset " + questId + " (progress + its own flags)."), false);
                                                        return 1;
                                                    })
                                            )
                                    )
                            )
                            // ── /totality unlockability <id> ──────────────────────────────
                            .then(Commands.literal("unlockability")
                                    .then(Commands.argument("id", StringArgumentType.word())
                                            .executes(ctx -> {
                                                ServerPlayer player = ctx.getSource().getPlayerOrException();
                                                String idStr = StringArgumentType.getString(ctx, "id");
                                                Identifier abilityId = Identifier.tryParse("totality:" + idStr);
                                                if (abilityId == null) {
                                                    ctx.getSource().sendFailure(Component.literal("Invalid ability id: " + idStr));
                                                    return 0;
                                                }
                                                zcylas.totality.api.ability.AbilityComponent comp =
                                                        zcylas.totality.api.ability.AbilityComponents.ABILITIES.get(
                                                                (ComponentProvider) player);
                                                comp.unlock(abilityId);
                                                ctx.getSource().sendSuccess(() ->
                                                        Component.literal("Unlocked ability: " + abilityId), false);
                                                return 1;
                                            })
                                    )
                            )

// ── /totality forgetability <id> ──────────────────────────────
                            .then(Commands.literal("forgetability")
                                    .then(Commands.argument("id", StringArgumentType.word())
                                            .executes(ctx -> {
                                                ServerPlayer player = ctx.getSource().getPlayerOrException();
                                                String idStr = StringArgumentType.getString(ctx, "id");
                                                Identifier abilityId = Identifier.tryParse("totality:" + idStr);
                                                if (abilityId == null) {
                                                    ctx.getSource().sendFailure(Component.literal("Invalid ability id: " + idStr));
                                                    return 0;
                                                }
                                                zcylas.totality.api.ability.AbilityComponent comp =
                                                        zcylas.totality.api.ability.AbilityComponents.ABILITIES.get(
                                                                (ComponentProvider) player);
                                                comp.forget(abilityId);
                                                ctx.getSource().sendSuccess(() ->
                                                        Component.literal("Forgot ability: " + abilityId), false);
                                                return 1;
                                            })
                                    )
                            )
                            // ── /totality addmasterypoint <amount> ───────────────────────
                            .then(Commands.literal("addmasterypoint")
                                    .then(Commands.argument("amount", IntegerArgumentType.integer(1))
                                            .executes(ctx -> {
                                                ServerPlayer player = ctx.getSource().getPlayerOrException();
                                                int amount = IntegerArgumentType.getInteger(ctx, "amount");
                                                var masteryComp = MasteriesComponents.get(player);
                                                masteryComp.getMasteries().addMasteryPoints(amount);
                                                masteryComp.sync();
                                                ctx.getSource().sendSuccess(() ->
                                                        Component.literal("Added " + amount + " mastery points."), false);
                                                return 1;
                                            })
                                    )
                            )

// ── /totality resetmasterypoints ─────────────────────────────
                            .then(Commands.literal("resetmasterypoints")
                                    .executes(ctx -> {
                                        ServerPlayer player = ctx.getSource().getPlayerOrException();
                                        var masteryComp = MasteriesComponents.get(player);
                                        masteryComp.getMasteries().setMasteryPointsDirectly(0);
                                        masteryComp.sync();
                                        ctx.getSource().sendSuccess(() ->
                                                Component.literal("Mastery points reset to 0."), false);
                                        return 1;
                                    })
                            )

// ── /totality learnmastery <id> ──────────────────────────────
                            .then(Commands.literal("learnmastery")
                                    .then(Commands.argument("id", StringArgumentType.word())
                                            .executes(ctx -> {
                                                ServerPlayer player = ctx.getSource().getPlayerOrException();
                                                String masteryId = StringArgumentType.getString(ctx, "id");
                                                var masteryComp = MasteriesComponents.get(player);

                                                // Find the mastery across all skills
                                                Mastery mastery = null;
                                                for (Skill skill : Skill.values()) {
                                                    var found = MasteryRegistry.get(skill, masteryId);
                                                    if (found.isPresent()) { mastery = found.get(); break; }
                                                }
                                                if (mastery == null) {
                                                    ctx.getSource().sendFailure(Component.literal("Unknown mastery: " + masteryId));
                                                    return 0;
                                                }

                                                // Unlock all ranks directly
                                                for (int rank = 1; rank <= mastery.getRankCount(); rank++) {
                                                    masteryComp.getMasteries().setRankDirectly(masteryId, rank);
                                                }
                                                masteryComp.sync();

                                                // Unlock associated ability if any
                                                if (mastery.getAbilityId() != null) {
                                                    Identifier abilityId = Identifier.tryParse(mastery.getAbilityId());
                                                    if (abilityId != null) {
                                                        zcylas.totality.api.ability.AbilityComponents.ABILITIES.get(
                                                                (ComponentProvider) player).unlock(abilityId);
                                                    }
                                                }

                                                ctx.getSource().sendSuccess(() ->
                                                        Component.literal("Learned mastery: " + masteryId), false);
                                                return 1;
                                            })
                                    )
                            )

// ── /totality forgetmastery <id> ─────────────────────────────
                            .then(Commands.literal("forgetmastery")
                                    .then(Commands.argument("id", StringArgumentType.word())
                                            .executes(ctx -> {
                                                ServerPlayer player = ctx.getSource().getPlayerOrException();
                                                String masteryId = StringArgumentType.getString(ctx, "id");
                                                var masteryComp = MasteriesComponents.get(player);
                                                masteryComp.getMasteries().setRankDirectly(masteryId, 0);
                                                masteryComp.sync();

                                                // Also forget associated ability if any
                                                Mastery mastery = null;
                                                for (Skill skill : Skill.values()) {
                                                    var found = MasteryRegistry.get(skill, masteryId);
                                                    if (found.isPresent()) { mastery = found.get(); break; }
                                                }
                                                if (mastery != null && mastery.getAbilityId() != null) {
                                                    Identifier abilityId = Identifier.tryParse(mastery.getAbilityId());
                                                    if (abilityId != null) {
                                                        zcylas.totality.api.ability.AbilityComponents.ABILITIES.get(
                                                                (ComponentProvider) player).forget(abilityId);
                                                    }
                                                }

                                                ctx.getSource().sendSuccess(() ->
                                                        Component.literal("Forgot mastery: " + masteryId), false);
                                                return 1;
                                            })
                                    )
                            )
                            // ── /totality resetall ────────────────────────────────────────
                            .then(Commands.literal("resetall")
                                            .executes(ctx -> {
                                                ServerPlayer player = ctx.getSource().getPlayerOrException();

                                                // Reset character stats
                                                PlayerStats stats = StatsComponents.getStats(player);
                                                stats.setLevelDirectly(1);
                                                stats.setCharacterXpDirectly(0);
                                                stats.setUnspentAttributePointsDirectly(0);
                                                stats.clearOriginBonus();
                                                stats.clearClassBonus();
                                                stats.clearItemBonus();
// Reset spent points
                                                for (AbilityScore score : AbilityScore.values()) {
                                                    stats.setSpentPointsDirectly(score, 0);
                                                }
                                                stats.recalculate();
                                                StatAttributeApplier.apply(player);
                                                StatsComponents.get(player).sync();

                                                // Reset all skills
                                                var skillsComp = SkillsComponents.get(player);
                                                for (Skill skill : Skill.values()) {
                                                    SkillData data = skillsComp.getSkills().getData(skill);
                                                    data.setLevelDirectly(10);
                                                    data.setXpDirectly(0);
                                                }
                                                skillsComp.sync();
                                                AncestryComponents.get(player).reapplyBonuses();

                                                // Reset all masteries and mastery points
                                                var masteryComp = MasteriesComponents.get(player);
                                                for (Skill skill : Skill.values()) {
                                                    for (Mastery mastery : MasteryRegistry.getMasteries(skill)) {
                                                        masteryComp.getMasteries().setRankDirectly(mastery.getId(), 0);
                                                    }
                                                }
                                                masteryComp.getMasteries().setMasteryPointsDirectly(0);
                                                masteryComp.sync();

                                                // Reset all abilities — keep only defaults
                                                var abilityComp = AbilityComponents.ABILITIES.get(
                                                        (ComponentProvider) player);
                                                for (Identifier id : new java.util.HashSet<>(abilityComp.getUnlocked())) {
                                                    Ability ability = AbilityRegistry.get(id);
                                                    if (ability != null && !ability.isDefault()) {
                                                        abilityComp.forget(id);
                                                    }
                                                }

                                                // Reset stamina and mana to new max
                                                int newMaxStamina = PlayerStaminaManager.getMaxStamina(player);
                                                PlayerStaminaManager.setStamina(player, newMaxStamina);
                                                StaminaServerTick.syncStamina(player);

                                                int newMaxMana = PlayerManaManager.getMaxMana(player);
                                                PlayerManaManager.setMana(player, newMaxMana);
                                                ServerPlayNetworking.send(player, new SyncManaPayload(newMaxMana, newMaxMana));

                                                player.setHealth(player.getMaxHealth());

                                                ctx.getSource().sendSuccess(() ->
                                                        Component.literal("All RPG progress reset."), false);
                                                return 1;
                                            })
                            )
                            // ── /totality damage <type> <amount> ─────────────────────────
                            .then(Commands.literal("damage")
                                    .then(Commands.argument("type", StringArgumentType.word())
                                            .then(Commands.argument("amount", com.mojang.brigadier.arguments.FloatArgumentType.floatArg(0))
                                                    .executes(ctx -> {
                                                        ServerPlayer player = ctx.getSource().getPlayerOrException();
                                                        String typeStr = StringArgumentType.getString(ctx, "type");
                                                        float amount = com.mojang.brigadier.arguments.FloatArgumentType.getFloat(ctx, "amount");

                                                        zcylas.totality.api.combat.damage.TotalityDamageType type =
                                                                zcylas.totality.api.combat.damage.DamageTypeRegistry.get(
                                                                        Identifier.fromNamespaceAndPath("totality", typeStr));

                                                        if (type == null) {
                                                            ctx.getSource().sendFailure(
                                                                    Component.literal("Unknown damage type: " + typeStr));
                                                            return 0;
                                                        }

                                                        float vanillaAmount = amount / zcylas.totality.api.core.rpgutils.RpgDisplayUtils.HP_DISPLAY_MULTIPLIER;
                                                        zcylas.totality.api.combat.damage.TotalityDamage.hurt(
                                                                player, null, type, vanillaAmount);

                                                        ctx.getSource().sendSuccess(() ->
                                                                Component.literal("Dealt " + amount + " " + typeStr + " damage."), false);
                                                        return 1;
                                                    })
                                            )
                                    )
                            )
                            .then(Commands.literal("shortrest")
                                    .executes(ctx -> {
                                        RestManager.shortRest(ctx.getSource().getPlayerOrException());
                                        ctx.getSource().sendSuccess(() -> Component.literal("Short rest taken."), false);
                                        return 1;
                                    }))
                            .then(Commands.literal("longrest")
                                    .executes(ctx -> {
                                        RestManager.longRest(ctx.getSource().getPlayerOrException());
                                        ctx.getSource().sendSuccess(() -> Component.literal("Long rest taken."), false);
                                        return 1;
                                    })
                            )
                            .then(Commands.literal("inspect")
                                    .executes(ctx -> {
                                        ServerPlayer player = ctx.getSource().getPlayerOrException();
                                        // Find entity player is looking at within 20 blocks
                                        net.minecraft.world.phys.HitResult hit = player.pick(20.0, 0f, false);
                                        net.minecraft.world.entity.Entity target = null;
                                        // Check entity hit (AABB sweep)
                                        net.minecraft.world.phys.Vec3 eye  = player.getEyePosition();
                                        net.minecraft.world.phys.Vec3 look = player.getLookAngle();
                                        net.minecraft.world.phys.Vec3 end  = eye.add(look.scale(20));
                                        var entities = player.level().getEntities(player,
                                                player.getBoundingBox().inflate(20),
                                                e -> e instanceof net.minecraft.world.entity.LivingEntity && e != player);
                                        double best = 20.0;
                                        for (var e : entities) {
                                            net.minecraft.world.phys.AABB box = e.getBoundingBox().inflate(0.3);
                                            var res = box.clip(eye, end);
                                            if (res.isPresent()) {
                                                double d = eye.distanceTo(res.get());
                                                if (d < best) { best = d; target = e; }
                                            }
                                        }
                                        if (target == null) {
                                            ctx.getSource().sendFailure(Component.literal("No mob in sight (up to 20 blocks)."));
                                            return 0;
                                        }
                                        final net.minecraft.world.entity.Entity finalTarget = target;
                                        String name = finalTarget.getDisplayName().getString();
                                        String info;
                                        if (finalTarget instanceof zcylas.totality.api.mob.stats.MobCombatStatsHolder h) {
                                            var s = h.totality$getMobCombatStats();
                                            String rarity = s.getSpawnRarity().name();
                                            info = name + " [" + rarity + "]"
                                                    + " | Lvl " + s.getLevel()
                                                    + " | AC " + s.getAC()
                                                    + " | Atk +" + s.getAttackBonus()
                                                    + " | STR " + s.getStat(zcylas.totality.api.rpg.stats.AbilityScore.STR)
                                                    + " CON " + s.getStat(zcylas.totality.api.rpg.stats.AbilityScore.CON)
                                                    + " DEX " + s.getStat(zcylas.totality.api.rpg.stats.AbilityScore.DEX)
                                                    + " | HP " + Math.round(((net.minecraft.world.entity.LivingEntity)finalTarget).getHealth())
                                                    + "/" + Math.round(((net.minecraft.world.entity.LivingEntity)finalTarget).getMaxHealth());
                                        } else {
                                            info = name + " | HP "
                                                    + Math.round(((net.minecraft.world.entity.LivingEntity)finalTarget).getHealth())
                                                    + "/" + Math.round(((net.minecraft.world.entity.LivingEntity)finalTarget).getMaxHealth())
                                                    + " (no stat block)";
                                        }
                                        ctx.getSource().sendSuccess(() -> Component.literal(info), false);
                                        return 1;
                                    })
                            )
                            // ── /totality savingthrows ────────────────────────────────────
                            .then(Commands.literal("savingthrows")
                                    .executes(ctx -> {
                                        ServerPlayer player = ctx.getSource().getPlayerOrException();
                                        int prof = ProficiencyBonus.forPlayer(player);
                                        Set<AbilityScore> saveProficiencies = ClassComponents.get(player).getSaveProficiencies();
                                        int equipSaveBonus = EquipmentComponents.get(player).getSaveBonus();
                                        PlayerStats stats = StatsComponents.getStats(player);

                                        StringBuilder sb = new StringBuilder("Saving Throws (Prof +" + prof);
                                        if (equipSaveBonus != 0) sb.append(", Equipment +" + equipSaveBonus);
                                        sb.append("):\n");

                                        for (AbilityScore score : AbilityScore.values()) {
                                            int mod = stats.getModifier(score);
                                            boolean hasProficiency = saveProficiencies.contains(score);
                                            int total = mod + (hasProficiency ? prof : 0) + equipSaveBonus;
                                            String sign = total >= 0 ? "+" : "";
                                            String profMark = hasProficiency ? " ✦" : "";
                                            sb.append("  ").append(score.getDisplayName())
                                              .append(profMark).append(": ").append(sign).append(total).append("\n");
                                        }

                                        String msg = sb.toString().trim();
                                        ctx.getSource().sendSuccess(() -> Component.literal(msg), false);
                                        return 1;
                                    })
                            )

                            // ── /totality dialogue ────────────────────────────────────────
                            .then(Commands.literal("dialogue")
                                    .then(Commands.literal("start")
                                            .then(Commands.argument("id", StringArgumentType.greedyString())
                                                    .executes(ctx -> {
                                                        ServerPlayer player = ctx.getSource().getPlayerOrException();
                                                        String idStr = StringArgumentType.getString(ctx, "id");
                                                        Identifier id = Identifier.tryParse(idStr);
                                                        if (id == null) {
                                                            ctx.getSource().sendFailure(Component.literal("Invalid dialogue id: " + idStr));
                                                            return 0;
                                                        }
                                                        zcylas.totality.api.dialogue.DialogueSessionManager.startDialogue(player, id, null);
                                                        ctx.getSource().sendSuccess(() -> Component.literal("Starting dialogue: " + id), false);
                                                        return 1;
                                                    })
                                            )
                                    )
                                    .then(Commands.literal("end")
                                            .executes(ctx -> {
                                                ServerPlayer player = ctx.getSource().getPlayerOrException();
                                                zcylas.totality.api.dialogue.DialogueSessionManager.endDialogue(player);
                                                ctx.getSource().sendSuccess(() -> Component.literal("Dialogue ended."), false);
                                                return 1;
                                            })
                                    )
                                    .then(Commands.literal("flag")
                                            .then(Commands.literal("set")
                                                    .then(Commands.argument("flag", StringArgumentType.word())
                                                            .then(Commands.argument("value", IntegerArgumentType.integer())
                                                                    .executes(ctx -> {
                                                                        ServerPlayer player = ctx.getSource().getPlayerOrException();
                                                                        String flag = StringArgumentType.getString(ctx, "flag");
                                                                        int value = IntegerArgumentType.getInteger(ctx, "value");
                                                                        zcylas.totality.api.dialogue.DialogueComponents.FLAGS.get(
                                                                                (zcylas.totality.api.core.component.ComponentProvider) player
                                                                        ).setFlag(flag, value);
                                                                        ctx.getSource().sendSuccess(() ->
                                                                                Component.literal("Flag " + flag + " = " + value), false);
                                                                        return 1;
                                                                    })
                                                            )
                                                    )
                                            )
                                            .then(Commands.literal("get")
                                                    .then(Commands.argument("flag", StringArgumentType.word())
                                                            .executes(ctx -> {
                                                                ServerPlayer player = ctx.getSource().getPlayerOrException();
                                                                String flag = StringArgumentType.getString(ctx, "flag");
                                                                int value = zcylas.totality.api.dialogue.DialogueComponents.FLAGS.get(
                                                                        (zcylas.totality.api.core.component.ComponentProvider) player
                                                                ).getFlag(flag);
                                                                ctx.getSource().sendSuccess(() ->
                                                                        Component.literal("Flag " + flag + " = " + value), false);
                                                                return 1;
                                                            })
                                                    )
                                            )
                                    )
                            )

                            .executes(ctx -> {
                                ServerPlayer p = ctx.getSource().getPlayerOrException();
                                int prof = ProficiencyBonus.forPlayer(p);
                                Set<AbilityScore> saves = ClassComponents.get(p).getSaveProficiencies();
                                ItemStack held = p.getMainHandItem();
                                boolean weaponProf = !held.isEmpty() && held.getItem() instanceof TotalityWeaponItem w
                                        && w.isProficient(p);
                                ctx.getSource().sendSuccess(() -> Component.literal(
                                        "Proficiency: +" + prof + " | Save profs: " + saves + " | Weapon prof: " + weaponProf
                                ), false);
                                return 1;
                            }));
        });
    }

    private TotalityCommands() {}
}