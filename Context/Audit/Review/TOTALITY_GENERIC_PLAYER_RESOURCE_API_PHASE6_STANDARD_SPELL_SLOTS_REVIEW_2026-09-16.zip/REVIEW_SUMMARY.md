# Review summary

## What this task did

Migrated `totality:spell_slots` (the ordinary, standard multiclass spell-slot pool) from transitional
`EXTERNAL_ADAPTER` (query-only, mirroring the legacy `SpellSlotComponent` array store) to real
`GENERIC_COMPONENT` authority — the same authority-flip pattern Phase 4 (Mana/Stamina) and Phase 5
(Rage) already established. Also enacted the new canonical decision that **ordinary Standard Spell
Slots are levels 1-9 only** — the pre-existing 10-level table's obsolete level-25/30 tier-10
entitlement is removed entirely, not hidden or converted into anything else.

## Root architecture change

- New `CLASS`-sourced grant provider (`StandardSpellSlotResources`) generalizes the single-class-gated
  pattern Rage established (`BarbarianRageResources`) to "any combination of classes currently
  contributing to the shared multiclass pool" — one shared pool, never per-class independent resources.
- New `ResourceMaximumResolver` (`StandardSpellSlotMaximumResolver`) delegates to the single existing
  multiclass formula (`SpellSlotTable`/`SpellSlotRecalculator`) — no second maximum table was created
  anywhere.
- `ResourceGrantReconciler` gained `PARTITIONED_POOL` grant-instantiation support (`AtMaximum` only) —
  it was scalar-only before this task. This is generic infrastructure the Standard Spell Slot
  migration needed, proven independently with a synthetic (non-spell-slot) resource id in
  `ResourceGrantReconcilerTest`, not hardcoded to spell slots.
- `ActivateAbilityHandler`'s cast pre-check/post-success-spend now goes through
  `PlayerResourceService.query`/`trySpend` (`EXACT_TIER`) instead of the legacy component's
  `hasSlot`/`useSlot` — the successful-cast-only control-flow ordering is byte-for-byte unchanged,
  confirmed by direct before/after code comparison.
- `ClassChangeReconciler` needed no new parallel recalculation hook: the existing grant-reconciliation
  step (step 1) already transitively covers Standard Spell Slots once the grant provider shares the
  same registry, exactly like Rage. The old explicit `SpellSlotRecalculator.recalculate` call — in
  `ClassChangeReconciler` and in `PlayerConnectionEvents`'s JOIN handler — was removed as redundant,
  directly satisfying the task's "one authoritative sequence only" requirement.
- One-time legacy-NBT migration reuses the exact `isLegacyMigrated`/`markLegacyMigrated` marker Mana/
  Stamina/Rage already established — no new migration framework was invented. Gated on the player's
  *current* combined caster level (not a legacy-store flag, since none exists) to avoid the exact
  "stale 0/0 pre-empts a future genuine grant" bug shape this precaution exists for.

## Tier-10 removal — explicit, not incidental

Every "10" occurrence across the progression tables, the legacy component, the adapter, the client
cache, the parity comparator, and every test file that assumed 10 partitions was traced to its actual
meaning before touching it (see the implementation report's §6 table). Two occurrences were
deliberately left untouched as genuinely unrelated: `GrimoireScreen.currentSpellSlot` (a rune-crafting
UI slot, unrelated naming coincidence) and `CrownOfStarsSpell`'s 7th-level spell content / ritual-cast
timing (legitimate, unrelated numeric literals). No global "replace every 10" was performed.

## What this task did NOT do

- Did not implement Pact Magic, Ki, Hit Dice, or Epic Magic.
- Did not invent a replacement reward for the removed level-25/30 tier-10 milestones.
- Did not give Warlock any Standard Spell Slot contribution — confirmed already-correct pre-migration
  (Warlock was already excluded from the pooling formula) and re-verified against the real production
  code after migration, via both a unit test and a real-`ServerPlayer` dev-server check.
- Did not redesign the Spell Radial, Class/Character UI, or spell progression beyond removing the
  obsolete tier 10 — `SpellRadialScreen` required zero code changes (it already read through the
  Generic-preferred `ClientResourcePresentationResolver`).
- Did not touch Food, the Minecraft 26.3 migration, the pre-existing `ProvisionerEntityBackedSmokeTest`/
  `OffhandAttackVerification` failures, or the previously-corrupted old test world.

## Isolating this task's diff

None of this task's 34 files (27 from the original Phase 6 pass, +1 canonical doc from the four-finding
correction pass, +6 from the level-up-regression correction pass — 2 new test files and 4 production
files newly touched: `MaximumChangePolicy.java`, `PlayerResourceService.java`, `ResourceGrantPolicy.java`,
`AddClassLevelHandler.java`) were among the repository's 109/139/145 pre-existing dirty paths — every
modified file in `REVIEW_GIT_DIFF.patch` was clean before this task began, so its diff is entirely this
task's own work; every brand-new file is included in full under `src/` in this bundle instead (`git
diff` cannot show the creation content of an untracked file). The final cleanup pass added zero new
files — it only touched 4 files already in this set (`ClassChangeReconciler.java`,
`MaximumChangePolicyTest.java`, `ClassChangeReconcilerMaximumSyncSourceRegressionTest.java`,
`StandardSpellSlotMigrationVerification.java`), so the 34-file total is unchanged. No mixed-hunk
isolation was required (unlike the prior "class-change reconciliation" task).

## Correction pass (2026-09-16) — four review findings, applied to the same uncommitted work

1. **Finding 1 (join-time class-level mutation bypassing `ClassChangeReconciler`) — CONFIRMED, FIXED.**
   `PlayerConnectionEvents`'s JOIN handler could lower a class's stored level (e.g. after
   `/totality resetlevel`) *after* `BaselineResourceLifecycleEvents`' own JOIN handler had already
   reconciled class-owned Generic Resource grants at the old, higher level — the same `current >
   maximum` lifecycle bug shape as the original stale-Rage bug, reachable through a path that
   predates `ClassChangeReconciler`. Fixed by calling `ClassChangeReconciler.reconcile(player)`
   immediately after the mutation. Universal (Rage benefits automatically today; any future
   class-owned grant provider benefits automatically too). A stale, now-disproven Javadoc claim in
   `ClassChangeReconciler` ("no current production table can decrease this way") was corrected.
2. **Finding 2 (canonical Resource API doc stale) — CONFIRMED, CORRECTED.** Every Standard-Spell-Slot
   "1..10" statement in `TOTALITY_GENERIC_PLAYER_RESOURCE_API.md` corrected to "1..9". The generic
   "partition id 10 survives persistence" infrastructure statement was clarified, not deleted, per
   explicit instruction — it describes generic `PARTITIONED_POOL` capability (e.g. Hit Dice's `d10`),
   never Standard Spell Slots.
3. **Finding 3 (old tier-10 save test precision) — OVERSTATEMENT CONFIRMED AND CORRECTED.** The
   original dev-server migration check claimed to prove "discards legacy tier 10 entirely," but its
   code used the current `SpellSlotComponent` API, which (post-Phase-6) cannot represent a tier-10
   value at all — the check's tier-10 assertion passed vacuously. Corrected the check's own
   label/comment, and added a true raw-NBT unit test
   (`SpellSlotComponentTest#readDataIgnoresHistoricalTierTenKeysFromAGenuinelyOldPreMigrationSave`)
   that hand-builds the historical `max_9`/`used_9` keys and proves the real `readData` never reads
   them into any array slot.
4. **Finding 4 (no-effect cast coverage) — OVERSTATEMENT CONFIRMED AND CORRECTED, OPTION A
   IMPLEMENTED.** The original "no-effect" check never called the real `ActivateAbilityHandler` at
   all (it just checked that doing nothing changes nothing). `ActivateAbilityHandler.handle` was made
   `public` and two small dev-only synthetic spells were added, proving through the real production
   entry point that a `markNoEffect()` cast spends nothing while a normal successful cast does.

A genuine self-inflicted test-isolation bug in the new Finding 4 checks (one legitimately spends a
real slot from a shared test player, shifting a later pre-existing check's hardcoded expectation) was
caught by actually running the dedicated server — not assumed — and fixed before this bundle was
finalized.

## Level-up regression correction pass (2026-09-16) — found during the user's own manual gameplay testing

Reported: leveling a Wizard from class level 12 to 13 (unlocking a 7th-level Standard Spell Slot) did
not show the new slot at all until reconnect, and it then showed `0/1` until a Long Rest. **Root cause,
confirmed by direct source read (two bugs, one root cause):** `ResourceGrantReconciler.reconcile`
deliberately never refills an already-granted resource, and `ClassChangeReconciler`'s only other step
was a clamp-down-only safety net with no symmetric handling for a *growing* maximum — so (A) a
still-granted resource's `current` never gained newly available capacity on level-up, and (B) since
`current` never changed, nothing ever called `ResourceSyncManager.markDirty`, so the client was never
told about the new maximum either (a reconnect "self-heals" only because JOIN always forces a full
snapshot regardless of dirty state). Prior art found during investigation:
`BarbarianRageAbility.updateChargePool` already solves half of this identical bug class for Rage (the
sync half only — Rage's own design deliberately never auto-grants on level-up) via a bespoke per-class
`ClassLevelUpRegistry` wire; Standard Spell Slots never got an equivalent wire-up when Phase 6 migrated
it. **Fix:** a new opt-in `ResourceGrantPolicy.maximumChangePolicy()` field (default `CLAMP_CURRENT`,
matching every existing resource's behavior unchanged); `totality:spell_slots` opts into
`MaximumChangePolicy.PRESERVE_DEFICIT`; `ClassChangeReconciler` gained `captureResolvedMaximums(player)`
(called by a caller *before* its mutation) and a `reconcile(player, before)` overload that applies each
resource's declared policy using a genuine "before" snapshot, degenerating safely to the old clamp-only
behavior when no snapshot is supplied (every pre-existing call site needed zero changes). Only
`AddClassLevelHandler` — the one call site that actually reproduces the bug — was updated to capture
"before" and use the new overload. Full detail, the four required numeric examples (all verified both
as a pure formula and through the real production pipeline), and the immediate-sync guarantee: see the
implementation report's §22.

## Final cleanup pass (2026-09-16) — performed after the level-up fix was manually confirmed live

The user manually retested the §22 reproduction after its fix and confirmed the newly unlocked
7th-level slot now appears immediately as `1/1` on Wizard 12→13, with no reconnect and no Long Rest —
the working level-up behavior was **not** redesigned or touched by this pass. Two small findings from
a final review were investigated against the actual current code (not assumed) and both confirmed:

1. **Finding 1 (partitioned maximum-only sync edge) — CONFIRMED, FIXED.** `ClassChangeReconciler
   .reconcilePartitioned` computes a per-partition `delta` and simply `continue`s when `delta == 0` —
   but a partition's resolved **maximum** can genuinely change while its reconciled **current** lands
   back on the exact same value (e.g. an already-empty partition whose maximum shrinks further still
   floor-clamps to 0, or any `CLAMP_CURRENT` partition already below both the old and new maximum).
   Since the only thing that ever marks a partitioned resource dirty is a successful `drain`/`restore`
   call, and neither ever ran in that shape, **nothing** told the client the maximum had changed — the
   same sync-half of the §22 bug, for a case §22's fix did not cover. Fixed by tracking `mutated` and
   `maximumChanged` across the per-partition loop and adding `if (maximumChanged && !mutated) {
   ResourceSyncManager.markDirty(player.getUUID(), resourceId); }` after it — generic (no
   Standard-Spell-Slot-specific branch), and only fires when a genuine captured "before" snapshot shows
   a real maximum change with no accompanying mutation, never unconditionally.
2. **Finding 2 (stale Javadoc) — CONFIRMED, CORRECTED.** `ClassChangeReconciler`'s class-level Javadoc
   still `@link`ed the retired `clampResourcesAboveResolvedMaximum` method (removed by the §22 pass);
   corrected to reference `reconcileResourcesAgainstResolvedMaximum` and describe its actual
   bidirectional, policy-driven behavior. Confirmed (by grep) to be the only remaining reference to the
   old name anywhere in `src/main/java`.

Full detail, the exact fix, and regression coverage: see the implementation report's §23.

## Test/build evidence

- `./gradlew test` (full suite): **1611 tests, 0 failures, 0 errors** (1595 → 1596 after the
  four-finding correction pass → 1607 after the level-up-regression correction pass → 1611 after the
  final cleanup pass, +4: 2 `MaximumChangePolicyTest` + 2
  `ClassChangeReconcilerMaximumSyncSourceRegressionTest`).
- `./gradlew clean build`: **BUILD SUCCESSFUL** (reconfirmed after all three passes).
- `git diff --check`: clean (only benign pre-existing CRLF-normalization warnings).
- Bounded dedicated-server run, **original Phase 6 pass** (`runServer_bounded_verification_original_phase6.log`):
  `[StandardSpellSlotMigrationVerification] All 14 self-test checks passed.`
- Bounded dedicated-server run, **four-finding correction pass** (`runServer_bounded_verification_correction_pass.log`,
  after fixing the self-inflicted test-isolation bug above): `[StandardSpellSlotMigrationVerification]
  All 18 self-test checks passed.` (+3 Finding 1 checks, +2 Finding 4 checks replacing 1 removed weak
  check = net +4). `[ResourceFoundationVerification] All 6 self-test checks passed.`,
  `[BaselineResourceMigrationVerification] All 11 self-test checks passed.`,
  `[BarbarianRageMigrationVerification] All 18 self-test checks passed.` (unchanged).
- Bounded dedicated-server run, **level-up-regression correction pass**
  (`runServer_bounded_verification_levelup_regression.log`): `[StandardSpellSlotMigrationVerification]
  All 21 self-test checks passed.` (+3 growth-preservation/tier-7-unlock checks).
  `[ResourceFoundationVerification] All 6`, `[BaselineResourceMigrationVerification] All 11`,
  `[BarbarianRageMigrationVerification] All 18` (all still unchanged — confirms Rage is unaffected by
  the new opt-in policy field, since it keeps the `CLAMP_CURRENT` default).
- Bounded dedicated-server run, **final cleanup pass** (`runServer_bounded_verification_final_cleanup.log`):
  **`[StandardSpellSlotMigrationVerification] All 23 self-test checks passed.`** (+2 maximum-only-sync-edge
  checks). `[ResourceFoundationVerification] All 6`, `[BaselineResourceMigrationVerification] All 11`,
  `[BarbarianRageMigrationVerification] All 18` (all still unchanged).
- The same two unrelated, pre-existing verification failures observed in every prior phase's run
  (`ProvisionerEntityBackedSmokeTest` 3/4 FAIL, `OffhandAttackVerification` 3/5 FAIL) appeared again,
  identically, in all four dedicated-server runs.

## Files in this bundle

See `REVIEW_CHANGED_FILES.md` for the full list and per-file description. See
`TOTALITY_GENERIC_PLAYER_RESOURCE_API_PHASE6_STANDARD_SPELL_SLOTS_IMPLEMENTATION_REPORT_2026-09-16.md`
for the complete characterization, design rationale, and manual test checklist.
