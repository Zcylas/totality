# Changed files (task-owned only)

**2026-09-16, three correction/cleanup passes:** this file now covers the original Phase 6
implementation AND three follow-up passes applied to the same still-uncommitted work — see
`REVIEW_SUMMARY.md`'s sections and the implementation report's §21 (four review findings), §22 (a
level-up regression found during the user's own manual gameplay testing), and §23 (a small final
cleanup pass, performed after §22's fix was manually confirmed working live) for the full detail.
Entries below are annotated `[correction pass]`, `[level-up regression]`, or `[final cleanup]` for the
pass that touched them; everything else reflects the original Phase 6 pass unchanged.

## New files

- `src/main/java/zcylas/totality/api/magic/spell/StandardSpellSlotMaximumResolver.java` — the
  `ResourceMaximumResolver` for `totality:spell_slots`, delegating to
  `SpellSlotRecalculator.computeMaxSlots`.
- `src/main/java/zcylas/totality/api/rpg/resources/integration/StandardSpellSlotResources.java` — the
  `CLASS` grant provider (any combined-caster-level > 0), Long Rest restore, registration.
  **[level-up regression]** `register()` now also registers `MaximumChangePolicy.PRESERVE_DEFICIT` for
  `totality:spell_slots` in `ResourceGrantPolicyRegistry` — the explicit per-resource opt-in canonical
  §10.5 requires; class Javadoc updated.
- `src/main/java/zcylas/totality/api/rpg/resources/verification/StandardSpellSlotMigrationVerification.java` —
  dev-server-gated self-test, mirrors `BarbarianRageMigrationVerification`. **[correction pass]** +3
  checks for Finding 1 (join-time class-level decrease clamping, using a dedicated fresh player); the
  old vacuous "no-effect" check replaced with 2 real `ActivateAbilityHandler.handle` checks for Finding
  4; the migration check's label/comment corrected for Finding 3 (no longer overclaims tier-10
  discard); a state-restoring line added so the Finding 4 addition cannot shift the pre-existing
  sequence's hardcoded expectations (a real self-inflicted test-isolation bug caught by actually
  running the dedicated server, then fixed). **[level-up regression]** the pre-existing "leveling the
  Wizard class up..." check corrected — it previously asserted the *bug's* behavior (current unchanged
  across a maximum increase) as expected; now asserts the fix via the real `captureResolvedMaximums`/
  `addClassLevel`/`reconcile(player, before)` sequence. Three new checks added (new-tier-unlock +
  fully-spent combined example, a genuine captured-before decrease example, and the exact
  manual-reproduction level-12→13 tier-7-unlock check). 18 → 21 checks. **[final cleanup]** +2 checks,
  a new `maximumOnlyChange` player: a level 7→6 decrease engineered so only tier 4's maximum changes
  (1→0) while every partition's reconciled delta is zero (tier 4 pre-spent to `0/1`, floor-clamps to
  `0/0`) — proves the reconciled state comes out correct in exactly the scenario that exercises the new
  maximum-only sync fallback. 21 → 23 checks.
- `src/test/java/zcylas/totality/api/rpg/resources/integration/StandardSpellSlotResourcesTest.java` —
  grant-shape unit tests, mirrors `BarbarianRageResourcesTest`.
- `src/test/java/zcylas/totality/api/rpg/resources/MaximumChangePolicyTest.java` **[level-up
  regression, new]** — pure-formula coverage of `MaximumChangePolicy.reconcileCurrent` for the four
  task-specified maximum-change examples (new tier unlock, increase with spent slots, decrease with
  spent slots, fully spent). **[final cleanup]** +2 tests: the task's literal `CLAMP_CURRENT`
  maximum-only example (old max 4, current 2, new max 5 → current stays 2) and a `PRESERVE_DEFICIT`
  floor-clamp example (an already-empty partition whose maximum shrinks further stays at 0) — both
  prove the formula precondition that makes the partitioned maximum-only sync edge reachable.
- `src/test/java/zcylas/totality/api/rpg/classes/ClassChangeReconcilerMaximumSyncSourceRegressionTest.java`
  **[level-up regression, new]** — source-text sentinel proving `ClassChangeReconciler`'s
  maximum-reconciliation methods route through the sync-marking `PlayerResourceService`
  primitives, mirroring `BarbarianRageAbilityMaximumSyncSourceRegressionTest`'s established pattern.
  **[final cleanup]** +2 tests proving the new `if (maximumChanged && !mutated) { ResourceSyncManager
  .markDirty(...) }` fallback exists with the correct guard, and that `maximumChanged` is derived from
  a real per-partition comparison rather than set unconditionally.

## Modified files (production)

- `src/main/java/zcylas/totality/Totality.java` — registers the new verification.
- `src/main/java/zcylas/totality/api/rpg/resources/MaximumChangePolicy.java` **[level-up regression]**
  — new `reconcileCurrent(current, previousMaximumUnits, newMaximumUnits, floor)` method (the §11.4
  formula, extracted byte-for-byte from `PlayerResourceService`'s existing scalar switch so a
  partitioned caller can share it without drift); class Javadoc updated (Standard Spell Slots is no
  longer the only resource with a non-default policy).
- `src/main/java/zcylas/totality/api/rpg/resources/PlayerResourceService.java` **[level-up regression]**
  — `reconcileMaximumGenericState`'s inline policy switch replaced with a call to
  `MaximumChangePolicy.reconcileCurrent` — behavior byte-for-byte unchanged (existing scalar tests
  reconfirm this).
- `src/main/java/zcylas/totality/api/rpg/resources/integration/ResourceGrantPolicy.java` **[level-up
  regression]** — new `maximumChangePolicy` field (default `CLAMP_CURRENT`, preserving every existing
  resource's behavior); a 2-arg compact-constructor overload keeps every pre-existing direct
  construction (including 3 in `ResourceGrantReconcilerTest`) compiling unchanged.
- `src/main/java/zcylas/totality/networking/classes/AddClassLevelHandler.java` **[level-up regression,
  new to Phase 6]** — captures `ClassChangeReconciler.captureResolvedMaximums(player)` immediately
  before `comp.addClassLevel(classId)`, then calls the new `reconcile(player, before)` overload — this
  is the one call site that actually reproduces the reported bug (the ordinary multiclass level-up
  path).
- `src/main/java/zcylas/totality/api/magic/spell/SpellSlotComponent.java` — `MAX_SPELL_LEVEL` 10→9,
  `restoreSome` removed (confirmed dead), retired-authority Javadoc, `onRest` left in place but
  documented as no longer registered.
- `src/main/java/zcylas/totality/api/magic/spell/SpellSlotRecalculator.java` — `recalculate(ServerPlayer)`
  removed (no longer writes the legacy component); `computeCombinedCasterLevel`/`computeMaxSlots`
  extracted as the one authoritative calculation the resolver/grant provider both use.
- `src/main/java/zcylas/totality/api/magic/spell/SpellSlotTable.java` — `FULL_CASTER`/`HALF_CASTER`
  trimmed from 10 to 9 columns; the obsolete level-25/30 tier-10 entitlement removed entirely; new
  `STANDARD_SLOT_LEVELS = 9` constant.
- `src/main/java/zcylas/totality/api/rpg/classes/ClassChangeReconciler.java` — removed the now-redundant
  `SpellSlotRecalculator.recalculate` call; generalized the defensive maximum-decrease clamp sweep from
  scalar-only to also cover `PARTITIONED_POOL`. **[correction pass]** corrected a now-disproven Javadoc
  claim ("no current production class-derived maximum table can actually decrease this way today") —
  Finding 1 identified a real trigger (the join-time class-level normalization in
  `PlayerConnectionEvents`). **[level-up regression]** the clamp-only `clampResourcesAboveResolvedMaximum`
  /`clampScalar`/`clampPartitioned` were replaced with policy-driven
  `reconcileResourcesAgainstResolvedMaximum`/`reconcileScalar`/`reconcilePartitioned`; new public
  `captureResolvedMaximums(player)` and a `reconcile(player, Map<Identifier, ResourceMaximum>)`
  overload — see the implementation report's §22.3 for the full design and why every pre-existing call
  site needed zero changes. **[final cleanup]** `reconcilePartitioned` gained an explicit maximum-only
  sync fallback (`if (maximumChanged && !mutated) { ResourceSyncManager.markDirty(...) }`) for the case
  where a partition's maximum genuinely changes but its reconciled current lands back on the same
  value (so no drain/restore call ever ran to mark the resource dirty); the stale `@link
  #clampResourcesAboveResolvedMaximum` Javadoc reference (a method the level-up regression pass had
  already removed) was corrected to point at `reconcileResourcesAgainstResolvedMaximum`.
- `src/main/java/zcylas/totality/api/rpg/resources/ProductionResourceDefinitions.java` — `totality:spell_slots`
  flipped to `GENERIC_COMPONENT` (`definitionVersion` 1→2), `SPENDABLE`/`RESTORABLE`/`PARTITIONED_SPENDING`
  capabilities added; resolver and grant provider registered.
- `src/main/java/zcylas/totality/api/rpg/resources/client/parity/ClientSpellSlotParityComparator.java` —
  `MAX_LEVEL` 10→9.
- `src/main/java/zcylas/totality/api/rpg/resources/integration/ResourceGrantReconciler.java` — added
  `PARTITIONED_POOL` grant instantiation (`AtMaximum` only) — previously scalar-only; generic
  infrastructure, not spell-slot-specific.
- `src/main/java/zcylas/totality/init/events/PlayerConnectionEvents.java` — removed the legacy
  `SpellSlotComponent.onRest` `RestListener` registration (JOIN + AFTER_RESPAWN) and the JOIN-time
  `SpellSlotRecalculator.recalculate` call; added the new `StandardSpellSlotResources.onLongRest`
  registration (LONG only). **[correction pass]** Finding 1 fix: the JOIN-time class-level
  normalization (`if (stored > available) { classComp.setClassLevel(...); }`) now also calls
  `ClassChangeReconciler.reconcile(player)` immediately after the mutation.
- `src/main/java/zcylas/totality/networking/ability/ActivateAbilityHandler.java` — the cast pre-check
  and post-success spend now go through `PlayerResourceService.query`/`trySpend` (`EXACT_TIER`) instead
  of `SpellSlotComponent.hasSlot`/`useSlot` — control-flow ordering (successful-cast-only) unchanged.
  **[correction pass]** `handle` changed from `private` to `public` (Finding 4) so a dev-only
  verification can call this real entry point directly.
- `src/main/java/zcylas/totality/networking/resource/BaselineResourceLifecycleEvents.java` — added
  `migrateSpellSlots`, the one-time legacy-NBT import for Standard Spell Slots (partitioned variant of
  the existing Mana/Stamina/Rage pattern).

## Modified files (tests)

- `src/test/java/zcylas/totality/api/magic/spell/SpellSlotComponentTest.java` — array literals trimmed
  to 9 elements; new/updated level-10 boundary assertions; `restoreSome` test removed; comment updates.
  **[correction pass]** +1 new test, `readDataIgnoresHistoricalTierTenKeysFromAGenuinelyOldPreMigrationSave`
  (Finding 3) — hand-builds raw legacy `max_9`/`used_9` NBT keys and proves the real `readData` never
  reads them into any array slot.
- `src/test/java/zcylas/totality/api/magic/spell/SpellSlotRecalculatorCharacterizationTest.java` — doc
  updates reflecting the renamed/retired methods.
- `src/test/java/zcylas/totality/api/magic/spell/SpellSlotTableTest.java` — 9-column table assertions;
  the two tier-10-unlock tests replaced with a "no tier 10 at any level 1-30" test.
- `src/test/java/zcylas/totality/api/rpg/resources/PlayerResourceRegistryExternalAdapterFreezeTest.java` —
  spell-slots' adapter-reference test replaced with a Phase-6-correct "no adapter" test.
- `src/test/java/zcylas/totality/api/rpg/resources/PlayerResourceRegistryTest.java` — spell-slots moved
  out of the `EXTERNAL_ADAPTER` group into its own `GENERIC_COMPONENT` tests; capability test updated.
- `src/test/java/zcylas/totality/api/rpg/resources/PlayerResourceStateComponentExternalEntryPathTest.java` —
  the spell-slots NBT quarantine test replaced with a "restores live data" test.
- `src/test/java/zcylas/totality/api/rpg/resources/PlayerResourceStateComponentExternalSafetyTest.java` —
  removed the now-false "spell slots reject generic instantiation" tests; renamed the "all N remaining
  external adapters" test to three.
- `src/test/java/zcylas/totality/api/rpg/resources/client/parity/ClientResourceParityPollTest.java` —
  `tenLevels` helper renamed/trimmed to `nineLevels`.
- `src/test/java/zcylas/totality/api/rpg/resources/client/parity/ClientSpellSlotParityComparatorTest.java` —
  substantially rewritten for the 9-partition shape (helper renamed, boundary tests re-targeted at the
  new partition-10 out-of-range case).
- `src/test/java/zcylas/totality/api/rpg/resources/external/StandardSpellSlotsResourceAdapterTest.java` —
  array literals trimmed to 9 elements; tier-10 assertions replaced with "tier 10 is absent."
- `src/test/java/zcylas/totality/api/rpg/resources/integration/ResourceGrantReconcilerTest.java` — 6 new
  tests proving the new `PARTITIONED_POOL` grant-instantiation path generically (synthetic resource id).
- `src/test/java/zcylas/totality/client/resource/parity/LegacyClientResourceParityReadersTest.java` —
  array sizes/loop bounds/assertions updated to 9 partitions.

## Modified files (documentation) — new in the correction pass

- `Context/Audit/TOTALITY_GENERIC_PLAYER_RESOURCE_API.md` — **[correction pass, Finding 2]** touched
  by Phase 6 work for the first time. Corrected every Standard-Spell-Slot-specific "1..10"/"level
  1–10" statement to "1..9" (§6.2 example, §14.3, §24.4 NBT migration step 4, §25.8 spec block, the
  Phase 6 plan bullets, §28.8). §28.7's generic "Level 10 survives persistence" statement was
  clarified, not deleted, to make explicit it describes generic `PARTITIONED_POOL` infrastructure
  (e.g. Hit Dice's own `d10`), never a Standard Spell Slot statement.
