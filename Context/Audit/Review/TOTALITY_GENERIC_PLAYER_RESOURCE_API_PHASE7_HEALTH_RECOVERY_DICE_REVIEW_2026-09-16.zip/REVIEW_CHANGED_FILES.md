# Changed files (task-owned only) — Phase 7A Health Recovery Dice correction

This is a rename/correction of the same uncommitted Phase 7A work reviewed previously under the
working name "Hit Dice." Every file below either replaces a same-shaped "Hit Dice"-named file or is
an already-dirty-from-the-original-pass file updated in place.

## Removed (old working name, never committed)

- `src/main/java/zcylas/totality/api/rpg/classes/HitDiceMaximumResolver.java`
- `src/main/java/zcylas/totality/api/rpg/resources/integration/HitDiceResources.java`
- `src/main/java/zcylas/totality/api/rpg/resources/verification/HitDiceResourceVerification.java`
- `src/test/java/zcylas/totality/api/rpg/resources/integration/HitDiceResourcesTest.java`
- `Context/Audit/TOTALITY_GENERIC_PLAYER_RESOURCE_API_PHASE7_HIT_DICE_IMPLEMENTATION_REPORT_2026-09-16.md`
- `Context/Audit/Review/TOTALITY_GENERIC_PLAYER_RESOURCE_API_PHASE7_HIT_DICE_REVIEW_2026-09-16.zip`

## New (corrected name; this bundle's `src/`/`Context/Audit/` contents)

- `src/main/java/zcylas/totality/api/rpg/classes/HealthRecoveryDiceMaximumResolver.java` — same
  resolver logic as before (registry-wide fixed partition key set, class-authored `hpDie` size),
  renamed class/file, Javadoc updated to record the correction and the relationship to the future
  Hit Die API.
- `src/main/java/zcylas/totality/api/rpg/resources/integration/HealthRecoveryDiceResources.java` —
  same grant provider/policy/Long-Rest logic as before, renamed class/file/`SOURCE_ID`
  (`class_progression_health_recovery_dice`), Javadoc updated.
- `src/main/java/zcylas/totality/api/rpg/resources/verification/HealthRecoveryDiceResourceVerification.java`
  — the original 13 dev-server checks, renamed and adapted to the new id/class names with no
  substantive behavior change, plus 1 new check asserting the corrected id is registered and the
  obsolete id is not (14 total).
- `src/test/java/zcylas/totality/api/rpg/resources/integration/HealthRecoveryDiceResourcesTest.java`
  — the original 3 unit tests, renamed/adapted, plus 1 new test guarding the obsolete id's absence
  (4 total).
- `Context/Audit/TOTALITY_GENERIC_PLAYER_RESOURCE_API_PHASE7_HEALTH_RECOVERY_DICE_IMPLEMENTATION_REPORT_2026-09-16.md`
  — replaces the old report; see it for full detail.

## Modified (already-dirty-from-the-original-pass, updated in place)

- `src/main/java/zcylas/totality/Totality.java` — verification registration line updated to the
  renamed class.
- `src/main/java/zcylas/totality/api/rpg/resources/PlayerResourceIds.java` — `HIT_DICE` →
  `HEALTH_RECOVERY_DICE` (with a Javadoc note distinguishing this resource from the future Hit Die
  API).
- `src/main/java/zcylas/totality/api/rpg/resources/ProductionResourceDefinitions.java` — resource
  id/resolver/grant-provider references updated; the definition-block comment rewritten to record
  the correction and the `ClassData.hpDie` sharing relationship with the future Hit Die API.
- `src/main/java/zcylas/totality/init/events/PlayerConnectionEvents.java` — both `LONG`-only Rest
  listener registrations (JOIN and AFTER_RESPAWN blocks) updated to call
  `HealthRecoveryDiceResources.onLongRest`.
- `src/test/java/zcylas/totality/api/rpg/resources/PlayerResourceRegistryTest.java` — renamed test
  method/assertions; +1 new test guarding the obsolete id's absence; registry-size assertion (11)
  and dormant-count doc comment confirmed still correct (a rename does not change the registry
  size).
- `Context/Audit/TOTALITY_GENERIC_PLAYER_RESOURCE_API.md` — §25.10/§28.9 renamed to Health Recovery
  Dice with an explicit naming-note distinguishing the future Hit Die API; every other pre-existing
  "Hit Dice" mention throughout the document (general Generic Resource examples, partition/
  descriptor examples, integration-ownership bullets, the handoff checklist) updated for full
  consistency, since all of them described the same Generic Resource concept. One "Hit Die size"
  mention deliberately left unchanged where it correctly referred to the class metadata concept
  (`ClassData.hpDie`), not the Generic Resource. New §32 appended at the end of the document
  (`FUTURE SYSTEM — HIT DIE API`, design-only) — no existing section was renumbered.

## What was NOT changed

- `ClassData.hpDie` — not renamed, per explicit instruction; it remains real class-progression
  metadata shared by both systems.
- `ClassChangeReconciler.java` — not touched, unchanged from the original Phase 7A pass.
- No Short Rest healing logic, formula, UI, or migration was added — none existed before this
  correction and none was invented by it.
- No mechanic/behavior was redesigned — this is a pure identifier/documentation correction, verified
  by re-running the full dev-server verification suite with unchanged-in-substance coverage.
