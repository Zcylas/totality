# Review summary — Phase 7A Health Recovery Dice correction (rename from "Hit Dice")

Performed on top of HEAD `7b48387a9456b8ab2a03f6ebc0ebd9985cdf1c75`, correcting the same
still-uncommitted Phase 7A work reviewed previously under the working name "Hit Dice." No commit was
created for either pass.

## What this correction did

Renamed the Generic Resource implemented in the original Phase 7A pass from `totality:hit_dice` to
**`totality:health_recovery_dice`**, because Totality separately reserves "Hit Die API" for a
future, unimplemented Character Creation/Progression system (permanent class/resource growth rolls
— starting-class maximum, reroll-1, a pending/resolved roll ledger) with materially different scope
than the simple spendable/restorable pool implemented here. Left uncorrected, the name collision
would have become ambiguous the moment that future system is designed.

- **Renamed:** 4 production/test classes (`HitDiceMaximumResolver` →
  `HealthRecoveryDiceMaximumResolver`, `HitDiceResources` → `HealthRecoveryDiceResources`,
  `HitDiceResourceVerification` → `HealthRecoveryDiceResourceVerification`,
  `HitDiceResourcesTest` → `HealthRecoveryDiceResourcesTest`), the `PlayerResourceIds.HIT_DICE`
  constant → `HEALTH_RECOVERY_DICE`, the resource id string, the grant `SOURCE_ID`, and every
  registration/reference in `Totality.java`/`ProductionResourceDefinitions.java`/
  `PlayerConnectionEvents.java`/`PlayerResourceRegistryTest.java`.
- **Preserved exactly:** every backend mechanic — `GENERIC_COMPONENT`/`PARTITIONED_POOL`,
  class-derived maxima from `ClassData.hpDie` (not renamed — it remains real class metadata shared
  by both this resource and the future Hit Die API by design), same-die-size aggregation,
  different-die-size independence, `SHARED_RESOURCE`/`REMOVE_STATE`/`PRESERVE_DEFICIT`, `AtMaximum`
  first grant, generic sync/persistence, `KEEP_CURRENT` death policy, Long-Rest-restores-all, no
  automatic Short Rest behavior, `PlayerResourceService`-only spending with no cross-partition
  fallback. No defect was found during the rename that would have justified a behavior change.
- **No migration added:** this work was never committed and has no legitimate persisted save format
  under either name — the id was simply corrected before it becomes canonical, per explicit
  instruction.
- **Future Hit Die API:** documented only (new canonical §32 — scope, roll semantics including
  reroll-1 and the starting-class-maximum rule, late-resource-acquisition pending-roll behavior, and
  the future data/ledger requirement), not implemented. No Java code exists for it.
- **Canonical doc:** §25.10/§28.9 renamed with an explicit naming-note distinguishing the two
  systems; every other pre-existing "Hit Dice" mention throughout the document updated for
  consistency; one "Hit Die size" (class metadata) mention deliberately left unchanged.

## Test/build evidence

- `./gradlew test` (full suite): **1626 tests, 0 failures, 0 errors** (was 1624 before this
  correction pass — +2: two new regression tests guarding the obsolete id's absence).
- `./gradlew clean build`: **BUILD SUCCESSFUL.**
- `git diff --check`: clean (only benign pre-existing CRLF-normalization warnings).
- Bounded dedicated-server run (`runServer_bounded_verification.log`):
  **`[HealthRecoveryDiceResourceVerification] All 14 self-test checks passed.`** (was 13 under the
  old name — +1 new obsolete-id-absence check). `[ResourceFoundationVerification] All 6`,
  `[BaselineResourceMigrationVerification] All 11`, `[BarbarianRageMigrationVerification] All 18`,
  `[StandardSpellSlotMigrationVerification] All 23`,
  `[CrownOfStarsActiveInstanceActionVerification] All 11` — all unchanged, byte-identical to the
  original (pre-correction) Phase 7A run. The same two unrelated, pre-existing verification
  failures (`ProvisionerEntityBackedSmokeTest` 3/4 FAIL, `OffhandAttackVerification` 3/5 FAIL)
  appeared again, identically — not touched by this task.

## Manual testing — still NOT performed

No manual/real-playable-client testing has been performed for this resource under either name. See
the implementation report for the unchanged manual test checklist inherited from the original pass.

## Isolating this task's diff

The 109 unrelated pre-existing dirty paths were untouched throughout — verified before and after
this correction pass. Every additional dirty path belongs to this corrected Phase 7A work: 4
renamed production/test files, 2 renamed documentation artifacts (report + review zip), and 6
already-dirty-from-the-original-pass files updated in place (`Totality.java`, `PlayerResourceIds.java`,
`ProductionResourceDefinitions.java`, `PlayerConnectionEvents.java`, `PlayerResourceRegistryTest.java`,
the canonical doc).

## Files in this bundle

See `REVIEW_CHANGED_FILES.md` for the full list and per-file description. See
`TOTALITY_GENERIC_PLAYER_RESOURCE_API_PHASE7_HEALTH_RECOVERY_DICE_IMPLEMENTATION_REPORT_2026-09-16.md`
for the complete rationale, the future Hit Die API's recorded canon, and validation detail.
