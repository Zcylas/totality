# Baseline

- Branch: `feature/general-resource-api`
- HEAD, verified with `git rev-parse HEAD` (full SHA): `7b48387a9456b8ab2a03f6ebc0ebd9985cdf1c75`
  (`fix(checks): separate ability check and saving throw bonuses`) — unchanged throughout the
  original Phase 7A pass and this correction pass.
- HEAD after this task: **unchanged** — no commit was created for either pass, per explicit
  instruction.
- `git status --short` before this correction pass began: **121 dirty paths** (109 unrelated
  pre-existing + 12 from the original, uncommitted Phase 7A "Hit Dice" pass), verified before any
  edit in this correction pass.
- `git status --short` after this correction pass: **119 dirty paths before the report/review-zip
  were (re)created**, then back to the same file-count shape once both artifacts were recreated
  under their corrected names — the rename replaced 4 production/test files and 2 documentation
  artifacts 1-for-1 with corrected-name equivalents; it did not add or remove a net path count
  beyond that direct substitution.

## Why this is a correction, not a new task

The original, uncommitted Phase 7A work implemented a Generic Resource under the working name "Hit
Dice" / `totality:hit_dice`. Totality separately reserves the term **Hit Die API** for a future,
unimplemented Character Creation/Progression system with a materially different scope (permanent
class/resource growth rolls, starting-class tracking, a pending/resolved roll ledger). Left
uncorrected, this collision would have made `totality:hit_dice` ambiguous the moment the real Hit
Die API is designed. This pass renames the Generic Resource to `totality:health_recovery_dice`,
preserves its already-tested backend behavior unchanged, and records the future Hit Die API's own
design intent in a new canonical §32 so the two systems can never be confused again — see the
implementation report for full detail.

## Scope confirmation

No `ClassChangeReconciler` code was touched (unchanged from the original pass — the maximum
resolver's registry-wide fixed partition key set design already avoided the one Phase 6 integration
risk the pre-implementation investigation flagged). `ClassData.hpDie` was **not** renamed — it
remains real class-progression metadata, shared by design with both this Generic Resource and the
future (undocumented-in-code) Hit Die API. No migration was added — this work was never committed
and has no legitimate persisted save format under either name. No mechanic was redesigned during
the rename; only names changed, verified by re-running the full, unchanged-in-substance dev-server
verification suite.
