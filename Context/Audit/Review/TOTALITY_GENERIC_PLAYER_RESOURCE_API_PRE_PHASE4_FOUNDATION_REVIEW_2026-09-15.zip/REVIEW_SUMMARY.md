# Review Summary — Generic Player Resource API: Pre-Phase-4 Foundation (refreshed after external-review correction pass)

**Date:** 2026-09-15 (foundation pass), corrected 2026-09-15 (same day, external-review correction pass)
**Branch:** `feature/general-resource-api`
**HEAD (unchanged, nothing committed by either pass):** `73380f9` "feat: add wearable Shinigami Robe"
**Working tree:** not committed. This bundle isolates exactly the files these two passes together touched; see `REVIEW_CHANGED_FILES.md` for the itemized list (with per-file correction-pass annotations) and `REVIEW_GIT_DIFF.patch` for the literal diff.

---

## What this bundle is

This is a **refreshed** review bundle. The original foundation pass built the three canonical pieces the 2026-09-15 Phases 4-8 gap audit found missing before Phase 4 (Mana/Stamina migration) could begin: the `PlayerResourceService` mutation façade, the `ResourceGrantProvider`/reconciliation mechanism, and the `ResourceMaximumResolver` framework. An external review of that original bundle found 12 issues. This bundle reflects the **corrected** state after addressing all 12 — see the implementation report's new §19 "External Review Corrections" section for the full per-issue classification and evidence. **No Mana/Stamina/Rage/Spell Slot migration work was done in either pass.**

## What the correction pass changed, in one paragraph

Dormant (`PRESERVE_DORMANT`) resource state is no longer spendable/drainable/restorable through ordinary gameplay (a real safety gap in the original pass) — a new `active` flag on `ScalarResourceState`/`PartitionedResourceState`, persisted via a schema bump. Grant removal now honors the *winning grant's own* declared removal policy (canonical §16.2) rather than a per-resource registry default, tracked via a small in-memory map on `PlayerResourceStateComponent`. All new arithmetic (scalar/partitioned deltas, `PRESERVE_RATIO`/`PRESERVE_DEFICIT`/overflow-accumulation reconciliation, grant `AtFraction` initialization, transaction `Drain`/`Restore`) is now overflow-checked and rejects rather than wraps. `Ledger.simulate`'s transaction validation now matches every single-operation path's own validation (no more unchecked cast, no more silently-inverted negative Drain/Restore). Grant `AtAbsolute`/`AtFraction` initialization is now validated (resource-id match, shape, bounds) before ever touching real state. `resolveMaximum`'s authored-base-vs-resolver precedence was inverted to match canonical §10.2's literal step order (authored base now wins when both exist). A registered resolver's partitioned maximum is now structurally validated (no negative partition values). 23 new regression tests were added (55 → 78 focused Resource API tests); 2 existing tests were rewritten (not weakened) to pin the newly-correct behavior.

## Architectural changes made (original foundation pass, unchanged by the correction)

- `PlayerResourceService` gained a full mutation façade (`trySpend`/`drain`/`restore`/`set`/`transact`) and a central `resolveMaximum` path shared by query and mutation.
- A new grant subsystem (`ResourceGrantProvider` → `ResourceGrant` → `ResourceGrantReconciler` → `PlayerResourceStateComponent`) implements the canonical ownership chain, stateless between calls.
- `GENERIC_COMPONENT` `PARTITIONED_POOL` resources are now genuinely supported by the query path.
- Aggregation/removal policy is deliberately **not** a new field on `PlayerResourceDefinition` — a sibling `ResourceGrantPolicyRegistry` holds the per-resource default (the correction pass adds a per-*grant* override on top of this default, see below).

## New public APIs / types introduced

Unchanged from the original pass — see the implementation report §1/§3. The correction pass added no new public types; it added two new package-visible/public accessor pairs (`ScalarResourceState`/`PartitionedResourceState`'s `active()`/`setActive()`; `PlayerResourceStateComponent`'s `isActive`/`setActive`/`setGrantRemovalPolicy`/`getGrantRemovalPolicy`/`clearGrantRemovalPolicy`) and one new mapped failure usage (`ResourceFailureCode.RESOURCE_INACTIVE`, an existing enum constant that was previously unused by any code path).

## Production wiring added

Unchanged: **one line**, in `Totality.java`: `ResourceFoundationVerification.register()`. The correction pass added no new production wiring. No production resource, grant provider, or maximum resolver was registered anywhere by either pass.

## Tests added

Original pass: 55 tests across 4 new files, plus 2 existing tests rewritten for the closed `PARTITIONED_POOL` query gap.
**Correction pass: +23 tests** (78 total across the same 4 files: 26 mutation + 14 transaction + 20 maximum-resolution + 18 grant-reconciler), plus 2 more existing tests rewritten (not weakened) to pin the corrected removal-policy and maximum-precedence behavior.

Plus the dev-only, isolated-registry, real-`ServerPlayer` end-to-end self-test (`ResourceFoundationVerification`) — re-confirmed passing 6/6 in a real dedicated server after the correction pass.

## Intentionally untouched systems

Unchanged from the original pass and re-verified by `git diff` inspection during the correction pass: `PlayerManaManager`, `PlayerStaminaManager`, `PlayerChargesComponent`, `SpellSlotComponent`, `ProductionResourceDefinitions.java`, every legacy sync packet, and all 7 production `EXTERNAL_ADAPTER` resources' authority. No NBT migration. No dormant resource (Thirst/Sanity/Ki) was promoted or instantiated for any real player. No Rage dimension-transfer fix. No legacy manager/packet removed. No gameplay balance number changed.

## Known limitations / deferred work (updated)

Everything the original pass deferred (§14 of the report) remains deferred, plus: `active`/dormancy is a server-authoritative mutation-safety fix only — it is **not** included in the sync packet payload, so full HUD/visibility integration (canonical §16.9-16.10, "ungranted resources should normally be absent from the HUD/client-visible data") remains explicitly future work, not falsely claimed complete. The `grantRemovalPolicies` bookkeeping is in-memory only (documented, minor limitation for the cross-server-restart edge case — see Issue 1 in the report). No production caller invokes `ResourceGrantReconciler.reconcile()` on any real trigger (class change, respec, login) yet — this was true before the correction pass and remains true after it.

## Validation results (correction pass)

- `./gradlew compileJava` / `compileTestJava` — **BUILD SUCCESSFUL**
- Focused Resource API tests — **78/78 passing** (up from 55/55)
- Full test suite — **1520/1520 passing, 0 failures, 0 errors** (up from 1497 before the correction pass)
- `./gradlew clean build` — **BUILD SUCCESSFUL**
- `git diff --check` — clean (no whitespace errors; only pre-existing LF/CRLF informational warnings)
- Bounded dedicated-server startup — **confirmed**: reached `Done (0.356s)!`, then `[ResourceFoundationVerification] All 6 self-test checks passed.`, zero exceptions. Two unrelated, pre-existing verification failures observed in the same run (`ProvisionerEntityBackedSmokeTest`, `OffhandAttackVerification`) — neither references any file this task touched; both outside this task's scope, not addressed.

## Final answers

- **Pre-Phase-4 foundation correctness review: PASS**
- **Phase 4 Mana/Stamina migration safe to begin: YES**

## Current Git commit / working-tree status

Nothing committed by either pass. `HEAD` is `73380f9` on `feature/general-resource-api`, unchanged. All changes described here exist only in the working tree.
