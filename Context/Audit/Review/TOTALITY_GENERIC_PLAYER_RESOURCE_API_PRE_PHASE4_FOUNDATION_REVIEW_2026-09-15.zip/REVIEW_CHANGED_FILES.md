# Changed Files Manifest — Pre-Phase-4 Foundation (refreshed after the 2026-09-15 external-review correction pass)

Repository-relative paths. **CORRECTED** marks a file the 2026-09-15 correction pass touched again, on top of the original 2026-09-15 foundation pass.

## ADDED — main sources (29, from the original foundation pass; unchanged further except where marked)

| File | Why |
|---|---|
| `src/main/java/zcylas/totality/api/rpg/resources/ResourceFailureCode.java` | Canonical §21.1 mutation-failure vocabulary (23 codes). |
| `src/main/java/zcylas/totality/api/rpg/resources/ResourceFailure.java` | Canonical §21.1 structured failure record. |
| `src/main/java/zcylas/totality/api/rpg/resources/ResourceOperationResult.java` | Canonical §21.2 mutation result — sealed `Success`/`PartitionedSuccess`/`Failure`. |
| `src/main/java/zcylas/totality/api/rpg/resources/PartitionSelectionPolicy.java` | Canonical §14.1 partitioned-cost selection policy enum. |
| `src/main/java/zcylas/totality/api/rpg/resources/ResourceCost.java` | Canonical §12.1/§14.1 `trySpend` input — sealed `Scalar`/`Partitioned`. |
| `src/main/java/zcylas/totality/api/rpg/resources/ResourceTarget.java` | Canonical §12.1 `set` input. |
| `src/main/java/zcylas/totality/api/rpg/resources/ResourceCause.java` | Canonical §20.3 mutation-cause record. |
| `src/main/java/zcylas/totality/api/rpg/resources/ResourceContext.java` | Canonical §20.3 mutation-context record. |
| `src/main/java/zcylas/totality/api/rpg/resources/MaximumChangePolicy.java` | Canonical §11.4 maximum-change reconciliation policy enum. |
| `src/main/java/zcylas/totality/api/rpg/resources/ResourceMaximum.java` | Canonical §10.3 resolved-maximum sealed type. |
| `src/main/java/zcylas/totality/api/rpg/resources/ResourceResolutionContext.java` | Auxiliary context parameter for `ResourceMaximumResolver`. |
| `src/main/java/zcylas/totality/api/rpg/resources/ResourceMaximumResolver.java` | Canonical §9.1 dynamic-maximum strategy interface. |
| `src/main/java/zcylas/totality/api/rpg/resources/ResourceMaximumResolverRegistry.java` | Registry of resolvers by resource id. |
| `src/main/java/zcylas/totality/api/rpg/resources/ResourceOperation.java` | Sealed transaction line-item type. |
| `src/main/java/zcylas/totality/api/rpg/resources/TransactionMode.java` | Canonical §13.2 transaction mode enum. |
| `src/main/java/zcylas/totality/api/rpg/resources/ResourceTransaction.java` | Canonical §13.2 transaction request record. |
| `src/main/java/zcylas/totality/api/rpg/resources/ResourceTransactionResult.java` | Transaction outcome record. |
| `src/main/java/zcylas/totality/api/rpg/resources/integration/ResourceGrantSourceType.java` | Canonical §16.2 grant-source-type enum. |
| `src/main/java/zcylas/totality/api/rpg/resources/integration/ResourceGrantMode.java` | Canonical §16.2 grant-mode enum. |
| `src/main/java/zcylas/totality/api/rpg/resources/integration/ResourceGrantAggregationPolicy.java` | Canonical §16.4 aggregation-policy enum. |
| `src/main/java/zcylas/totality/api/rpg/resources/integration/ResourceRemovalPolicy.java` | Canonical §16.7 removal-policy enum. |
| `src/main/java/zcylas/totality/api/rpg/resources/integration/ResourceVisibilityPolicy.java` | Canonical §16.10 visibility-policy enum. |
| `src/main/java/zcylas/totality/api/rpg/resources/integration/ResourceGrant.java` | Canonical §16.2 grant record. |
| `src/main/java/zcylas/totality/api/rpg/resources/integration/ResourceGrantProvider.java` | Canonical §16.2 owning-system grant-provider interface. |
| `src/main/java/zcylas/totality/api/rpg/resources/integration/ResourceGrantRegistry.java` | Registry of providers. |
| `src/main/java/zcylas/totality/api/rpg/resources/integration/ResourceGrantPolicy.java` | Per-resource aggregation+removal policy pair (registry default). |
| `src/main/java/zcylas/totality/api/rpg/resources/integration/ResourceGrantPolicyRegistry.java` | Registry of `ResourceGrantPolicy` by resource id. |
| `src/main/java/zcylas/totality/api/rpg/resources/integration/ResourceGrantReconciler.java` | **CORRECTED** — the grant reconciliation engine. Correction pass: now honors a grant's own `removalPolicy` (Issue 1), marks/reactivates dormant state (Issue 2), overflow-checked `AtFraction` arithmetic (Issue 3), validates `AtAbsolute`/`AtFraction` grant initialization (Issue 5). |
| `src/main/java/zcylas/totality/api/rpg/resources/verification/ResourceFoundationVerification.java` | Dev-environment-gated end-to-end self-test. Re-run this pass (6/6 passing) to prove the correction-pass changes work against a real server/player; not itself edited. |

## ADDED — test sources (4, from the original foundation pass, all extended by the correction pass)

| File | Why |
|---|---|
| `src/test/java/zcylas/totality/api/rpg/resources/PlayerResourceServiceMutationTest.java` | **CORRECTED** — +6 tests: dormant-state rejection (scalar/partitioned/drain/restore), the `set`-is-privilege-exempt case, and overflow-rejection near `Long.MAX_VALUE`/`MIN_VALUE`. |
| `src/test/java/zcylas/totality/api/rpg/resources/PlayerResourceServiceTransactionTest.java` | **CORRECTED** — +6 tests: `Ledger` model-mismatch/negative-amount validation parity, transaction-level overflow rejection, dormant-state handling (unprivileged blocks, privileged Set allows). |
| `src/test/java/zcylas/totality/api/rpg/resources/PlayerResourceServiceMaximumResolutionTest.java` | **CORRECTED** — 1 test rewritten (`resolverTakesPriorityOverAnAuthoredMaximumWhenBothArePresent` → `authoredMaximumTakesPriorityOverARegisteredResolverWhenBothArePresent`, now pinning the corrected precedence) + 2 new partitioned-maximum-safety tests + 1 new `PRESERVE_RATIO` overflow test. |
| `src/test/java/zcylas/totality/api/rpg/resources/integration/ResourceGrantReconcilerTest.java` | **CORRECTED** — 1 test rewritten (`finalGrantRemovalWithPreserveDormantLeavesStateInPlace` → `...ButMarksItInactive`, now also asserting dormancy) + a `removalPolicy`-parameterized `grant()` helper overload + 8 new tests (reactivation, per-grant-not-per-resource policy, 4 `AtAbsolute` validation cases, `AtFraction` clamp/overflow). |

## MODIFIED — main sources (6; was 5 in the original foundation pass — `PlayerResourceStateComponent.java` is a new addition to this list, touched for the first time by the correction pass)

| File | Why |
|---|---|
| `src/main/java/zcylas/totality/api/rpg/resources/PlayerResourceService.java` | **CORRECTED** — original pass added the mutation façade/central `resolveMaximum`/`PARTITIONED_POOL` query support. Correction pass: swapped `resolveMaximum`'s authored-vs-resolver precedence (Issue 7), added `isValidPartitionedMaximum` structural safety (Issue 8), added dormant-state (`RESOURCE_INACTIVE`) checks to every mutation entry point (Issue 2), added checked arithmetic throughout (Issue 3), fixed `Ledger.simulate`'s unchecked cast and validation gaps (Issue 4), added a dormant-state check to `transactGenericState` (Issue 2). |
| `src/main/java/zcylas/totality/api/rpg/resources/PlayerResourceStateComponent.java` | **NEW to this correction pass** (was untouched by the original foundation pass; this file predates both tasks, from Phase 1). Added the `active`/dormant flag's component-level accessors (`isActive`/`setActive`), the in-memory `grantRemovalPolicies` bookkeeping map and its accessors, NBT schema bump 2→3 to persist the `active` flag, and `copyFrom`/`readData` propagation (Issues 1 and 2). |
| `src/main/java/zcylas/totality/api/rpg/resources/ResourceAmount.java` | Unchanged since the original pass — Javadoc update only (mutation methods now exist). |
| `src/main/java/zcylas/totality/api/rpg/resources/external/ExternalPlayerResourceAdapter.java` | Unchanged since the original pass — 3 default throwing stub methods. |
| `src/main/java/zcylas/totality/api/rpg/resources/integration/ResourceGrantInitialization.java` | Unchanged since the original pass — Javadoc update only. |
| `src/main/java/zcylas/totality/Totality.java` | Unchanged since the original pass — one line registering `ResourceFoundationVerification`. |

## MODIFIED — main sources (2, new this correction pass)

| File | Why |
|---|---|
| `src/main/java/zcylas/totality/api/rpg/resources/state/ScalarResourceState.java` | **NEW to this correction pass.** Added the `active` field (default `true`) + `active()`/`setActive()`, preserved by `copy()` (Issue 2). |
| `src/main/java/zcylas/totality/api/rpg/resources/state/PartitionedResourceState.java` | **NEW to this correction pass.** Same `active` field addition as `ScalarResourceState.java` (Issue 2). |

## MODIFIED — test sources (2)

| File | Why |
|---|---|
| `src/test/java/zcylas/totality/api/rpg/resources/PlayerResourceServiceTest.java` | Unchanged since the original pass (mechanical `queryGenericState` signature update + 2 rewritten tests, both about the original pass's `PARTITIONED_POOL` query gap, unrelated to this correction pass). |
| `src/test/java/zcylas/totality/api/rpg/resources/DormantResourceRegistrationTest.java` | Unchanged since the original pass (same mechanical update). |

## DELETED

None.

## Included for context (not code changes)

| File | Why |
|---|---|
| `Context/Audit/TOTALITY_GENERIC_PLAYER_RESOURCE_API_PRE_PHASE4_FOUNDATION_IMPLEMENTATION_REPORT_2026-09-15.md` | The full implementation report, now including a new §19-21 "External Review Corrections" section classifying all 12 review findings. |
| `REVIEW_GIT_DIFF.patch` | Plain-text `git diff` covering exactly the 40 source/test files above (34 added + 6 modified main + 2 modified test, shown as new-file diffs via `git add -N` for the 34 never-committed files), refreshed to include every correction-pass change. |
| `REVIEW_SUMMARY.md` | Reviewer-facing summary (this bundle's sibling file), refreshed with the correction pass's outcome. |
