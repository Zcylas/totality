# Review Summary — Phase 4: Mana + Stamina Authority Migration (refreshed after the final external-review correction pass)

**Date:** 2026-09-15 (original pass), corrected 2026-09-15 (same day, final external-review correction pass)
**Branch:** `feature/general-resource-api`
**HEAD (unchanged, nothing committed by either pass):** `73380f9` "feat: add wearable Shinigami Robe"
**Working tree:** not committed. This bundle isolates exactly the 22 files these two passes together touched; see `REVIEW_CHANGED_FILES.md` for the itemized list (with per-file correction-pass annotations) and `REVIEW_GIT_DIFF.patch` for the literal diff.

---

## What this bundle is

This is a **refreshed** review bundle. The original Phase 4 pass migrated Mana and Stamina from legacy authoritative storage into `PlayerResourceStateComponent` + `PlayerResourceService`. An external review of that original bundle found two code/documentation issues plus a manual-validation requirement — see the implementation report's §26 "Final External Review Corrections" for the full per-finding classification and evidence. **Rage and Spell Slots remain untouched by either pass.**

## What the correction pass changed, in one paragraph

Mana/Stamina's `ProductionResourceDefinitions.java` capability metadata was still declaring the old Phase 2C transitional shape (`HUD_VISIBLE`/`MENU_VISIBLE` only) even after the authority flip to real, authoritative `GENERIC_COMPONENT` resources — corrected to canonical §25.4/§25.5's exact declared sets (`SPENDABLE`/`RESTORABLE`/`PASSIVE_REGENERATION`/`MAXIMUM_MODIFIERS`/+`HUD_VISIBLE`/`MENU_VISIBLE` for Mana; the same plus `DIRECT_DRAIN`/`CLIENT_PREDICTION` for Stamina). The legacy NBT migration's idempotency guard relied on Generic-state presence alone, which conflated "never migrated" with "migrated, then later lost its live state for an unrelated reason" (e.g. a persisted-data quarantine) — a durable, per-resource `legacyMigratedResourceIds` marker was added to `PlayerResourceStateComponent` (NBT schema 3→4) so the migration-import guard can no longer be fooled into resurrecting a stale legacy value. `PlayerResourceStateComponent`'s class-level Javadoc, which still described Mana/Stamina as `EXTERNAL_ADAPTER`-authority, was corrected. 7 new tests were added; no existing test was weakened.

## Architectural changes made (original Phase 4 pass, extended by the correction pass)

- `totality:mana`/`totality:stamina`: `EXTERNAL_ADAPTER` → `GENERIC_COMPONENT`, `definitionVersion` 1→2, dropped `authoredBaseMaximum` (would have short-circuited the new resolvers), and — as of this correction pass — corrected capability metadata matching canonical exactly.
- First production grant/reconciliation wiring (`totality:player_baseline`), ordered precisely relative to the legacy-reading recalculator and the sync-snapshot scheduler.
- `PlayerManaManager`/`PlayerStaminaManager` rewritten as pure compatibility facades — zero gameplay caller files touched.
- `PlayerResourceStateComponent.copyFrom` now consults each resource's `ResourceDeathPolicy` — and, as of this correction pass, also carries a durable, respawn-surviving migration-completion marker per resource, independent of the resource's live value.

## New public APIs / types introduced

Unchanged from the original pass (see the implementation report §1) plus, this correction pass:
`PlayerResourceStateComponent.isLegacyMigrated(Identifier)`/`markLegacyMigrated(Identifier)`.

## Production wiring

Unchanged from the original pass — see the implementation report §7.

## Compatibility facades retained

Unchanged — `PlayerManaManager`/`PlayerStaminaManager` remain the public API every existing gameplay
caller uses.

## Legacy paths removed

None in this correction pass (the original pass's one redundant re-clamp-line removal in
`StaminaServerTick` stands unchanged).

## Legacy paths deliberately retained

Unchanged from the original pass — `PlayerResourceComponent`'s legacy Mana/Stamina fields remain
fully intact (never deleted, matching canonical §24.4's "controlled transition period" language);
this correction pass's migration marker makes the eventual removal of those fields *safer*, not the
trigger for removing them now.

## Sync/prediction changes

None.

## Tests

7 new/rewritten test methods this correction pass (2 rewritten in `PlayerResourceRegistryTest.java`
replacing 1 that pinned the wrong capability set, 5 new in a dedicated migration-marker test file),
plus +1 dev-only end-to-end check (now 11, was 10). Combined with the original pass: 30 new/rewritten
test methods total across 9 files, plus the 11-check dev-only self-test. No test was deleted or
weakened without a same-behavior-class replacement.

## Validation

- `./gradlew compileJava` / `compileTestJava` — **BUILD SUCCESSFUL**
- Full test suite — **1533/1533 passing, 0 failures, 0 errors** (up from 1527 before this correction pass)
- `./gradlew clean build` — **BUILD SUCCESSFUL**
- `git diff --check` — clean (no whitespace errors; only pre-existing LF/CRLF informational warnings)
- Bounded dedicated-server startup — **confirmed**: reached `Done (0.293s)!`, then
  `[ResourceFoundationVerification] All 6 self-test checks passed.` and
  **`[BaselineResourceMigrationVerification] All 11 self-test checks passed.`** (up from 10 — the new
  check directly proves Finding 2's fix). The same two unrelated, pre-existing verification failures
  (`ProvisionerEntityBackedSmokeTest`, `OffhandAttackVerification`) were observed again, confirmed
  identical to every prior run on this branch — not caused or worsened by this correction pass.

## Known risks

Unchanged from the original pass (implementation report §25) — none newly introduced by this
correction pass.

## Final answers

- **Phase 4 code review: PASS**
- **Phase 4 automated validation: PASS**
- **Phase 4 manual validation: PENDING STEFAN**
- **Safe to commit Phase 4: YES** (pending Stefan's manual playtest checklist — see the implementation report §29)
- **Safe to begin Phase 5 Rage migration: YES**
- **Generic Player Resource API V1 overall: NOT COMPLETE**

## Current Git commit / working-tree status

Nothing committed by any pass. `HEAD` is `73380f9` on `feature/general-resource-api`, unchanged. All
changes described here exist only in the working tree.
