package zcylas.totality.networking.stamina;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import zcylas.totality.api.core.component.ComponentProvider;
import zcylas.totality.api.core.movement.*;
import zcylas.totality.api.rpg.combat.CombatStateManager;
import zcylas.totality.api.rpg.combat.bow.BowStaminaHandler;
import zcylas.totality.api.rpg.combat.stamina.depletion.StaminaDepletionManager;
import zcylas.totality.api.rpg.resources.ResourceComponents;
import zcylas.totality.api.rpg.stamina.PlayerStaminaManager;
import zcylas.totality.networking.movement.MovementStaminaHandler;

public class StaminaServerTick {
    // Static counter shared across all players on this server instance — fine for single-server use
    private static int tickCounter = 0;

    private static final Identifier SPEED_MODIFIER_ID =
            Identifier.fromNamespaceAndPath("totality", "stamina_depleted_movement_penalty");
    private static final double SPEED_PENALTY = -0.20;

    private static final Identifier ATTACK_MODIFIER_ID =
            Identifier.fromNamespaceAndPath("totality", "stamina_depleted_attack_penalty");
    private static final double ATTACK_PENALTY = -0.25;

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            tickCounter++;

            for (ServerPlayer player : server.getPlayerList().getPlayers()) {

                // ── Tick combat timer ─────────────────────────────────────────
                CombatStateManager.tick(player);

                // ── Biological flight drain — every 5 ticks while active ─────────────────
                // ── Biological flight drain ───────────────────────────────────────────────
                PlayerMovementComponent movement = MovementComponents.MOVEMENT.get(
                        (ComponentProvider) player);
                // ── Ground Slam impact handling ─────────────────────────────────
                if (movement.isGroundSlamming()) {

                    boolean impacted =
                            player.onGround()
                                    || player.horizontalCollision
                                    || player.verticalCollision;

                    if (impacted) {
                        GroundSlamImpact.perform(player, movement.getGroundSlamStartY());
                        movement.stopGroundSlam();
                    } else {
                        player.setDeltaMovement(
                                player.getDeltaMovement().x * 0.8D,
                                MovementStaminaCosts.GROUND_SLAM_DOWNWARD_VELOCITY,
                                player.getDeltaMovement().z * 0.8D
                        );

                        player.fallDistance = 0.0F;
                        player.hurtMarked = true;
                    }
                }
                if (PlayerStaminaManager.getStamina(player) <= 0 && movement.isPowerSprinting()) {
                    movement.setPowerSprinting(false);
                }

                if (!player.isSprinting() && movement.isPowerSprinting()) {
                    movement.setPowerSprinting(false);
                }

                if (movement.isActivelyFlying() && !player.isCreative()) {
                    boolean onGround = player.onGround();

                    if (onGround && !player.isFallFlying()) {
                        movement.setActivelyFlying(false);
                        syncStamina(player);
                        continue;
                    }

                // Drain while biological flight is active and the player is airborne.
                    if (!onGround && tickCounter % MovementStaminaCosts.FLIGHT_DRAIN_INTERVAL_TICKS == 0) {
                        PlayerStaminaManager.removeStamina(player, MovementStaminaCosts.FLIGHT_DRAIN_COST);
                        syncStamina(player);
                    }

                    if (PlayerStaminaManager.getStamina(player) <= 0) {
                        movement.setActivelyFlying(false);
                        player.setDeltaMovement(
                                player.getDeltaMovement().x,
                                -0.15D,
                                player.getDeltaMovement().z
                        );
                        syncStamina(player);
                    }
                }

                // ── Sprint drain — every 3 ticks, only on ground ──────────────
                boolean powerSprinting = isPowerSprinting(player, movement);

                if (player.isSprinting() && !powerSprinting && !player.isCreative() && player.onGround()
                        && !BowStaminaHandler.isBowDrawn(player)) {
                    if (tickCounter % MovementStaminaCosts.NORMAL_SPRINT_DRAIN_INTERVAL_TICKS == 0) {
                        PlayerStaminaManager.removeStamina(player, 1);
                        syncStamina(player);
                    }
                    if (PlayerStaminaManager.getStamina(player) <= 0) {
                        player.setSprinting(false);
                    }
                }

                // ── Bow stamina drain ─────────────────────────────────────────
                BowStaminaHandler.tick(player, tickCounter);

                // ── Stamina depletion state tick ──────────────────────────────
                StaminaDepletionManager.tick(player);

                // ── Stamina depletion attribute penalties ─────────────────────
                boolean penalized = StaminaDepletionManager.isPenalized(player) && !player.isCreative();

                var speedAttr = player.getAttribute(Attributes.MOVEMENT_SPEED);
                if (speedAttr != null) {
                    if (penalized) {
                        speedAttr.addOrUpdateTransientModifier(new AttributeModifier(
                                SPEED_MODIFIER_ID, SPEED_PENALTY,
                                AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
                    } else {
                        speedAttr.removeModifier(SPEED_MODIFIER_ID);
                    }
                }

                var attackAttr = player.getAttribute(Attributes.ATTACK_DAMAGE);
                if (attackAttr != null) {
                    if (penalized) {
                        attackAttr.addOrUpdateTransientModifier(new AttributeModifier(
                                ATTACK_MODIFIER_ID, ATTACK_PENALTY,
                                AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
                    } else {
                        attackAttr.removeModifier(ATTACK_MODIFIER_ID);
                    }
                }

                // ── Stamina regen — every 20 ticks ────────────────────────────
                if (tickCounter % 20 == 0) {
                    int currentStamina = PlayerStaminaManager.getStamina(player);
                    // Only block regen while actively consuming stamina (stamina > 0).
                    // When stamina is already 0, the client may still be re-initiating sprint
                    // (CTRL held) even though the server kills it every tick. Without this check,
                    // isSprinting() stays true and regen is permanently blocked — locking the
                    // player out of sprint until they manually release the sprint key.
                    boolean regenBlocked = (player.isSprinting() && currentStamina > 0)
                            || powerSprinting
                            || BowStaminaHandler.isBowDrawn(player)
                            || movement.isActivelyFlying();

                    if (!regenBlocked) {
                        int current = PlayerStaminaManager.getStamina(player);
                        int max     = PlayerStaminaManager.getMaxStamina(player);
                        if (current < max) {
                            float regenMultiplier = StaminaDepletionManager.getRegenMultiplier(player);
                            int regenAmount = Math.max(1,
                                    (int)(PlayerStaminaManager.calculateRegenAmount(player)
                                            * regenMultiplier));
                            PlayerStaminaManager.addStamina(player, regenAmount);
                            // The re-set that used to live here was truly redundant even before
                            // this migration (nested inside the same current<max branch that just
                            // called addStamina, which already clamps to max) — unlike Mana's
                            // equivalent line (kept — see ManaServerTick), it never covered a
                            // current>max case, since nothing else here calls it unconditionally.
                            syncStamina(player);
                        }
                    }
                }
            }

            if (tickCounter >= 60) tickCounter = 0;
        });
    }

    public static void syncStamina(ServerPlayer player) {
        ServerPlayNetworking.send(player, new SyncStaminaPayload(
                PlayerStaminaManager.getStamina(player),
                PlayerStaminaManager.getMaxStamina(player)));
    }

    private static boolean isPowerSprinting(ServerPlayer player, PlayerMovementComponent movement) {
        return !player.isCreative()
                && player.isSprinting()
                && movement.isPowerSprinting()
                && MovementStaminaHandler.hasMovementMode(player, MovementMode.POWER_SPRINT)
                && PlayerStaminaManager.getStamina(player) > 0;
    }

    private StaminaServerTick() {}
}