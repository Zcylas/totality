# Changed Files Manifest — Phase 4: Mana + Stamina Authority Migration (refreshed after the final external-review correction pass)

2026-09-15 (original pass), corrected 2026-09-15 (same day, final external-review correction pass).
Every file this task created or modified, repository-relative. This branch already carried
substantial uncommitted work from the pre-Phase-4 foundation pass and its own correction pass before
this task began — this manifest covers **only** files the Phase 4 task (both passes) touched.
**CORRECTED** marks a file the final correction pass touched again, on top of the original Phase 4 pass.

## ADDED — main sources (5)

| File | Why |
|---|---|
| `src/main/java/zcylas/totality/api/rpg/mana/ManaMaximumResolver.java` | Real `ResourceMaximumResolver` for `totality:mana` — delegates to `PlayerManaManager.getMaxMana`. |
| `src/main/java/zcylas/totality/api/rpg/stamina/StaminaMaximumResolver.java` | Same for `totality:stamina` / `PlayerStaminaManager.getMaxStamina`. |
| `src/main/java/zcylas/totality/api/rpg/resources/integration/PlayerBaselineResources.java` | The `totality:player_baseline` `GLOBAL_SYSTEM` grant provider and the first production `ResourceGrantReconciler` singleton. |
| `src/main/java/zcylas/totality/networking/resource/BaselineResourceLifecycleEvents.java` | **CORRECTED** — `migrateLegacyIfAbsent` rewritten to consult the new durable migration marker instead of Generic-state presence alone (correction Finding 2). |
| `src/main/java/zcylas/totality/api/rpg/resources/verification/BaselineResourceMigrationVerification.java` | **CORRECTED** — +1 dev-only check proving the state-loss-does-not-resurrect-stale-legacy scenario (now 11 checks, was 10). |

## ADDED — test sources (3, one new this correction pass)

| File | Why |
|---|---|
| `src/test/java/zcylas/totality/api/rpg/resources/PlayerResourceStateComponentDeathPolicyTest.java` | Proves `copyFrom` honors `ResourceDeathPolicy` for Mana/Stamina/Thirst. |
| `src/test/java/zcylas/totality/api/rpg/resources/PlayerResourceStateComponentLegacyMigrationMarkerTest.java` | **NEW this correction pass** — 5 tests for the migration marker's own storage/persistence/respawn-propagation contract, independent of `hasState`. |
| `src/test/java/zcylas/totality/api/rpg/resources/integration/PlayerBaselineResourcesTest.java` | Proves the real registered grant's exact shape. |

## MODIFIED — main sources (8, two additionally touched this correction pass)

| File | Why |
|---|---|
| `src/main/java/zcylas/totality/Totality.java` | One line: registers `BaselineResourceMigrationVerification`. |
| `src/main/java/zcylas/totality/api/rpg/mana/PlayerManaManager.java` | Full internal rewrite — compatibility facade over `PlayerResourceService`. |
| `src/main/java/zcylas/totality/api/rpg/stamina/PlayerStaminaManager.java` | Same, plus `onLongRest(ServerPlayer)`. |
| `src/main/java/zcylas/totality/api/rpg/resources/ProductionResourceDefinitions.java` | **CORRECTED** — original pass: authority flip, dropped authored maximum, `RESET_TO_MAXIMUM` lifecycle, `definitionVersion` 2, resolver/grant registration. Correction pass: Mana/Stamina `.capabilities(...)` corrected to canonical §25.4/§25.5's exact declared sets (correction Finding 1 — the original pass left them at the old Phase 2C transitional `HUD_VISIBLE`/`MENU_VISIBLE`-only shape). |
| `src/main/java/zcylas/totality/api/rpg/resources/PlayerResourceStateComponent.java` | **CORRECTED** — original pass: `copyFrom` death-policy consultation. Correction pass: stale class Javadoc rewritten (Finding 3 — still described Mana/Stamina as `EXTERNAL_ADAPTER`); new durable `legacyMigratedResourceIds` marker + `isLegacyMigrated`/`markLegacyMigrated`, NBT schema 3→4, `copyFrom` propagation (Finding 2). **Also touched by the separately-reported prior correction pass** — this task's diff is confined to what's described here. |
| `src/main/java/zcylas/totality/init/ModEvents.java` | Registers `BaselineResourceLifecycleEvents.register()` at an ordering-critical position. |
| `src/main/java/zcylas/totality/init/events/PlayerConnectionEvents.java` | Registers a Stamina Long-Rest listener. |
| `src/main/java/zcylas/totality/networking/mana/ManaServerTick.java` | Comment-only. |
| `src/main/java/zcylas/totality/networking/stamina/StaminaServerTick.java` | Removed one genuinely-redundant re-clamp line. |
| `src/main/java/zcylas/totality/client/resource/parity/ClientResourceParityInspectionCommand.java` | Doc-comment only. |

## MODIFIED — test sources (4, one additionally touched this correction pass)

| File | Why |
|---|---|
| `src/test/java/zcylas/totality/api/rpg/resources/PlayerResourceRegistryTest.java` | **CORRECTED** — original pass: split/rewrote tests for the `GENERIC_COMPONENT` authority shape. Correction pass: the old single wrong-capability test (`productionManaAndStaminaDeclareExactlyHudVisibleAndMenuVisibleCapabilities`, still pinning the pre-correction capability set) replaced by two tests pinning the corrected canonical §25.4/§25.5 sets. |
| `src/test/java/zcylas/totality/api/rpg/resources/PlayerResourceRegistryExternalAdapterFreezeTest.java` | Unchanged since the original pass. |
| `src/test/java/zcylas/totality/api/rpg/resources/PlayerResourceStateComponentExternalEntryPathTest.java` | Unchanged since the original pass. |
| `src/test/java/zcylas/totality/api/rpg/resources/PlayerResourceStateComponentExternalSafetyTest.java` | Unchanged since the original pass. |

## DELETED

None.

## Included for context (not code changes)

| File | Why |
|---|---|
| `Context/Audit/TOTALITY_GENERIC_PLAYER_RESOURCE_API_PHASE4_MANA_STAMINA_IMPLEMENTATION_REPORT_2026-09-15.md` | The full implementation report, now including §26-29: "Final External Review Corrections," tests added, final status lines, and the manual validation checklist. |
| `REVIEW_GIT_DIFF.patch` | Plain-text `git diff` covering exactly the 22 files above (8 added + 14 modified), refreshed to include every correction-pass change. |
| `REVIEW_SUMMARY.md` | Reviewer-facing summary (this bundle's sibling file), refreshed with the correction pass's outcome. |
