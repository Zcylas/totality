# Class Tab Quick Level-Up — Review Baseline

- `git rev-parse HEAD` at task start (and unchanged throughout every pass, since nothing was committed): `ab398b17dcce74a589d75dbb6946d4fc62612125` — "feat(resources): migrate rage to generic resource authority".
- `git status --short` at task start: 109 dirty paths, none staged. Snapshot: `git_status_short_baseline.txt` in this ZIP.
- Two of those 109 sit directly on files this task's audits had to read: `src/main/java/zcylas/totality/api/rpg/classes/ClassLevelUpRegistry.java` and `src/main/java/zcylas/totality/api/rpg/classes/PlayerClassComponent.java`, each carrying a pre-existing, unrelated bug fix (a per-class-level-source fix and a class-points-formula off-by-one fix, respectively).

## This revision covers two passes over the same still-uncommitted work

1. **Original "+" button pass** — added the Class Tab quick level-up button, plus (as approved scope expansion required by an audit finding) the fix for a pre-existing bug where subclass selection reached via ordinary leveling was silently discarded.
2. **Continuation pass** — a design review found the subclass storage model itself (one global `subclassId` per player) could not support multiclass characters each having their own subclass per owned class. Migrated storage to `Map<classId, subclassId>`, fixed every consumer, added legacy-save migration, normalized Wizard's subclass milestone to class level 3, and preserved Warlock's current provisional behavior unchanged.

## Pre-existing dirty files: what changed and what didn't

- **`ClassLevelUpRegistry.java`** — **not touched by either pass.** Verified byte-identical to its pre-task diff after every edit in both passes.
- **`PlayerClassComponent.java`** — **not touched by the original "+" button pass.** The continuation pass *does* touch this file (it is the authoritative subclass-storage owner and could not be avoided), but only in regions disjoint from the pre-existing fix. `PlayerClassComponent.pre-existing.diff` in this ZIP is the exact diff captured **before** the continuation pass touched anything; it lives entirely inside `toClassLevel(int)`/`getClassLevel(int)`/`getAvailableClassPoints(int)`. The continuation pass's own edits live in the field declaration, the "Subclass & Covenant" section, `selectClass`/`selectSubclass`, `writeSyncPacket`/`applySyncPacket`, `writeData`/`readData`, and `copyFrom`/`resetClass` — entirely separate regions. The file as included in this ZIP (`src/main/java/zcylas/totality/api/rpg/classes/PlayerClassComponent.java`) is its **current full working-tree state** (both the pre-existing fix and this task's migration, still uncommitted together); `REVIEW_GIT_DIFF.patch`'s hunks for this file can be cross-referenced against `PlayerClassComponent.pre-existing.diff` to see exactly which hunks pre-date this task (2 of the resulting hunks) versus which are new (the rest) — prepared for partial staging at commit time, the same technique already used for a different file in the Rage Phase 5 milestone commit.

No other file in this ZIP had any pre-existing diff before either pass — every other included file's diff is entirely attributable to this task.
