# Class Tab Quick Level-Up — Changed Files

## ADDED

| File | Pass | Reason |
|---|---|---|
| `src/main/java/zcylas/totality/networking/classes/SelectSubclassPayload.java` | Original | New client→server payload for applying a subclass to an already-owned class. |
| `src/main/java/zcylas/totality/networking/classes/SelectSubclassHandler.java` | Original, modified in Continuation | Server-authoritative handler; `apply(...)` is the pure, package-visible, directly-testable validation+apply core. Continuation pass re-scopes its rejection check from global `hasSubclass()` to per-class `hasSubclass(classId)`. |
| `src/test/java/zcylas/totality/networking/classes/SelectSubclassHandlerTest.java` | Original, rewritten in Continuation | Executing unit tests; rewritten for the per-class API plus 3 new multiclass-specific scenarios. |
| `src/test/java/zcylas/totality/screen/classes/ConfirmClassScreenSubclassRoutingSourceRegressionTest.java` | Original | 4 source-text sentinels pinning the `ConfirmClassScreen` routing fix. Unaffected by the Continuation pass. |
| `src/test/java/zcylas/totality/screen/character/tabs/ClassTabQuickLevelUpSourceRegressionTest.java` | Original | 5 source-text sentinels pinning the "+" button's structural guarantees. Unaffected by the Continuation pass. |
| `src/test/java/zcylas/totality/api/rpg/classes/PlayerClassComponentSubclassMigrationTest.java` | Continuation | 13 executing tests: storage/query API, NBT persistence round-trip, legacy migration, sync-packet round-trip. |
| `src/test/java/zcylas/totality/api/rpg/classes/ClassSubclassMilestoneNormalizationTest.java` | Continuation | 5 tests: executing assertions on the three classes' `subclassUnlockClassLevel()`, plus source-text sentinels on their handlers. |
| `Context/Audit/TOTALITY_CLASS_TAB_QUICK_LEVEL_UP_IMPLEMENTATION_2026-09-16.md` | Both | This task's implementation report, amended in place by the Continuation pass. |

## MODIFIED — Original "+" button pass, unaffected by Continuation

| File | What changed |
|---|---|
| `src/main/java/zcylas/totality/Totality.java` | Registers `SelectSubclassHandler.register()` (1 line). |
| `src/main/java/zcylas/totality/networking/TotalityPackets.java` | Registers `SelectSubclassPayload` on the serverbound channel (1 import + 1 line). |
| `src/main/java/zcylas/totality/screen/classes/ConfirmClassScreen.java` | CONFIRM branch routes an already-owned class's subclass choice to `SelectSubclassPayload`, checked before the two pre-existing branches. |

## MODIFIED — touched by the Continuation pass (per-class subclass migration)

| File | What changed |
|---|---|
| `src/main/java/zcylas/totality/api/rpg/classes/PlayerClassComponent.java` | **Partial pre-existing overlap — see `REVIEW_BASELINE.md`.** Storage migrated from `@Nullable Identifier subclassId` to `Map<Identifier, Identifier> subclassIds`; new per-class API (`getSubclassId(classId)`, `hasSubclass(classId)`, `selectSubclass(classId, id)`, `getAllSubclassIds()`); `writeSyncPacket`/`applySyncPacket`/`writeData`/`readData`/`copyFrom`/`resetClass`/`selectClass` all updated; `readData` gained one-time legacy-format migration (infers owning class via `SubclassRegistry`). |
| `src/main/java/zcylas/totality/api/rpg/classes/ClientClassManager.java` | Same migration, client-side mirror; `apply(...)`'s second parameter is now `Map<Identifier, Identifier>` instead of `@Nullable Identifier`; `getSubclassId(classId)`/`hasSubclass(classId)`/`getSubclassData(classId)` replace the parameterless versions. |
| `src/main/java/zcylas/totality/api/rpg/classes/barbarian/BarbarianClass.java` | `ClassLevelUpRegistry` handler: `hasSubclass()` → `hasSubclass(TotalityClasses.BARBARIAN_ID)`; milestone comparison now reads `DATA.subclassUnlockClassLevel()` instead of the literal `3`. |
| `src/main/java/zcylas/totality/api/rpg/classes/monk/MonkClass.java` | Same as Barbarian, for Monk. |
| `src/main/java/zcylas/totality/api/rpg/classes/wizard/WizardClass.java` | Same as Barbarian, for Wizard — **plus** `DATA`'s `subclassUnlockClassLevel` normalized from `2` to `3`. |
| `src/main/java/zcylas/totality/networking/classes/SelectClassHandler.java` | `comp.selectSubclass(subclassId)` → `comp.selectSubclass(classId, subclassId)` (first-time selection path). |
| `src/main/java/zcylas/totality/screen/character/tabs/ClassTab.java` | Identity panel now queries the primary class's own subclass (`getSubclassData(classData.id())`); the multiclass row list (added in the Original pass) now also shows each class's own subclass name on a second line beneath its level. The "+" button logic itself is unchanged. |
| `src/main/java/zcylas/totality/screen/character/BaseCharacterScreen.java` | Character-summary subclass line now queries the primary class's subclass explicitly. |
| `src/main/java/zcylas/totality/screen/character/tabs/OverviewTab.java` | Same fix as `BaseCharacterScreen.java`, for the Overview tab's identity block. |
| `src/test/java/zcylas/totality/client/resource/parity/LegacyClientResourceParityReadersTest.java` | 3 call sites: `ClientClassManager.apply(Map.of(), null, null)` → `ClientClassManager.apply(Map.of(), Map.of(), null)` — a required fix once `apply`'s second parameter became a `Map` (caught by the full test suite as a `NullPointerException`, not found manually). No pre-existing diff on this file before this fix — the file was clean at both task starts. |

## Not overlapping / not touched

`ClassLevelUpRegistry.java` — already dirty at baseline, read during both audits — received **zero** edits from either pass. See `REVIEW_BASELINE.md`.

`WarlockClass.java`, `ClassSelectionScreen.java`, `SubclassSelectionScreen.java` — audited and confirmed to need **no changes** (Warlock's subclass usage was already genuine, distinct from Covenant; the two selection screens never call the mutated getters/setters directly).

## Not included in this ZIP

The remaining ~107 baseline-dirty paths, plus `ClassLevelUpRegistry.java`'s own pre-existing diff (referenced via `ClassLevelUpRegistry.pre-existing.diff` for context only, since it was read but never edited) — unrelated to this task.
