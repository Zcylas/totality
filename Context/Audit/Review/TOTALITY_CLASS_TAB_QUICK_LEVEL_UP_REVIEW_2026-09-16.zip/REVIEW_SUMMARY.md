# Class Tab Quick Level-Up — Review Summary

## What this does (both passes combined)

Adds a small, generic "+" button beside every owned class's level display in the Class Tab, reusing the existing server-authoritative `AddClassLevelPayload`/`AddClassLevelHandler`/`ClassLevelUpRegistry` path unchanged. While auditing that flow, a pre-existing bug was found and fixed (subclass choices reached via ordinary leveling were silently discarded — see the implementation report §3). A subsequent design review found the subclass *storage model itself* was wrong for multiclassing: one global subclass slot per player could not represent a Barbarian subclass and a Wizard subclass existing on the same character simultaneously. This revision migrates subclass storage to `Map<classId, subclassId>`.

## Per-class subclass migration (this revision's new work)

- **Storage:** `PlayerClassComponent`'s single `@Nullable Identifier subclassId` field became `Map<Identifier, Identifier> subclassIds`, with a new class-keyed API (`getSubclassId(classId)`, `hasSubclass(classId)`, `selectSubclass(classId, id)`). The old parameterless methods were removed entirely (not deprecated) — the full consumer set was small and closed, so complete migration was safer than ambiguous parallel APIs.
- **Consumer audit:** every production reference to subclass state was found and migrated: `PlayerClassComponent`, `ClientClassManager` (client mirror), the three `ClassLevelUpRegistry` handlers (`BarbarianClass`/`MonkClass`/`WizardClass`), `SelectClassHandler`, `SelectSubclassHandler`, `ClassTab`, `BaseCharacterScreen`, `OverviewTab`. `ClassSelectionScreen`/`SubclassSelectionScreen`/`ConfirmClassScreen` needed no change (they never call the mutated getters/setters directly).
- **Legacy save migration:** the old single `"SubclassId"` NBT key is inferred onto its real owning class via `SubclassRegistry.get(id).parentClassId()` on load, exactly once; the new format is written from then on and the old key is never written again, making the migration naturally idempotent. An unresolvable legacy id migrates nothing rather than guessing.
- **Client sync:** the sync packet now carries the whole class→subclass map; the Class Tab's multiclass row list shows each class's own subclass beneath its own level line, never another class's.
- **`SelectSubclassHandler`:** its rejection check is now scoped to the target class only (`hasSubclass(classId)`) — a Barbarian subclass no longer blocks a Wizard subclass choice on the same character.
- **Wizard normalization:** `WizardClass`'s subclass milestone moved from class level 2 (stale) to class level 3, matching Barbarian/Monk (D&D 2024-style). Each class's handler now compares against its own `DATA.subclassUnlockClassLevel()` instead of a re-typed literal, preventing this exact drift from recurring.
- **Warlock:** audited directly before assuming anything, per instruction. Confirmed Warlock's subclass field already holds genuine subclass data (Hexblade/Archfey), completely separate from its own Covenant/Patron field — no architecture question was raised, no redesign was needed. Warlock received only the same mechanical per-class-map migration every other class needed.

## What this deliberately does NOT do

- No Spell Slot migration, no Rage/Mana/Stamina resource authority changes, no Phase 6 work.
- No feat work, no class balance/subclass content redesign, no confirmation-popup UI.
- No Warlock redesign, no Covenant/Patron changes, no Pact Boon/Pact Magic implementation.
- No commit, no push, no staging of unrelated files.

## Validation performed

- `./gradlew compileJava` / `compileTestJava` — clean.
- Full `./gradlew test` — **1578 tests, 0 failures, 0 errors** (39 new/changed tests across both passes).
- `./gradlew clean build` — `BUILD SUCCESSFUL`.
- `git diff --check` on every file touched by either pass — no whitespace errors.
- Bounded `./gradlew runServer` (~100s, re-run after the continuation pass) — reached `Done`, every Totality self-test suite passed including `BarbarianRageMigrationVerification` (13/13, confirming the class-level-up-to-Rage-maximum integration still works after the storage format change). Only the same pre-existing, unrelated `OffhandAttackVerification` failure observed.

See the implementation report (`Context/Audit/TOTALITY_CLASS_TAB_QUICK_LEVEL_UP_IMPLEMENTATION_2026-09-16.md`, §9 for the full per-class migration writeup) and `REVIEW_CHANGED_FILES.md` for the exact file-by-file breakdown across both passes.

## Final status

- Existing subclass progression bug: **FIXED**
- Per-class subclass storage: **COMPLETE**
- Legacy subclass migration: **PASS**
- Wizard subclass now level 3: **YES**
- Barbarian/Monk subclass level 3: **PRESERVED**
- Warlock provisional behavior: **PRESERVED**
- Barbarian + Wizard simultaneous subclasses: **PASS**
- Class Tab "+" regression: **PASS**
- Existing Class Screen regression: **PASS**
- Right-side owned-class list scrolling (separate follow-up, see `TOTALITY_CLASS_TAB_MULTICLASS_SCROLL_FIX_IMPLEMENTATION_2026-09-16.md`): **COMPLETE**
- Full tests: **1578/1578** (1588/1588 including the scrolling follow-up's own tests)
- **Manual validation (Stefan, in-game): PASS** — Wizard leveling via "+", Wizard subclass milestone selection, clean-world multiclassing, independent per-class subclass state, right-side list scrolling with previously-hidden classes reachable, disabled/non-highlighted "+" when no points remain, and dimension-change persistence all confirmed.
- Safe to commit: **YES** (this documentation update; the commit itself is a separate, already-approved step)
- Phase 6 started: **NO**

### Separately discovered, deliberately NOT fixed here

Manual testing on an **old** test-world character (previously Barbarian ~level 18, ~6 Rage) reproduced a server crash in `ResourceScalarWireSnapshot` after `/totality resetall` → `showclass` → rebuilding as Wizard → later multiclassing back into Barbarian — consistent with stale class-owned Generic Resource state (old Rage) surviving the reset path while the new Barbarian resolves a lower maximum. A clean-world multiclass test (no prior resetall/showclass history) does not reproduce this. This is **not** a defect in the per-class subclass/Class Tab work in this ZIP, and is explicitly deferred to a separate future "universal class-change reconciliation" task covering Rage and future class-owned resources (Ki, Pact Magic). Nothing related to `resetall`, `showclass`, Rage, or Generic Resource reconciliation was changed here.
