# Baseline

- Branch: `feature/general-resource-api`
- HEAD before this task: `501ddfbffa5dad545ecaf701ffde78673a5ed3a0`
  (`feat(resources): migrate standard spell slots to generic authority`)
- HEAD after this task: recorded post-commit in the final response — this bundle documents the
  working-tree state immediately before either commit.
- `git status --short` at the start of this task: **109 dirty paths**, all pre-existing/unrelated
  (see `git_status_short_baseline.txt` in this bundle). None were cleaned, reset, or absorbed.
- Exactly **11 new dirty paths** appeared since this task began — verified by sorting the full
  current `git status --short` path list and diffing it against a path list captured before any
  edit in this task: the diff is precisely this bundle's 11 files (10 code/verification files + this
  report), no more, no less. No unrelated file was touched.

## Baseline capture commands run before any edits

```
git rev-parse HEAD
git branch --show-current
git status --short
git diff --stat
```

`git diff --cached` was empty (nothing staged) at baseline.

## Scope confirmation

Neither fix touches `PlayerResourceService`, `ClassChangeReconciler`, `MaximumChangePolicy`, or any
other Generic Resource API internals — both call existing public APIs exactly as every other caller
already does (`PlayerResourceService.trySpend`/`.query` for Crown of Stars, unchanged;
`RollModifierRegistry`'s new methods mirror its existing `getSaveBonusList`/`resolveSaveBonusList`
pair exactly for the Ability Check fix).

The two fixes are structurally independent — no file is required by both:

- **Crown of Stars**: `Spell.java`, `CrownOfStarsSpell.java`, `ActivateAbilityHandler.java`,
  `CrownOfStarsActiveInstanceActionVerification.java` (new), `Totality.java` (its one new
  registration line).
- **Ability Check bonus routing**: `RollModifierRegistry.java`, `DialogueSessionManager.java`,
  `RollModifierRegistryCheckBonusChannelTest.java` (new),
  `DialogueSessionManagerCheckBonusRoutingSourceRegressionTest.java` (new),
  `BlessLifecycleSourceRegressionTest.java`.

No partial/selective hunk staging was required for either commit — every file above belongs
entirely to one fix or the other.
