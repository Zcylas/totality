# Review summary — Crown of Stars mote-fire fix & dialogue Ability Check bonus routing fix

Two small, independent post-Phase-6 investigations and fixes, performed on top of HEAD
`501ddfbffa5dad545ecaf701ffde78673a5ed3a0`.

## Issue 1 — Crown of Stars

**Confirmed real** on current HEAD, traced through the actual code (not assumed): firing an
already-summoned mote went through the exact same `ActivateAbilityHandler.handle` path as a
brand-new cast, with no seam distinguishing the two. If the initial cast used the player's last
7th-level slot, firing a mote was silently rejected (motes permanently stranded); if a slot was
still available, firing a mote incorrectly consumed it too. `SpellBoltEntity` (the projectile) was
confirmed NOT at fault.

**Fix:** a new `Spell.isActiveInstanceAction(ServerPlayer)` virtual method, default `false`
(zero behavior change for every other spell); `CrownOfStarsSpell` overrides it via its own existing
`hasMotes(UUID)` helper; `ActivateAbilityHandler` computes one `chargesSlot` boolean before
`onActivate` runs and gates both the pre-check and the spend on it, so they can never disagree. No
`if (spell instanceof CrownOfStarsSpell)` hack, no change to `PlayerResourceService` or any other
Generic Resource code.

See the implementation report's §1 for the full root-cause trace and the 11-check dev-server
verification.

## Issue 2 — Dialogue Ability Check bonus routing

**Confirmed real** on current HEAD (verified directly, not assumed from the older snapshot
referenced in the task): `DialogueSessionManager.handleChoice` built every dialogue roll's bonus
list via `RollModifierRegistry.resolveSaveBonusList` unconditionally — including for genuine Ability
Checks like the Banker's Persuasion check — so Bless's +1d4 (D&D 5e: attack rolls and saving throws
only, never Ability Checks) incorrectly applied to dialogue Ability Checks. No dedicated Ability
Check bonus-list mechanism existed anywhere in the codebase for dialogue to have used instead — one
needed to be added.

**Fix:** a new `getCheckBonusList`/`resolveCheckBonusList` pair on `RollModifierRegistry`, mirroring
the existing `getSaveBonusList`/`resolveSaveBonusList` pair exactly (default `List.of()`);
`DialogueSessionManager.handleChoice` now calls `resolveCheckBonusList` instead of
`resolveSaveBonusList`. `BlessEffect` needed zero changes — it already only overrides the
attack/save lists, so it correctly contributes nothing to the new check channel by default.
`modifyCheck`/`RollMode` (advantage/disadvantage) is a separate, untouched mechanism.

See the implementation report's §2 for the full investigation (5 questions answered with file:line
evidence) and the real, executing `RollModifierRegistryCheckBonusChannelTest` coverage.

## Test/build evidence

- `./gradlew test` (full suite): **1620 tests, 0 failures, 0 errors** (was 1611 before this task —
  +9: 7 `RollModifierRegistryCheckBonusChannelTest` + 1
  `DialogueSessionManagerCheckBonusRoutingSourceRegressionTest` + 1 `BlessLifecycleSourceRegressionTest`
  addition; Crown of Stars has no plain-JUnit unit tests since it is dev-server-verification-only,
  matching every other real-`ServerPlayer`-requiring spell/resource fix in this codebase).
- `./gradlew clean build`: **BUILD SUCCESSFUL.**
- `git diff --check`: clean (only benign pre-existing CRLF-normalization warnings).
- Bounded dedicated-server run (`runServer_bounded_verification.log`):
  **`[CrownOfStarsActiveInstanceActionVerification] All 11 self-test checks passed.`** (new).
  `[ResourceFoundationVerification] All 6`, `[BaselineResourceMigrationVerification] All 11`,
  `[BarbarianRageMigrationVerification] All 18`, `[StandardSpellSlotMigrationVerification] All 23`
  (all unchanged — confirms neither fix disturbed the Generic Resource API). The same two unrelated,
  pre-existing verification failures (`ProvisionerEntityBackedSmokeTest` 3/4 FAIL,
  `OffhandAttackVerification` 3/5 FAIL) appeared again, identically — not touched by this task.

## Manual testing — NOT performed

Neither fix's manual test sequence (Crown of Stars: cast with the last 7th-level slot, fire a mote,
confirm it works and the slot stays at 0; Banker dialogue: apply Bless, choose Persuasion, confirm
the roll breakdown excludes Bless) has been performed by a human or a real playable client. This
bundle and the implementation report do not claim manual PASS for either fix.

## Isolating this task's diff

Exactly 11 new dirty paths appeared since this task began (verified by diffing the full current
`git status --short` path list against one captured before any edit in this task) — precisely this
bundle's file set, no more, no less. No file is shared between the two fixes; no partial/selective
hunk staging was required for either commit. The 109 unrelated pre-existing dirty paths were
untouched throughout.

## Files in this bundle

See `REVIEW_CHANGED_FILES.md` for the full list and per-file description. See
`TOTALITY_CROWN_OF_STARS_AND_DIALOGUE_ABILITY_CHECK_BONUS_FIXES_2026-09-16.md` for the complete
investigation, root-cause trace, and design rationale for both issues.
