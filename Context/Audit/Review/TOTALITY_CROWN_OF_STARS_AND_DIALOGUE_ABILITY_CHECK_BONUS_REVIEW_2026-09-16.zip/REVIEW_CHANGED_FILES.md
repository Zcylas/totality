# Changed files (task-owned only)

Two independent fixes; each file belongs entirely to one.

## Issue 1 — Crown of Stars active-instance-action fix

**Modified:**
- `src/main/java/zcylas/totality/api/magic/spell/Spell.java` — new
  `isActiveInstanceAction(ServerPlayer)`, default `false`.
- `src/main/java/zcylas/totality/api/magic/spell/destruction/CrownOfStarsSpell.java` — overrides
  `isActiveInstanceAction` via its existing public `hasMotes(UUID)`.
- `src/main/java/zcylas/totality/networking/ability/ActivateAbilityHandler.java` — a single
  `chargesSlot` boolean, computed once before `onActivate` runs, gates both the slot pre-check and
  the post-cast spend (previously two separate `!spell.isCantrip()` checks that could disagree).
- `src/main/java/zcylas/totality/Totality.java` — registers the new verification (one added line).

**New:**
- `src/main/java/zcylas/totality/api/rpg/resources/verification/CrownOfStarsActiveInstanceActionVerification.java`
  — dev-server-gated self-test, 11 checks, mirrors `StandardSpellSlotMigrationVerification`'s
  established pattern (real `ServerPlayer` via `TotalityFakePlayer`, real
  `ActivateAbilityHandler.handle` calls, real `totality:spell_slots` Generic Resource queries).

## Issue 2 — Dialogue Ability Check bonus routing fix

**Modified:**
- `src/main/java/zcylas/totality/api/rpg/combat/RollModifierRegistry.java` — new
  `RollModifier.getCheckBonusList`/`checkBonus` (mirrors `getSaveBonusList`/`saveBonus` exactly, default
  `List.of()`); new `resolveCheckBonusList`/`resolveCheckBonus` static methods (mirror
  `resolveSaveBonusList`/`resolveSaveBonus`); new UUID-keyed test-only hooks
  (`resolveSaveBonusListForTest`, `resolveCheckBonusListForTest`, `resolveCheckModeForTest`).
- `src/main/java/zcylas/totality/api/dialogue/DialogueSessionManager.java` — `handleChoice`'s
  dialogue-roll bonus list now calls `resolveCheckBonusList` instead of `resolveSaveBonusList` (every
  dialogue roll is an Ability Check, never a Saving Throw).
- `src/test/java/zcylas/totality/effect/BlessLifecycleSourceRegressionTest.java` — +1 sentinel test
  confirming `BlessEffect` does not override `getCheckBonusList`.

**New:**
- `src/test/java/zcylas/totality/api/rpg/combat/RollModifierRegistryCheckBonusChannelTest.java` — 7
  real, executing tests proving attack/save/check bonus channels are independent.
- `src/test/java/zcylas/totality/api/dialogue/DialogueSessionManagerCheckBonusRoutingSourceRegressionTest.java`
  — source-regression sentinel confirming `handleChoice` calls `resolveCheckBonusList` and no longer
  calls `resolveSaveBonusList`.

**`BlessEffect.java` itself was not changed** — it already only overrides
`getAttackBonusList`/`getSaveBonusList`; the new `getCheckBonusList` default correctly excludes it
from Ability Checks with zero edits.

## Documentation

- `Context/Audit/TOTALITY_CROWN_OF_STARS_AND_DIALOGUE_ABILITY_CHECK_BONUS_FIXES_2026-09-16.md` (new)
  — covers both investigations, clearly separated into two top-level sections.
