# Class Tab Multiclass Scroll Fix — Review Summary

## Root cause

The right-side/multiclass owned-class list in `ClassTab`'s progression panel was drawn with an unconditional cursor advance and no scroll offset or clamped viewport — a single, unscrolled clip region covered the whole right column (header, SPEND CLASS POINT button, and list together). With four or more owned classes, rows past the second or third simply rendered below the visible box with correctly-computed but unreachable "+" hitboxes. The LEFT column (weapon/armor/save proficiencies), a few lines above in the same method, already scrolls correctly via `progScroll`; the right column's list never received the same treatment when it was added.

## Fix

Mirrors the left column's existing pattern exactly: a new `mcListScroll` offset field, new `mcListPanelX/Y/W/H` viewport fields scoped to just the list (the header/button area above keeps its own separate, unscrolled clip), and a new pure `measureOwnedClassListContentHeight()` helper used to clamp the scroll on both ends — both every frame in `draw()` (so a content-height change is corrected immediately) and again in `mouseScrolled()`. A row scrolled outside the list's viewport is still drawn (harmlessly invisible under the GL scissor) but is excluded from click handling via a `fullyVisible` check folded into its stored `enabled` flag — `mouseClicked` itself required no changes. The multiclass list's viewport is checked before the wider left-column region in `mouseScrolled`, so the two scroll independently without needing to touch the left column's own existing bounds.

No new scrolling framework, no broad refactor, no changes to class progression, subclass storage, networking, resource, or server-authority code.

## Validation

- `./gradlew compileJava` / `compileTestJava` — clean.
- Full `./gradlew test` — **1588 tests, 0 failures, 0 errors** (10 new tests).
- `./gradlew clean build` — `BUILD SUCCESSFUL`.
- `git diff --check` — no whitespace errors.
- No networking/component registration changed, so no dedicated-server run was required.

See the implementation report (`Context/Audit/TOTALITY_CLASS_TAB_MULTICLASS_SCROLL_FIX_IMPLEMENTATION_2026-09-16.md`) for full detail and the manual test checklist.

## Final status

- Right-side owned-class list scrolling: **COMPLETE**
- Left-side scrolling regression: **PASS**
- "+" button / `AddClassLevelPayload` regression: **PASS**
- Class progression / subclass / resource / server-authority logic touched: **NO**
- Full tests: **1588/1588**
- Safe for manual testing: **YES**
- Safe to commit: **NO — wait for Stefan manual test/review**
