# Class Tab Multiclass Scroll Fix — Changed Files

## MODIFIED

| File | What changed |
|---|---|
| `src/main/java/zcylas/totality/screen/character/tabs/ClassTab.java` | Added independent scrolling for the right-side/multiclass owned-class list: new `mcListScroll` offset field (mirrors `progScroll`), new `mcListPanelX/Y/W/H` viewport fields (mirrors `progPanelX/Y/W/H`, scoped to only the list portion of the right column), a new pure `measureOwnedClassListContentHeight()` helper, two-sided clamping in both `draw()` and `mouseScrolled()`, and an off-viewport visibility check folded into each `QuickLevelButton`'s stored `enabled` flag so a scrolled-away row's "+" can never remain clickable at its raw off-screen coordinates. `onOpen()` now also resets `mcListScroll`. The CLASS LEVEL header and SPEND CLASS POINT button keep their own unchanged, un-scrolled clip region exactly as before; only the list below them is newly scrollable. |

## ADDED

| File | Reason |
|---|---|
| `src/test/java/zcylas/totality/screen/character/tabs/ClassTabMulticlassScrollSourceRegressionTest.java` | 10 source-text sentinels pinning the scroll-offset field, two-sided clamping (both in `draw()` and `mouseScrolled()`), content-height-driven max-scroll recomputation, shared render/click cursor, off-viewport click exclusion, independent left/right scroll regions, `onOpen` reset, the unchanged `AddClassLevelPayload` path, and the untouched left-column scrolling. |

## Included for context, not modified

| File | Reason |
|---|---|
| `src/test/java/zcylas/totality/screen/character/tabs/ClassTabQuickLevelUpSourceRegressionTest.java` | Pre-existing test from the prior Class Tab task, re-run and confirmed still passing unmodified after this fix — included so a reviewer can see it was not broken by this change. |

## Not touched

No class progression, subclass storage, networking payload/handler, resource, or server-authority file was touched by this task. `PlayerClassComponent.java` and `ClassLevelUpRegistry.java` (the two genuinely unrelated pre-existing dirty files documented in the prior task's own review material) are unaffected and not included here.
