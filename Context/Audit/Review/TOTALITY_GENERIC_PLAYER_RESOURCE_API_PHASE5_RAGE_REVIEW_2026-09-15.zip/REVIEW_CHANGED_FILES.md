# Phase 5 Review — Changed Files

Legend: **ADDED** = new file, did not exist at baseline. **MODIFIED** = existing tracked file, edited. **MODIFIED (pre-existing diff, zero Phase 5 edits)** = tracked file that appears dirty solely because of the baseline's own pre-existing uncommitted diff (see `REVIEW_BASELINE.md`) — this task did not touch it. Each entry also notes whether it was touched by the **original Phase 5 pass** or the subsequent **External Review Corrections pass** (§24 of the implementation report).

## ADDED

| File | Pass | Reason |
|---|---|---|
| `src/main/java/zcylas/totality/api/ability/impl/barbarian/RageMaximumResolver.java` | Original | New `ResourceMaximumResolver` delegate for `totality:rage`, mirroring `ManaMaximumResolver`/`StaminaMaximumResolver`. |
| `src/main/java/zcylas/totality/api/rpg/resources/integration/BarbarianRageResources.java` | Original | New `BarbarianClass -> totality:rage` `CLASS` grant provider + reconciler, mirroring `PlayerBaselineResources`. |
| `src/main/java/zcylas/totality/api/rpg/resources/verification/BarbarianRageMigrationVerification.java` | Original, extended in Corrections | New dev-only end-to-end self-test, mirroring `BaselineResourceMigrationVerification`. Extended by the Corrections pass with 5 more checks (finding 1: level-up-across-threshold; finding 4: real `onActivate` end-to-end; finding 5: non-Barbarian no-grant, exactly-one-state-entry, reconciliation-does-not-refill). |
| `src/test/java/zcylas/totality/api/rpg/resources/integration/BarbarianRageResourcesTest.java` | Original | New unit test for `BarbarianRageResources`'s grant shape and null-player safety. |
| `src/test/java/zcylas/totality/api/ability/impl/barbarian/BarbarianRageAbilityMaximumSyncSourceRegressionTest.java` | Corrections (finding 1) | Source-text sentinels pinning that `updateChargePool` marks `totality:rage` dirty for the Generic sync path, and never mutates current merely to force a sync. |
| `Context/Audit/TOTALITY_GENERIC_PLAYER_RESOURCE_API_PHASE5_RAGE_IMPLEMENTATION_REPORT_2026-09-15.md` | Both | This task's implementation report, updated in place by the Corrections pass with a new §24 and corrected §14/§19/§20/§22 wording. |

## MODIFIED — entirely Phase-5-attributable

| File | Pass | What changed |
|---|---|---|
| `src/main/java/zcylas/totality/Totality.java` | Original | Registers `BarbarianRageMigrationVerification.register()` (1 line added). |
| `src/main/java/zcylas/totality/api/ability/impl/barbarian/BarbarianRageAbility.java` | Original, extended in Corrections | `canActivate`/`onActivate` routed through `PlayerResourceService`; `registerChargePool`/`updateChargePool` routed through `BarbarianRageResources`; new `getMaxRage`/`onShortRest`/`onLongRest` methods (original). `updateChargePool` also marks `totality:rage` dirty for the Generic sync path (Corrections, finding 1). |
| `src/main/java/zcylas/totality/api/rpg/resources/ProductionResourceDefinitions.java` | Original | `totality:rage` definition rewritten: `GENERIC_COMPONENT` authority (no `.externalAdapter(...)`), canonical §25.6 capability set, `definitionVersion` 2; `registerMaximumResolvers`/`registerGrants` extended; class Javadoc updated. |
| `src/main/java/zcylas/totality/api/rpg/resources/ResourceLifecyclePolicy.java` | Original | Stale Javadoc corrected — Rage removed from the "EXTERNAL_ADAPTER resources using DEFAULT for that structural reason" list, documented instead as GENERIC_COMPONENT deliberately choosing DEFAULT. |
| `src/main/java/zcylas/totality/init/events/PlayerConnectionEvents.java` | Original | Removed the legacy `ChargeComponents.PLAYER_CHARGES.onRest` `RestEventBus` registration (JOIN + AFTER_RESPAWN, dual-authority hazard); added a Generic-routed Rage Rest listener in both blocks. |
| `src/main/java/zcylas/totality/networking/resource/BaselineResourceLifecycleEvents.java` | Original | `migrateLegacyIfAbsent` extended with Rage's one-time legacy NBT import (reusing the existing marker mechanism); class Javadoc updated. |
| `src/main/java/zcylas/totality/TotalityClient.java` | Corrections (finding 3) | Rage legacy fallback readers (`legacyRageCurrent`/`legacyRageMax`) hardcoded to `return 0;`, no longer reading `ChargeComponents.PLAYER_CHARGES`; now-dead `ChargeComponents`/`ComponentProvider`/`BarbarianRageAbility` imports removed. |
| `src/main/java/zcylas/totality/screen/character/tabs/ClassTab.java` | Corrections (finding 3) | Same correction as `TotalityClient.java`; now-dead `BarbarianRageAbility`/`ComponentProvider` imports removed. |

## MODIFIED — partially Phase-5-attributable (pre-existing diff overlap)

| File | Phase-5-attributable portion | Pre-existing portion (see `REVIEW_BASELINE.md`) |
|---|---|---|
| `src/main/java/zcylas/totality/api/rpg/classes/PlayerChargesComponent.java` | Removal of the confirmed-dead, zero-caller `registerWithRestBus()` method only (Original pass; untouched by Corrections). | `applySyncPacket`'s existing-pool branch now adopts the server's maximum on sync; `toClassLevel(int)` delegates to `PlayerClassComponent.toClassLevel`. Both pre-date this task — see `PlayerChargesComponent.pre-existing.diff`. |

## MODIFIED (pre-existing diff, zero Phase 5 edits)

| File | Note |
|---|---|
| `src/test/java/zcylas/totality/api/rpg/classes/PlayerChargesRageCharacterizationTest.java` | Appears dirty in `git status` and in `REVIEW_GIT_DIFF.patch`, but neither the original Phase 5 pass nor the Corrections pass made any edits to it. Its entire diff is the pre-existing 4-test addition documented in `REVIEW_BASELINE.md` / `PlayerChargesRageCharacterizationTest.pre-existing.diff`. Included in this ZIP only for completeness, not as evidence of Phase 5 work. |

## MODIFIED — test files updated to reflect the new authority (entirely Phase-5-attributable, original pass)

Phase 2E registered `totality:rage` as `EXTERNAL_ADAPTER`-authority; several pre-existing unit tests hardcoded that assumption directly against the real production registry. This migration invalidates that assumption for Rage exactly the way Phase 4 already invalidated the same assumption for Mana/Stamina in these same files — every replacement below is a straight mirror of an already-existing Mana/Stamina test in the same file.

| File | What changed |
|---|---|
| `src/test/java/zcylas/totality/api/rpg/resources/PlayerResourceRegistryTest.java` | Removed Rage from the "remaining EXTERNAL_ADAPTER resources" list/tests; added `productionRageIsGenericComponentAuthorityAfterPhase5Migration`, `productionRageIsScalarGenericComponentResourceAfterPhase5Migration`, `rageDeclaresNoAuthoredMaximumAndBumpedDefinitionVersionAfterPhase5Migration`, `productionRageDeclaresExactlyItsCanonicalPhase5CapabilitySet`. `rageDeclaresContextualAccessPipsPresentation` (presentation shape, unchanged by the migration) was left as-is. |
| `src/test/java/zcylas/totality/api/rpg/resources/PlayerResourceRegistryExternalAdapterFreezeTest.java` | `productionRageDefinitionResolvesItsRegisteredAdapter` replaced with `productionRageDefinitionNoLongerReferencesAnAdapterAfterPhase5Migration` (mirrors the existing Mana/Stamina test of the same shape). `productionRageQueryOnANonServerPlayerReturnsStateUnavailableOnThisSideNotAnException`'s assertions are unchanged (the failure reason/id are identical for EXTERNAL_ADAPTER and GENERIC_COMPONENT with a null player) — only its comment was updated. |
| `src/test/java/zcylas/totality/api/rpg/resources/PlayerResourceStateComponentExternalEntryPathTest.java` | `nbtLoadingQuarantinesStaleGenericDataForRage`/`applyingASyncPayloadCannotCreateLiveRageGenericState` replaced with `nbtLoadingRestoresLiveGenericDataForRageAfterPhase5Migration`/`applyingASyncPayloadCreatesLiveRageGenericStateAfterPhase5Migration` (mirror the existing Mana/Stamina tests). The `externalSnapshotsAlwaysComeFromTheAdapterNeverFromGenericState` test's Rage assertion was removed with an explanatory comment pointing at the new registry test. |
| `src/test/java/zcylas/totality/api/rpg/resources/PlayerResourceStateComponentExternalSafetyTest.java` | `instantiateScalarRejectsRage`/`instantiatePartitionedRejectsRage` removed (their premise is no longer true), with a comment mirroring the existing Mana/Stamina removal precedent already documented in this same file. `isRegisteredExternalAdapterAuthorityIsTrueForAllFiveRemainingExternalAdapterProductionResources` renamed to `...AllFourRemaining...`, with Rage moved from the `assertTrue` list to the `assertFalse` list (alongside Mana/Stamina). |

## MODIFIED — External Review Corrections pass only

| File | Finding | What changed |
|---|---|---|
| `src/test/java/zcylas/totality/api/rpg/resources/client/presentation/Phase3CConsumerMigrationSourceRegressionTest.java` | 3 | Two new sentinel tests, `totalityClientLegacyRageFallbackNeverReadsTheLegacyChargeComponentMirror` and `classTabLegacyRageFallbackNeverReadsTheLegacyChargeComponentMirror`, pinning that both Rage legacy fallback methods are hardcoded to `return 0;` and never reference `ChargeComponents` again. |

## Not included in this ZIP

The remaining ~107 baseline-dirty paths (build.gradle, gradle.properties, datagen outputs, unrelated asset/class-progression/quest-HUD files, etc.) — unrelated to this task, untouched, and correctly excluded per the task's exclusion list.
