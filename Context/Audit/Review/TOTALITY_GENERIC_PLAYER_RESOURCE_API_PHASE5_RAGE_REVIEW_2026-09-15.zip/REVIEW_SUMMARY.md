# Phase 5 Review — Summary

## What this migration does

Moves the Barbarian Rage charge pool's authority from `PlayerChargesComponent` (legacy, mutated directly by `BarbarianRageAbility`) to the Generic Player Resource API (`PlayerResourceStateComponent` / `PlayerResourceService`), following the exact structural pattern the Phase 4 Mana/Stamina migration already established. See the implementation report for full detail; this ZIP's contents now reflect **two** passes: the original Phase 5 implementation, and a subsequent **External Review Corrections** pass.

## External Review Corrections (this revision)

External review of the first Phase 5 Review ZIP found one confirmed synchronization bug and raised four additional audit questions:

1. **Rage maximum change must sync to the Generic client — CONFIRMED + FIXED.** `updateChargePool` (called on class level-up) never marked `totality:rage` dirty for a maximum-only change, so a client could remain stuck at a stale maximum (e.g. 2/2) after the server resolved a higher one (2/3), until an unrelated mutation or full snapshot happened to catch up. Fixed with a single `ResourceSyncManager.markDirty(player.getUUID(), PlayerResourceIds.RAGE)` call, mirroring the exact mechanism `PlayerResourceRecalculator` already uses for Mana/Stamina's own maximum-only-change seam. `current` is never mutated to force this. Proven with a new source-text sentinel test plus 1 new `BarbarianRageMigrationVerification` end-to-end check (level-up across a `RAGE_CHARGES` threshold: current preserved, maximum increased).
2. **Rest listener priority — NOT ACTUALLY A BUG.** Every Rest listener registered in `PlayerConnectionEvents` (Abilities, Spell Slots, Stamina, and now Rage) is a lambda, which cannot override `RestListener`'s default priority — so the pre-migration "Rage before Abilities" ordering was already only a registration-order tie-break, and every Rest handler mutates a completely disjoint state store from every other one (cooldowns vs. spell slots vs. stamina vs. rage), so firing order has zero observable effect either way. No code change.
3. **Legacy Rage mirror/fallback for existing migrated players — CONFIRMED + FIXED.** An existing pre-Phase-5 Barbarian's legacy `PlayerChargesComponent` pool is frozen at migration time and never mutated again, but the legacy JOIN sync packet still sends it, arriving before the Generic full snapshot within the same tick — meaning the presentation-layer fallback could transiently display the stale frozen value during that narrow window. Fixed by hardcoding the Rage-specific legacy fallback readers in `TotalityClient`/`ClassTab` to always return 0 (matching the task's stated preference to disable the fallback rather than resume legacy mutation or add a new packet) — the worst case is now the same harmless "not yet synced" 0 every Generic-authoritative resource already shows. Proven with 2 new source-text sentinels.
4. **Migration verification wording — DOCUMENTATION/TEST WORDING FIXED, plus real coverage added.** A pre-existing verification check was reworded to accurately state it tests the authoritative `trySpend` path directly, not `BarbarianRageAbility.onActivate`; a new end-to-end check was added that exercises the real `onActivate` path and confirms exactly one charge is consumed.
5. **Non-Barbarian ownership sanity check — CONFIRMED (coverage added, no defect found).** The grant provider was already correctly class-gated; 3 new checks were added to the existing dev-only verification fixture proving non-Barbarian-gets-nothing, Barbarian-gets-exactly-one-state-entry, and repeated-reconciliation-does-not-refill.

The implementation report's §14 (legacy dimension-mirror bug disposition) was also corrected: the original wording incorrectly implied every player's legacy mirror "has nothing to go stale" — it now distinguishes brand-new post-migration Barbarians (no legacy pool at all) from already-migrated pre-Phase-5 Barbarians (a frozen, potentially-stale legacy pool that does physically exist, and was the actual subject of finding 3).

## What this migration still deliberately does NOT do

- Does not migrate Spell Slots, Mana, or Stamina.
- Does not add a new legacy dimension-change resync hook/packet.
- Does not rebalance any Rage gameplay number.
- Does not resume legacy Rage mutation, and does not remove `PlayerChargesComponent`.
- Does not commit, stage, or push anything.

## Validation performed (after the Corrections pass)

- `./gradlew compileJava` / `compileTestJava` — clean.
- Full `./gradlew test` — **1539 tests, 0 failures, 0 errors**.
- `./gradlew clean build` — `BUILD SUCCESSFUL`.
- `git diff --check` on every Phase 5 + Corrections file — no whitespace errors.
- Bounded `./gradlew runServer` (~100s), re-run after the corrections — reached `Done`, and `[BarbarianRageMigrationVerification]` reported **all 13 checks passed** (up from 8) against a real `ServerPlayer` and the real production registry. The only failures observed (`ProvisionerEntityBackedSmokeTest`, `OffhandAttackVerification`) are pre-existing, unrelated, and match the exact failure text already documented in the Phase 4 report.

See the implementation report (`Context/Audit/TOTALITY_GENERIC_PLAYER_RESOURCE_API_PHASE5_RAGE_IMPLEMENTATION_REPORT_2026-09-15.md`, included in this ZIP, now with a "§24. External Review Corrections" section) for full detail on every design decision, and `REVIEW_CHANGED_FILES.md` for the exact file-by-file breakdown across both passes.

## Final status

- Phase 5 external review corrections: **PASS**
- Rage maximum-only level-up sync: **FIXED**
- Rage Rest ordering preserved: **YES**
- Legacy Rage fallback safe for migrated existing players: **YES**
- Phase 5 automated validation: **PASS**
- Phase 5 manual validation: **PENDING STEFAN**
- Safe to commit Phase 5: **NO — manual validation still required**
- Safe to begin Phase 6: **NO — commit/review Phase 5 first**
