package zcylas.totality.api.shop;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.alchemy.Potions;
import zcylas.totality.Totality;
import zcylas.totality.api.core.component.ComponentProvider;
import zcylas.totality.api.core.util.VerificationReporter;
import zcylas.totality.api.economy.currency.CurrencyComponents;
import zcylas.totality.api.economy.value.ItemPricingService;
import zcylas.totality.api.economy.value.PriceQuote;
import zcylas.totality.api.economy.value.PricingContext;
import zcylas.totality.api.economy.value.PricingDirection;
import zcylas.totality.init.ModTags;
import zcylas.totality.server.TotalityFakePlayer;

import java.util.Optional;
import java.util.Set;
import java.util.function.Supplier;

/**
 * Dev-environment-gated self-test for the Phase 2 merchant runtime / SELL foundation, run once
 * at {@code SERVER_STARTED} — same convention as {@code ItemValueVerification} (no JUnit
 * infrastructure exists in this project; see that class's Javadoc for why).
 *
 * <p>Tests 1-13 exercise {@link MerchantSellQuoteView}/{@link ItemPricingService} directly
 * against isolated, hand-built {@link InMemoryMerchantRuntime} instances — no trade session
 * needed. Tests 14-21 drive the REAL {@link TradeSessionManager} session/commit path (using the
 * existing {@code totality:test_trader} shop and a {@link TotalityFakePlayer}), since those are
 * exactly the atomic-commit and session-validation behaviors that can't be verified by testing
 * the pure quote helper alone.
 */
public final class MerchantSellVerification {

    private static final Identifier TEST_TRADER_SHOP_ID = Identifier.fromNamespaceAndPath("totality", "test_trader");

    private MerchantSellVerification() {}

    public static void register() {
        ServerLifecycleEvents.SERVER_STARTED.register(MerchantSellVerification::runSelfTestIfDev);
    }

    static void runSelfTestIfDev(MinecraftServer server) {
        if (!VerificationReporter.isDevEnvironment()) return;

        VerificationReporter r = new VerificationReporter(Totality.LOGGER, "MerchantSellVerification");
        ServerPlayer player = TotalityFakePlayer.create(server.overworld(), "[MerchantSellVerification]");

        checkAcceptedValuedItemSellable(r, player);
        checkValuedItemOutsideAcceptedTagsRejected(r, player);
        checkAcceptedTagItemWithNoValueRejected(r, player);
        checkToolRejectedByPolicy(r, player);
        checkPotionRejectedByPolicy(r, player);
        checkBaseValue12ProducesPayout6(r, player);
        checkOddBaseValueFloors(r);
        checkMinimumPositivePayout(r);
        checkZeroBaseValuePayoutZero(r);
        checkQuantityMultiplication(r, player);
        checkQuantityOverflowRejected(r, player);
        checkMerchantWithExactCreditsCanSell(r, player);
        checkMerchantWithInsufficientCreditsRejects(r, player);

        checkSuccessfulSellRemovesExactQuantity(r, player);
        checkSuccessfulSellPaysExactAmount(r, player);
        checkSuccessfulSellDecreasesMerchantCreditsExactly(r, player);
        checkFailedSellChangesNothing(r, player);
        checkSuccessfulBuyIncreasesMerchantCredits(r, player);
        checkFailedBuyDoesNotChangeMerchantCredits(r, player);
        checkInvalidSessionSlotQuantityStaleStackRejected(r, player);
        checkSellingPartOfStackLeavesRemainder(r, player);
        checkExtraIrrelevantComponentsStillUseCorrectBaseValue(r, player);

        r.summarize();
    }

    // ─────────────────────────────────────────────────────────────────────
    // Pure MerchantSellQuoteView / ItemPricingService checks — no session required
    // ─────────────────────────────────────────────────────────────────────

    private static void checkAcceptedValuedItemSellable(VerificationReporter r, ServerPlayer player) {
        safe(r, "Accepted item with a value is sellable", () -> {
            MerchantRuntime merchant = freshMerchant(300);
            MerchantSellQuoteView quote = MerchantSellQuoteView.compute(player, merchant, new ItemStack(Items.BREAD), 6, 1);
            return result(quote.sellable() && quote.accepted() && quote.hasValue(), "quote=" + quote);
        });
    }

    private static void checkValuedItemOutsideAcceptedTagsRejected(VerificationReporter r, ServerPlayer player) {
        safe(r, "Valued item outside accepted tags is rejected", () -> {
            MerchantRuntime merchant = freshMerchant(300);
            MerchantSellQuoteView quote = MerchantSellQuoteView.compute(player, merchant, new ItemStack(Items.IRON_SWORD), 1, 1);
            return result(!quote.sellable() && !quote.accepted() && quote.hasValue(), "quote=" + quote);
        });
    }

    private static void checkAcceptedTagItemWithNoValueRejected(VerificationReporter r, ServerPlayer player) {
        safe(r, "Accepted-tag item with no central value is rejected", () -> {
            MerchantRuntime merchant = freshMerchant(300);
            // Carrot is in #totality:provisioner_buys but has no item_values rule authored.
            MerchantSellQuoteView quote = MerchantSellQuoteView.compute(player, merchant, new ItemStack(Items.CARROT), 1, 1);
            return result(!quote.sellable() && quote.accepted() && !quote.hasValue(), "quote=" + quote);
        });
    }

    private static void checkToolRejectedByPolicy(VerificationReporter r, ServerPlayer player) {
        safe(r, "Tool is rejected by the Provisioner policy", () -> {
            MerchantRuntime merchant = freshMerchant(300);
            MerchantSellQuoteView quote = MerchantSellQuoteView.compute(player, merchant, new ItemStack(Items.STONE_AXE), 1, 1);
            return result(!quote.sellable() && !quote.accepted(), "quote=" + quote);
        });
    }

    private static void checkPotionRejectedByPolicy(VerificationReporter r, ServerPlayer player) {
        safe(r, "Potion is rejected by the Provisioner policy", () -> {
            MerchantRuntime merchant = freshMerchant(300);
            ItemStack healingPotion = PotionContents.createItemStack(Items.POTION, Potions.HEALING);
            MerchantSellQuoteView quote = MerchantSellQuoteView.compute(player, merchant, healingPotion, 1, 1);
            return result(!quote.sellable() && !quote.accepted() && quote.hasValue(), "quote=" + quote);
        });
    }

    private static void checkBaseValue12ProducesPayout6(VerificationReporter r, ServerPlayer player) {
        safe(r, "Base value 12 (Bread) produces unit SELL payout 6", () -> {
            PricingContext context = PricingContext.sell(player);
            Optional<PriceQuote> quote = ItemPricingService.quoteSell(new ItemStack(Items.BREAD), 1, context);
            return result(quote.isPresent() && quote.get().unitPrice() == 6L, "quote=" + quote);
        });
    }

    private static void checkOddBaseValueFloors(VerificationReporter r) {
        safe(r, "Odd base value 5 produces unit SELL payout 2 under floor division",
                () -> result(ItemPricingService.sellUnitPayout(5L) == 2L, "got " + ItemPricingService.sellUnitPayout(5L)));
    }

    private static void checkMinimumPositivePayout(VerificationReporter r) {
        safe(r, "Positive base value 1 produces minimum payout 1",
                () -> result(ItemPricingService.sellUnitPayout(1L) == 1L, "got " + ItemPricingService.sellUnitPayout(1L)));
    }

    private static void checkZeroBaseValuePayoutZero(VerificationReporter r) {
        safe(r, "Base value 0 produces payout 0",
                () -> result(ItemPricingService.sellUnitPayout(0L) == 0L, "got " + ItemPricingService.sellUnitPayout(0L)));
    }

    private static void checkQuantityMultiplication(VerificationReporter r, ServerPlayer player) {
        safe(r, "Quantity multiplication is correct (Bread x4 -> 24)", () -> {
            PricingContext context = PricingContext.sell(player);
            Optional<PriceQuote> quote = ItemPricingService.quoteSell(new ItemStack(Items.BREAD), 4, context);
            return result(quote.isPresent() && quote.get().unitPrice() == 6L && quote.get().total() == 24L, "quote=" + quote);
        });
    }

    private static void checkQuantityOverflowRejected(VerificationReporter r, ServerPlayer player) {
        safe(r, "Quantity overflow is rejected (ArithmeticException), not wrapped", () -> {
            PricingContext overflowContext = new PricingContext(
                    player, Optional.empty(), PricingDirection.SELL, Optional.of(Long.MAX_VALUE));
            boolean threw;
            try {
                ItemPricingService.quoteSell(new ItemStack(Items.BREAD), 2, overflowContext);
                threw = false;
            } catch (ArithmeticException expected) {
                threw = true;
            }
            return result(threw, "expected ArithmeticException, none thrown");
        });
    }

    private static void checkMerchantWithExactCreditsCanSell(VerificationReporter r, ServerPlayer player) {
        safe(r, "Merchant with exact Credits can buy the item", () -> {
            MerchantRuntime merchant = freshMerchant(6); // exactly one Bread's payout
            MerchantSellQuoteView quote = MerchantSellQuoteView.compute(player, merchant, new ItemStack(Items.BREAD), 1, 1);
            return result(quote.sellable() && quote.totalPayout() == 6L, "quote=" + quote);
        });
    }

    private static void checkMerchantWithInsufficientCreditsRejects(VerificationReporter r, ServerPlayer player) {
        safe(r, "Merchant with insufficient Credits rejects the sale", () -> {
            MerchantRuntime merchant = freshMerchant(5); // one short of Bread's payout of 6
            MerchantSellQuoteView quote = MerchantSellQuoteView.compute(player, merchant, new ItemStack(Items.BREAD), 1, 1);
            return result(!quote.sellable() && quote.rejectionReason().isPresent(), "quote=" + quote);
        });
    }

    // ─────────────────────────────────────────────────────────────────────
    // Real session/commit checks — drive TradeSessionManager against the existing test shop
    // ─────────────────────────────────────────────────────────────────────

    private static void checkSuccessfulSellRemovesExactQuantity(VerificationReporter r, ServerPlayer player) {
        safe(r, "Successful SELL removes the exact item quantity", () -> {
            int slot = 0;
            player.getInventory().setItem(slot, new ItemStack(Items.BREAD, 10));
            resetMerchantCredits(300);
            TradeSessionManager.startTrade(player, TEST_TRADER_SHOP_ID, null);

            TradeSessionManager.handleSell(player, slot, 4);

            ItemStack remaining = player.getInventory().getItem(slot);
            boolean pass = remaining.getCount() == 6 && remaining.is(Items.BREAD);
            TradeSessionManager.endTrade(player);
            player.getInventory().setItem(slot, ItemStack.EMPTY);
            return result(pass, "remaining=" + remaining);
        });
    }

    private static void checkSuccessfulSellPaysExactAmount(VerificationReporter r, ServerPlayer player) {
        safe(r, "Successful SELL pays the exact amount", () -> {
            int slot = 0;
            player.getInventory().setItem(slot, new ItemStack(Items.BREAD, 4));
            resetMerchantCredits(300);
            long before = wallet(player);
            TradeSessionManager.startTrade(player, TEST_TRADER_SHOP_ID, null);

            TradeSessionManager.handleSell(player, slot, 4);

            long after = wallet(player);
            boolean pass = after - before == 24L; // 4 * 6
            TradeSessionManager.endTrade(player);
            player.getInventory().setItem(slot, ItemStack.EMPTY);
            return result(pass, "before=" + before + ", after=" + after);
        });
    }

    private static void checkSuccessfulSellDecreasesMerchantCreditsExactly(VerificationReporter r, ServerPlayer player) {
        safe(r, "Successful SELL decreases merchant Credits by the exact amount", () -> {
            int slot = 0;
            player.getInventory().setItem(slot, new ItemStack(Items.BREAD, 4));
            MerchantRuntime merchant = resetMerchantCredits(300);
            TradeSessionManager.startTrade(player, TEST_TRADER_SHOP_ID, null);

            TradeSessionManager.handleSell(player, slot, 4);

            boolean pass = merchant.currentCredits() == 300 - 24;
            TradeSessionManager.endTrade(player);
            player.getInventory().setItem(slot, ItemStack.EMPTY);
            return result(pass, "currentCredits=" + merchant.currentCredits());
        });
    }

    private static void checkFailedSellChangesNothing(VerificationReporter r, ServerPlayer player) {
        safe(r, "Failed SELL changes neither inventory, player Credits, nor merchant Credits", () -> {
            int slot = 0;
            player.getInventory().setItem(slot, new ItemStack(Items.IRON_SWORD, 1)); // not accepted -> must fail
            MerchantRuntime merchant = resetMerchantCredits(300);
            long walletBefore = wallet(player);
            TradeSessionManager.startTrade(player, TEST_TRADER_SHOP_ID, null);

            TradeSessionManager.handleSell(player, slot, 1);

            ItemStack after = player.getInventory().getItem(slot);
            boolean pass = after.getCount() == 1 && after.is(Items.IRON_SWORD)
                    && wallet(player) == walletBefore
                    && merchant.currentCredits() == 300;
            TradeSessionManager.endTrade(player);
            player.getInventory().setItem(slot, ItemStack.EMPTY);
            return result(pass, "after=" + after + ", wallet unchanged=" + (wallet(player) == walletBefore)
                    + ", merchantCredits=" + merchant.currentCredits());
        });
    }

    private static void checkSuccessfulBuyIncreasesMerchantCredits(VerificationReporter r, ServerPlayer player) {
        safe(r, "Successful BUY increases merchant Credits by the exact amount", () -> {
            MerchantRuntime merchant = resetMerchantCredits(300);
            giveWallet(player, 10_000);
            TradeSessionManager.startTrade(player, TEST_TRADER_SHOP_ID, null);

            TradeSessionManager.handleBuy(player, 0, 1); // index 0 = Iron Sword, price 450 in test_trader.json

            boolean pass = merchant.currentCredits() == 300 + 450;
            TradeSessionManager.endTrade(player);
            return result(pass, "currentCredits=" + merchant.currentCredits());
        });
    }

    private static void checkFailedBuyDoesNotChangeMerchantCredits(VerificationReporter r, ServerPlayer player) {
        safe(r, "Failed BUY does not change merchant Credits", () -> {
            MerchantRuntime merchant = resetMerchantCredits(300);
            setWallet(player, 0); // can't afford anything -> BUY must fail
            TradeSessionManager.startTrade(player, TEST_TRADER_SHOP_ID, null);

            TradeSessionManager.handleBuy(player, 0, 1);

            boolean pass = merchant.currentCredits() == 300;
            TradeSessionManager.endTrade(player);
            return result(pass, "currentCredits=" + merchant.currentCredits());
        });
    }

    private static void checkInvalidSessionSlotQuantityStaleStackRejected(VerificationReporter r, ServerPlayer player) {
        safe(r, "Invalid session, slot, quantity, or stale/empty stack is rejected", () -> {
            int slot = 0;

            // No active session at all.
            player.getInventory().setItem(slot, new ItemStack(Items.BREAD, 4));
            long walletBefore = wallet(player);
            TradeSessionManager.handleSell(player, slot, 1);
            boolean noSessionSafe = wallet(player) == walletBefore && player.getInventory().getItem(slot).getCount() == 4;

            MerchantRuntime merchant = resetMerchantCredits(300);
            TradeSessionManager.startTrade(player, TEST_TRADER_SHOP_ID, null);

            // Invalid (out-of-range) slot.
            TradeSessionManager.handleSell(player, player.getInventory().getContainerSize() + 5, 1);
            boolean invalidSlotSafe = wallet(player) == walletBefore && merchant.currentCredits() == 300;

            // Invalid (zero) quantity.
            TradeSessionManager.handleSell(player, slot, 0);
            boolean invalidQuantitySafe = wallet(player) == walletBefore
                    && player.getInventory().getItem(slot).getCount() == 4 && merchant.currentCredits() == 300;

            // Stale/empty slot (nothing there to sell).
            player.getInventory().setItem(slot, ItemStack.EMPTY);
            TradeSessionManager.handleSell(player, slot, 1);
            boolean emptySlotSafe = wallet(player) == walletBefore && merchant.currentCredits() == 300;

            TradeSessionManager.endTrade(player);
            player.getInventory().setItem(slot, ItemStack.EMPTY);

            boolean pass = noSessionSafe && invalidSlotSafe && invalidQuantitySafe && emptySlotSafe;
            return result(pass, "noSessionSafe=" + noSessionSafe + ", invalidSlotSafe=" + invalidSlotSafe
                    + ", invalidQuantitySafe=" + invalidQuantitySafe + ", emptySlotSafe=" + emptySlotSafe);
        });
    }

    private static void checkSellingPartOfStackLeavesRemainder(VerificationReporter r, ServerPlayer player) {
        safe(r, "Selling part of a stack leaves the correct remainder", () -> {
            int slot = 0;
            player.getInventory().setItem(slot, new ItemStack(Items.BREAD, 10));
            resetMerchantCredits(300);
            TradeSessionManager.startTrade(player, TEST_TRADER_SHOP_ID, null);

            TradeSessionManager.handleSell(player, slot, 3);

            ItemStack remaining = player.getInventory().getItem(slot);
            boolean pass = remaining.is(Items.BREAD) && remaining.getCount() == 7;
            TradeSessionManager.endTrade(player);
            player.getInventory().setItem(slot, ItemStack.EMPTY);
            return result(pass, "remaining=" + remaining);
        });
    }

    private static void checkExtraIrrelevantComponentsStillUseCorrectBaseValue(VerificationReporter r, ServerPlayer player) {
        safe(r, "Selling an item with extra irrelevant components still uses the correct base value", () -> {
            MerchantRuntime merchant = freshMerchant(300);
            ItemStack namedBread = new ItemStack(Items.BREAD);
            namedBread.set(DataComponents.CUSTOM_NAME, Component.literal("Fancy Bread"));
            MerchantSellQuoteView quote = MerchantSellQuoteView.compute(player, merchant, namedBread, 1, 1);
            return result(quote.sellable() && quote.unitPayout() == 6L, "quote=" + quote);
        });
    }

    // ─────────────────────────────────────────────────────────────────────
    // Fixtures and helpers
    // ─────────────────────────────────────────────────────────────────────

    private static MerchantRuntime freshMerchant(long credits) {
        return new InMemoryMerchantRuntime(
                Identifier.fromNamespaceAndPath("totality", "selftest/merchant"), credits, Set.of(ModTags.PROVISIONER_BUYS));
    }

    /** Resets the SHARED, registry-cached runtime for the real test shop to a known Credits
     *  value, returning it so the caller can assert against the same instance afterward. */
    private static MerchantRuntime resetMerchantCredits(long credits) {
        MerchantRuntime merchant = MerchantRuntimeRegistry.getOrCreate(TEST_TRADER_SHOP_ID);
        merchant.setCurrentCredits(credits);
        return merchant;
    }

    private static long wallet(ServerPlayer player) {
        return CurrencyComponents.WALLET.get((ComponentProvider) player).getValue();
    }

    private static void setWallet(ServerPlayer player, long value) {
        CurrencyComponents.WALLET.get((ComponentProvider) player).setValue(value);
    }

    private static void giveWallet(ServerPlayer player, long amount) {
        CurrencyComponents.WALLET.get((ComponentProvider) player).modify(amount);
    }

    private record CheckResult(boolean pass, String detail) {}

    private static CheckResult result(boolean pass, String detail) {
        return new CheckResult(pass, detail);
    }

    /** Runs one check body, converting an unexpected exception into a FAIL instead of aborting
     *  the whole suite — a bug in one check must not hide the pass/fail of the rest. */
    private static void safe(VerificationReporter r, String label, Supplier<CheckResult> body) {
        try {
            CheckResult result = body.get();
            r.check(label, result.pass(), result.detail());
        } catch (RuntimeException e) {
            r.check(label, false, "threw " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }
}
