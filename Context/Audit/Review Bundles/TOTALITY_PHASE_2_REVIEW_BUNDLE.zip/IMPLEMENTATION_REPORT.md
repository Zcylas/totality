# Totality — Phase 2 Implementation Report

**Phase:** 2 of the Economy Pricing and Provisioner work (Section 11 of the canonical design
document). Phase 1 (component-aware `ItemValueRegistry` + context-aware `ItemPricingService`)
was implemented, hardened, and runtime-verified in a prior pass — this report covers only
Phase 2's additions on top of it.

**Canonical design document:** `Context/Audit/TOTALITY_ECONOMY_PRICING_AND_PROVISIONER.md`
(Section 11 steps 3–4, plus the BUY-side half of step 3; see Section 12c for the doc's own
implementation-status record).

**Date:** 2026-07-13.

---

## 1. Summary of what was implemented

Phase 2 built the minimal merchant-side runtime and a fully functional, server-authoritative
SELL transaction, without building the eventual `ProvisionerNpcEntity` (explicitly deferred).
Concretely:

1. **Merchant runtime Credits** — a `MerchantRuntime` interface plus a non-persistent
   `InMemoryMerchantRuntime` placeholder, lazily created per shop by `MerchantRuntimeRegistry`
   (seeded with the design document's PLAYTEST VALUE of 300 starting Credits).
2. **Accepted goods** — a new `#totality:provisioner_buys` item tag, checked independently of
   item value (an item must have both a resolvable value AND match this tag to be sellable).
3. **Server-side SELL** — a new `TradeSessionManager.handleSell`, validating everything before
   any mutation and committing atomically.
4. **Merchant-to-player payment** — `CreditPaymentHelper.receive`/`canReceive`, reusing the same
   Wallet-crediting mechanism the Banker's deposit flow already established.
5. **BUY integration** — `handleBuy` now also increases the merchant's Credits, with an
   overflow check performed *before* the player is charged.
6. **Rounding decision** — the Phase 1 placeholder (`baseValue / 2`) is replaced with an
   explicit Phase 2 interim rule: floor half, minimum 1 Credit for any positive value.
7. **Verification logging cleanup** (requested alongside Phase 2) — a shared
   `VerificationReporter` helper (concise-by-default, verbose via a JVM system property) now
   used by both the Phase 1 and Phase 2 self-test suites, and `ItemValueRegistry`'s conflict
   validation was split into a pure function + a logging wrapper so synthetic self-test data no
   longer produces real `ERROR` log lines.
8. **New self-test suite** — `MerchantSellVerification`, 22 checks covering both the pure
   quote/pricing logic and the real session/commit path.

Everything else in the design document's Section 11 (randomized assortment, the Provisioner
entity itself, the tutorial quest, TradingScreen's SELL UI, buyback, restocking, Relationship/
reputation/Persuasion modifiers, the broader Economy Transaction API) is explicitly **out of
scope** and was not touched.

---

## 2. Every file created, modified, or deleted

No files were deleted in Phase 2. 9 files created, 10 files modified.

### Created

| Path | Purpose |
|---|---|
| `src/main/java/zcylas/totality/api/shop/MerchantRuntime.java` | Merchant runtime contract (interface) |
| `src/main/java/zcylas/totality/api/shop/InMemoryMerchantRuntime.java` | Non-persistent placeholder implementation |
| `src/main/java/zcylas/totality/api/shop/MerchantRuntimeRegistry.java` | Lazy per-shop `MerchantRuntime` cache |
| `src/main/java/zcylas/totality/api/shop/MerchantSellQuoteView.java` | Pure server-computed SELL quote/validation data |
| `src/main/java/zcylas/totality/api/shop/MerchantSellVerification.java` | Phase 2 self-test suite (22 checks) |
| `src/main/java/zcylas/totality/networking/shop/SellItemPayload.java` | C2S SELL request payload |
| `src/main/java/zcylas/totality/networking/shop/SellItemHandler.java` | Registers the SELL payload receiver |
| `src/main/java/zcylas/totality/api/core/util/VerificationReporter.java` | Shared concise/verbose self-test reporting helper |
| `src/main/resources/data/totality/tags/item/provisioner_buys.json` | The accepted-goods item tag's data |

### Modified

| Path | What changed |
|---|---|
| `src/main/java/zcylas/totality/api/shop/TradeSessionManager.java` | New `handleSell`; `handleBuy` now credits the merchant with an overflow pre-check; `ActiveTrade` carries a `MerchantRuntime` |
| `src/main/java/zcylas/totality/api/economy/currency/CreditPaymentHelper.java` | New `receive`/`canReceive` merchant-to-player payment path |
| `src/main/java/zcylas/totality/api/economy/value/ItemValueRegistry.java` | Conflict validation split into pure `validate()` (returns `ValidationResult`) + logging `load()` |
| `src/main/java/zcylas/totality/api/economy/value/ItemPricingService.java` | SELL rounding rule implemented as `sellUnitPayout` (public); Phase 1's TBD placeholder replaced |
| `src/main/java/zcylas/totality/api/economy/value/ItemValueVerification.java` | Refactored onto `VerificationReporter`; registry checks now call `validate()` directly (no more synthetic `ERROR` logs) |
| `src/main/java/zcylas/totality/init/ModTags.java` | Added `PROVISIONER_BUYS` tag key |
| `src/main/java/zcylas/totality/networking/TotalityPackets.java` | Registers `SellItemPayload` |
| `src/main/java/zcylas/totality/networking/TotalityServerPacketHandlers.java` | Registers `SellItemHandler` |
| `src/main/java/zcylas/totality/Totality.java` | Registers `MerchantSellVerification` |
| `Context/Audit/TOTALITY_ECONOMY_PRICING_AND_PROVISIONER.md` | New Section 12c (Phase 2 implementation status); corrected the `trade_screen.png` reference note |

**Not included in this bundle (unmodified in Phase 2):** `ShopEntry`, `ShopTemplate`,
`ShopRegistry`, `ShowShopStatePayload`, `ShopEntryDisplayData`, `BuyItemPayload`,
`BuyItemHandler`, `CloseTradePayload`, `CloseTradeHandler`, `TradingScreen`,
`ItemValueRule`, `ItemValueRuleConflicts`, `PricingContext`, `PriceQuote`, `PricingDirection`,
and the 20 `item_values/*.json` files — all Phase 1 (or earlier) work, out of scope for a
Phase 2 bundle.

---

## 3. Final architecture and important implementation decisions

### Merchant runtime is an interface, not an entity

`MerchantRuntime` is deliberately not tied to any concrete NPC. `TradeSessionManager`'s SELL/BUY
logic is written once against the interface; the eventual `ProvisionerNpcEntity` will implement
it with real persisted NBT state, without any change to the transaction logic itself.
`InMemoryMerchantRuntime` + `MerchantRuntimeRegistry` (keyed by `shopId`, since that's the only
merchant identity that exists before per-entity Provisioners) are an explicit, documented
placeholder — non-persistent, resets on server restart.

### Accepted-goods tag is separate from item value

Sellability requires BOTH a resolvable base value (`ItemValueRegistry`, unchanged from Phase 1)
AND membership in `#totality:provisioner_buys` — checked independently, matching the design
document's explicit rule that "a merchant accepting an item is separate from the item having a
value." An empty tag set on a `MerchantRuntime` correctly rejects everything (no implicit
"accepts anything" fallback).

### One shared pure quote/validation function

`MerchantSellQuoteView.compute(...)` is the single implementation of "is this stack sellable to
this merchant, and for how much" — used identically by `TradeSessionManager.handleSell`'s
validation and by the self-test. It never mutates anything; it only produces a structured
result (`accepted`, `hasValue`, `unitPayout`, `maxQuantityByStack`, `maxQuantityByMerchant`,
`effectiveMaxQuantity`, `requestedQuantity`, `totalPayout`, `rejectionReason`).

### Server-authoritative SELL, atomic by validation rather than by rollback

The client only ever sends an inventory slot index and a quantity (`SellItemPayload`) — never a
stack, a price, or a sellability claim. `handleSell` re-reads the real stack fresh from the slot
every time and validates, in order: active session → positive quantity → valid slot → non-empty
stack → sufficient count → (accepted / valued / quotable / merchant-can-afford, all via
`MerchantSellQuoteView`) → player can safely receive the payout
(`CreditPaymentHelper.canReceive`). Only after every check passes does it commit: remove the
exact quantity, pay the player the exact payout, decrement the merchant's Credits by the exact
payout. Because every precondition is already confirmed, none of the three commit operations can
fail — so no explicit rollback/transaction machinery was needed, deliberately, per the task's own
guidance to prefer "operations whose success is guaranteed after validation" over building a
rollback framework.

### BUY's merchant-credit integration mirrors the same ordering discipline

`handleBuy` computes the merchant's prospective new balance via `Math.addExact` and rejects
*before* charging the player if it would overflow — a failed BUY must never charge the player,
and merchant Credits must never change on a failed attempt. Merchant Credits are only
incremented after the player has been successfully charged.

### Rounding is now an explicit decision, not accidental behavior

Phase 1's SELL calculation (`baseValue / 2`) worked only by coincidence, because every
currently-authored base value happens to be even. Phase 2 replaces it with an explicit,
documented interim rule: `baseValue == 0 ? 0 : Math.max(1L, baseValue / 2L)` — exposed as public
`ItemPricingService.sellUnitPayout(long)` specifically so it can be verified against values (5,
1) that no real authored item currently has. It remains explicitly INTERIM — modifier
composition and per-unit-vs-transaction-total rounding remain open per the design document's
Section 1f.

### Verification logging: concise by default, pure validation for synthetic tests

`VerificationReporter` centralizes PASS/FAIL/summary reporting for both self-test suites.
Default output is one summary line per suite; `-Dtotality.verboseVerification=true` restores
full per-check PASS lines. Separately, `ItemValueRegistry`'s conflict-detection logic was split
into a pure `validate(Map<Identifier, ItemValueRule>) -> ValidationResult` (no logging at all)
and a thin `load()` wrapper that turns `ValidationResult.conflicts()` into real `ERROR` log
lines for actual datapack problems. The self-tests call `validate()` directly, so feeding it
deliberately conflicting synthetic data no longer produces any log output — previously this
produced real-looking `ERROR` lines (with an explanatory disclaimer) for entirely fake test
data, which was flagged as noise to clean up.

---

## 4. Networking changes

One new C2S payload pair, modeled exactly on the existing BUY flow:

- **`SellItemPayload(int slotIndex, int quantity)`** — C2S. Identifies the stack to sell by
  inventory slot index (not by item identity or a client-supplied stack), so the server always
  re-reads the authoritative current stack rather than trusting anything the client claims about
  it.
- **`SellItemHandler`** — registers the receiver, delegates to
  `TradeSessionManager.handleSell(player, slotIndex, quantity)`.

Both are registered in `TotalityPackets` (payload type) and `TotalityServerPacketHandlers`
(receiver), following the exact existing pattern used for `BuyItemPayload`/`BuyItemHandler`.

**No new S2C payload was added.** A successful or failed SELL still calls the existing
`sendState(player, false)` (unchanged), which refreshes the player's wallet/physical-Credits
display exactly as BUY already does. Extending `ShowShopStatePayload` with a `merchantCredits`
field (needed for a future SELL UI showing "Merchant Credits: ₵300" per the reviewed
`trade_screen.png` reference) was deliberately deferred — `MerchantRuntime.currentCredits()` is
already trivially available to `TradeSessionManager.sendState()` when that networking work
happens, so this is a pure addition later, not a rework.

---

## 5. Persistence changes

**None.** `InMemoryMerchantRuntime`/`MerchantRuntimeRegistry` are explicitly non-persistent —
merchant Credits reset to the 300-Credit baseline on every server restart. This is a deliberate,
documented placeholder (design document Section 2a/11 step 3): the real persistence work lands
with `ProvisionerNpcEntity` in a later phase, which will persist `currentCredits` (and stock) as
real entity NBT. No new NBT keys, no new `SavedData`, no new component types were introduced in
Phase 2.

---

## 6. Verification and runtime results

No JUnit/test infrastructure exists in this project (confirmed: no `src/test`, no test
dependency in `build.gradle`) — both self-test suites run as real in-game self-checks at
`SERVER_STARTED`, gated to development environments only.

- **`gradlew compileJava`: SUCCESSFUL** (first attempt).
- **`gradlew runClient`, integrated server, world loaded — CONFIRMED (twice, on separate loads
  in the same session):**
  - `Parsed 20 item value rules: 20 accepted, 0 rejected, across 19 items` (Phase 1 data,
    unaffected by Phase 2).
  - `[ItemValueVerification] All 19 self-test checks passed.`
  - `[MerchantSellVerification] All 22 self-test checks passed.`
  - **41 checks total, zero failures.**
  - Zero unexpected `ERROR` lines (confirms the logging-cleanup fix: synthetic conflict-test
    data no longer logs at all).
  - Zero `PASS` lines printed by default (confirms concise-mode works as designed) — the only
    other log lines present were expected `WARN`s from `MerchantSellVerification`'s own
    intentional-rejection checks (invalid session/slot/quantity/empty-stack), which are genuine
    `TradeSessionManager` rejection messages, not verification noise.
  - `-Dtotality.verboseVerification=true` was not independently re-run in this session (the
    concise-mode result already demonstrates the default path correctly); the flag exists and
    the code path for it is present in `VerificationReporter.verbose()`.

`MerchantSellVerification`'s 22 checks: 13 exercise `MerchantSellQuoteView`/`ItemPricingService`
directly against isolated `InMemoryMerchantRuntime` fixtures (accepted+valued sellable;
valued-but-unaccepted rejected; accepted-but-unvalued rejected — using `minecraft:carrot`,
deliberately tagged but left unvalued, exactly for this case; tool and potion rejected by
policy; base value 12 → payout 6; odd value 5 → floored payout 2; value 1 → minimum payout 1;
value 0 → payout 0; quantity multiplication; quantity overflow; exact-Credits and
insufficient-Credits merchant affordability). 9 drive the real `TradeSessionManager`
session/commit path against the existing `totality:test_trader` shop and a `TotalityFakePlayer`
(successful SELL removes the exact quantity, pays the exact amount, and decreases merchant
Credits by the exact amount; a failed SELL changes nothing at all; successful/failed BUY
correctly does/doesn't change merchant Credits; invalid session/slot/quantity/empty-stack SELL
attempts are all safely rejected; selling part of a stack leaves the correct remainder; an item
with an irrelevant extra component still resolves its correct base value).

---

## 7. Known limitations and explicitly deferred scope

Deliberately **not** implemented in Phase 2 (per the task's own scope boundary):

- `ProvisionerNpcEntity` and persistent per-entity merchant NBT (merchant Credits are
  in-memory only, reset on restart).
- Randomized Provisioner assortment / `ProvisionerAssortmentPool` / `MerchantStockEntry` / stock
  depletion / restocking.
- Credit replenishment toward an "effective starting Credits" baseline.
- Buyback.
- The full `TradingScreen` SELL visual redesign (SELL is still a UI-only inert tab client-side;
  no networking wires a real SELL flow into the GUI yet).
- The first trading tutorial quest.
- Relationship, reputation, Persuasion, and investment modifiers.
- Pickpocket, Contacts integration, Blacksmith/Alchemist NPCs.
- The broader Economy Transaction API, ledger history, refunds, an idempotency framework.
- The unrelated, pre-existing dedicated-server `EnergyItems`/`Screen`-classloading bug (confirmed
  in an earlier pass to predate this work entirely; not touched).

**Rounding remains explicitly interim.** The Phase 2 rule (`Math.max(1, baseValue/2)`, floor)
is a deliberate, documented decision, but modifier composition (Relationship/Persuasion/
reputation percentage adjustments) and per-unit-vs-transaction-total rounding for those future
modifiers are still open questions per the design document's Section 1f.

**No new S2C networking for merchant Credits or SELL display data.** `MerchantSellQuoteView`
exists and is fully computed server-side, but nothing currently transmits it to a client — this
was an explicit, task-permitted deferral ("do not build the full visual SELL screen in this
phase unless minimal networking changes require a simple placeholder"; none were required, since
`handleSell` needed only a request payload, not a response one).

---

## 8. Discrepancies from the original prompt

1. **`Image References/trad_screen.png` → `Context/Audit/Image References/trade_screen.png`.**
   The task (from an earlier turn) referenced a trading-screen visual mockup at a path that does
   not exist; the actual file (found after Stefan corrected the filename) is at
   `Context/Audit/Image References/trade_screen.png`. It was located and reviewed mid-Phase-2;
   the design document's Section 12c records what it confirmed (merchant Credits display,
   slot-based SELL interaction, BUY/SELL/BUYBACK tabs, per-item stock) and that nothing built
   needed to change as a result.
2. **`ItemValueRegistry.validateAndGroup` → `ItemValueRegistry.validate`.** The Phase 1/hardening
   method name `validateAndGroup` (package-private, returned a plain
   `Map<Item, List<ItemValueRule>>`) was renamed to `validate` and its return type changed to a
   new `ValidationResult(accepted, conflicts)` record as part of Part A's logging-cleanup
   requirement (separating pure validation from log-emission). This is a Phase 2 change to
   Phase-1-authored code, done because Part A of this phase's own instructions required it, not
   a deviation from what was asked.
3. **No other discrepancies identified.** Every other Phase 2 requirement (merchant runtime
   shape, accepted tags, SELL validation order, atomicity, payment path, BUY integration,
   rounding rule, verification suite and its 22 cases) was implemented as specified.

---

## 9. Reviewer notes on this bundle's patch

`phase_changes.patch` was generated by reconstructing the pre-Phase-2 state of files that were
also touched by earlier, separate, still-uncommitted work in the same working tree (a prior
interaction-lock fix, and this feature's own Phase 1/hardening pass) — there is no git commit
marking "immediately before Phase 2" to diff against directly. The patch file's own header
explains exactly which files were reconstructed and how (either from the literal pre-Phase-2
file content read at the start of this phase, or by reverse-applying the exact edit operations
performed during this phase). The `files/` directory in this bundle always contains the current,
real, authoritative file content regardless of how the patch was derived.
