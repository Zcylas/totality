package zcylas.totality.api.shop;

import com.mojang.logging.LogUtils;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import zcylas.totality.api.core.component.ComponentProvider;
import zcylas.totality.api.economy.currency.CreditPaymentHelper;
import zcylas.totality.api.economy.currency.CurrencyComponents;
import zcylas.totality.entity.npc.TotalityNpcEntity;
import zcylas.totality.networking.shop.ShopEntryDisplayData;
import zcylas.totality.networking.shop.ShowShopStatePayload;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Server-side trade session tracking, mirroring {@link zcylas.totality.api.dialogue.DialogueSessionManager}'s
 * shape but without a branching state machine — a shop's catalog is static per session,
 * only the player's Credits/afford status changes between updates.
 */
public final class TradeSessionManager {

    private static final Logger LOGGER = LogUtils.getLogger();

    private record ActiveTrade(
            Identifier shopId, ShopTemplate template, MerchantRuntime merchant, int npcEntityId, Component npcName) {}

    private static final Map<UUID, ActiveTrade> SESSIONS = new HashMap<>();

    private TradeSessionManager() {}

    public static void startTrade(ServerPlayer player, Identifier shopId, @Nullable Entity npc) {
        ShopTemplate template = ShopRegistry.INSTANCE.get(shopId);
        if (template == null) {
            LOGGER.error("Shop not found: {}", shopId);
            return;
        }
        Component npcName = npc != null ? npc.getName() : Component.empty();
        int npcId = npc != null ? npc.getId() : -1;
        MerchantRuntime merchant = MerchantRuntimeRegistry.getOrCreate(shopId);
        SESSIONS.put(player.getUUID(), new ActiveTrade(shopId, template, merchant, npcId, npcName));
        if (npc instanceof TotalityNpcEntity totNpc) {
            totNpc.acquireInteractionLock(player);
        }
        sendState(player, false);
    }

    public static void handleBuy(ServerPlayer player, int index, int quantity) {
        ActiveTrade trade = SESSIONS.get(player.getUUID());
        if (trade == null) return;

        List<ShopEntry> sells = trade.template().sells();
        if (index < 0 || index >= sells.size()) return;

        quantity = Math.max(1, Math.min(100, quantity));

        ShopEntry entry = sells.get(index);
        long total = entry.price() * quantity;

        // Validate the merchant's balance can safely absorb this BEFORE charging the player —
        // a failed BUY must never charge the player, and merchant Credits must never change on
        // a failed attempt (Section 11 step 4 / Part F).
        MerchantRuntime merchant = trade.merchant();
        long newMerchantCredits;
        try {
            newMerchantCredits = Math.addExact(merchant.currentCredits(), total);
        } catch (ArithmeticException overflow) {
            LOGGER.warn("BUY rejected: merchant {} Credits would overflow (+{})", trade.shopId(), total);
            return;
        }

        if (!CreditPaymentHelper.pay(player, total)) return;

        merchant.setCurrentCredits(newMerchantCredits);

        // Individual copies, not one stack multiplied by count — a full inventory drops
        // the remainder on the ground instead of blocking/rolling back the purchase.
        for (int i = 0; i < quantity; i++) {
            ItemStack gift = entry.stack().copy();
            if (!player.getInventory().add(gift)) {
                player.drop(gift, false);
            }
        }

        sendState(player, false);
    }

    /**
     * Server-authoritative SELL — the client only ever supplies a slot index and a quantity;
     * every other fact (the real stack, its count, the merchant's acceptance/value/Credits, and
     * the resulting quote) is re-read and revalidated here, never trusted from the client. See
     * design document Section D for the full validation order this method implements:
     *
     * <ol>
     *   <li>An active trade session exists for the player.
     *   <li>Its merchant is present (implied by the session existing at all).
     *   <li>{@code quantity} is positive.
     *   <li>{@code slotIndex} is a valid inventory slot.
     *   <li>The real stack in that slot is non-empty.
     *   <li>The real stack holds at least {@code quantity}.
     *   <li>The merchant accepts the item ({@link MerchantSellQuoteView}).
     *   <li>The item has a resolvable central base value ({@link MerchantSellQuoteView}).
     *   <li>A SELL quote can be produced ({@link MerchantSellQuoteView}).
     *   <li>The quote total is valid and does not overflow ({@link MerchantSellQuoteView}).
     *   <li>The merchant has enough {@code currentCredits} ({@link MerchantSellQuoteView}).
     *   <li>The player can safely receive the payout ({@link CreditPaymentHelper#canReceive}).
     * </ol>
     *
     * <p>Every precondition is confirmed before any mutation. The commit itself (remove item,
     * pay player, decrement merchant Credits) uses operations already proven safe by the
     * preceding validation, so no explicit rollback machinery is needed — nothing in the commit
     * step can fail after validation has passed.
     */
    public static void handleSell(ServerPlayer player, int slotIndex, int quantity) {
        ActiveTrade trade = SESSIONS.get(player.getUUID());
        if (trade == null) {
            LOGGER.warn("SELL rejected: no active trade session for {}", player.getName().getString());
            return;
        }

        if (quantity <= 0) {
            LOGGER.warn("SELL rejected: invalid quantity {} from {}", quantity, player.getName().getString());
            return;
        }

        Inventory inventory = player.getInventory();
        if (slotIndex < 0 || slotIndex >= inventory.getContainerSize()) {
            LOGGER.warn("SELL rejected: invalid slot {} from {}", slotIndex, player.getName().getString());
            return;
        }

        ItemStack real = inventory.getItem(slotIndex);
        if (real.isEmpty()) {
            LOGGER.warn("SELL rejected: slot {} is empty for {}", slotIndex, player.getName().getString());
            return;
        }

        if (real.getCount() < quantity) {
            LOGGER.warn("SELL rejected: slot {} only holds {}, requested {} for {}",
                    slotIndex, real.getCount(), quantity, player.getName().getString());
            return;
        }

        MerchantRuntime merchant = trade.merchant();
        MerchantSellQuoteView quote = MerchantSellQuoteView.compute(player, merchant, real, real.getCount(), quantity);
        if (!quote.sellable()) {
            LOGGER.warn("SELL rejected for {}: {}", player.getName().getString(), quote.rejectionReason().orElse("unknown"));
            return;
        }

        long payout = quote.totalPayout();
        if (!CreditPaymentHelper.canReceive(player, payout)) {
            LOGGER.warn("SELL rejected: {} cannot safely receive {} Credits", player.getName().getString(), payout);
            return;
        }

        inventory.removeItem(slotIndex, quantity);
        CreditPaymentHelper.receive(player, payout);
        merchant.setCurrentCredits(merchant.currentCredits() - payout);

        sendState(player, false);
    }

    public static void endTrade(ServerPlayer player) {
        ActiveTrade removed = SESSIONS.remove(player.getUUID());
        releaseTradePartner(player, removed);
        ServerPlayNetworking.send(player, new ShowShopStatePayload(
                -1, Component.empty(), List.of(), 0, 0, true
        ));
    }

    public static boolean isTrading(ServerPlayer player) {
        return SESSIONS.containsKey(player.getUUID());
    }

    private static void releaseTradePartner(ServerPlayer player, @Nullable ActiveTrade trade) {
        if (trade == null || trade.npcEntityId() == -1) return;
        if (player.level().getEntity(trade.npcEntityId()) instanceof TotalityNpcEntity totNpc) {
            totNpc.releaseInteractionLock();
        }
    }

    private static void sendState(ServerPlayer player, boolean ended) {
        ActiveTrade trade = SESSIONS.get(player.getUUID());
        if (trade == null) return;

        long walletBalance = CurrencyComponents.WALLET.get((ComponentProvider) player).getValue();
        long physicalCredits = CreditPaymentHelper.physicalCredits(player);

        List<ShopEntryDisplayData> display = new ArrayList<>();
        for (ShopEntry entry : trade.template().sells()) {
            boolean affordable = CreditPaymentHelper.canAfford(player, entry.price());
            display.add(new ShopEntryDisplayData(entry.stack(), entry.price(), affordable));
        }

        ServerPlayNetworking.send(player, new ShowShopStatePayload(
                trade.npcEntityId(),
                Component.literal(trade.template().name()),
                display,
                walletBalance,
                physicalCredits,
                ended
        ));
    }
}
