package zcylas.totality.api.shop;

import net.minecraft.resources.Identifier;
import zcylas.totality.init.ModTags;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Lazily creates and holds one {@link InMemoryMerchantRuntime} per shop identifier — the
 * temporary stand-in for per-entity merchant state (design document Section 11 step 3). Keyed by
 * {@code shopId} because that is the only merchant identity that exists before
 * {@code ProvisionerNpcEntity} (a later phase) gives individual NPCs their own runtime.
 *
 * <p>Every merchant currently uses the same accepted-tag policy
 * ({@link ModTags#PROVISIONER_BUYS}) because only the generic Provisioner archetype exists so
 * far — a real per-merchant-type policy is future work, not invented here.
 */
public final class MerchantRuntimeRegistry {

    /** Section 2's PLAYTEST VALUE baseline for the first Provisioner. */
    public static final long BASE_STARTING_CREDITS = 300;

    private static final Map<Identifier, InMemoryMerchantRuntime> MERCHANTS = new HashMap<>();

    private MerchantRuntimeRegistry() {}

    public static MerchantRuntime getOrCreate(Identifier shopId) {
        return MERCHANTS.computeIfAbsent(shopId,
                id -> new InMemoryMerchantRuntime(id, BASE_STARTING_CREDITS, Set.of(ModTags.PROVISIONER_BUYS)));
    }
}
