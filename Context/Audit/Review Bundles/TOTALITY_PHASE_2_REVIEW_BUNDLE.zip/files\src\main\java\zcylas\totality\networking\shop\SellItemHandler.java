package zcylas.totality.networking.shop;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import zcylas.totality.api.shop.TradeSessionManager;

public final class SellItemHandler {

    private SellItemHandler() {}

    public static void register() {
        ServerPlayNetworking.registerGlobalReceiver(
                SellItemPayload.TYPE,
                (payload, context) -> context.server().execute(
                        () -> TradeSessionManager.handleSell(context.player(), payload.slotIndex(), payload.quantity())
                )
        );
    }
}
