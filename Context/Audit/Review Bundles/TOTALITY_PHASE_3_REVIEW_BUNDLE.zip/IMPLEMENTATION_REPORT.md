# Totality — Phase 3: Provisioner Assortment, Per-Entity Stock, and Stock-Aware BUY

**Scope:** the first real Provisioner NPC — persistent per-entity Credits, roll-once randomized
stock, stock-aware BUY transactions, and the server-issued shop-state fields the future Trading
Screen redesign (Phase 4) will need. Does **not** implement the Phase 4 visual redesign, BUYBACK,
restocking, Credit replenishment, the tutorial quest, or any of Section 10's future integrations
(Relationship, Persuasion, Investment, Pickpocket, Contacts, Blacksmith, Alchemist) — all
explicitly out of scope, per task instruction.

**Canonical design document:** `Context/Audit/TOTALITY_ECONOMY_PRICING_AND_PROVISIONER.md`,
new Section 12g.

**Date:** 2026-07-14.

---

## 1. Summary of what was implemented

1. **Static assortment data** (`api/shop/assortment/`) — `AssortmentItemEntry`,
   `WeightedAssortmentEntry`, `ChanceAssortmentEntry`, `AssortmentSelectionGroup`,
   `ProvisionerAssortmentPool` (pure `validate()` + `roll(RandomSource)`),
   `ProvisionerAssortmentRegistry` (loads `data/totality/provisioner_assortments/*.json`, same
   `SERVER_STARTED` + `RegistryOps` pattern as `ShopRegistry`/`ItemValueRegistry`).
2. **Adopted Provisioner pool data** — `generic_provisioner.json`: guaranteed Torch/Bread/Water
   Bottle; a 4-distinct-of-6 common-material group; a 1-of-2 cooked-food group; a 1-of-8 tool
   group modeling the 90%-Stone/10%-Iron tier split via weight 9 (Stone) vs. weight 1 (Iron); a
   12.5%-chance Potion of Healing entry. No prices authored — all prices resolve live.
3. **Runtime stock representation** (`api/shop/MerchantStockEntry` + `MerchantStockProvider`) —
   immutable, defensively-copying stock entries; a deliberately separate interface from
   `MerchantRuntime` (Credits vs. stock are different concerns).
4. **`ProvisionerNpcEntity`** (`entity/npc/`) — thin `TotalityNpcEntity` subclass implementing
   both `MerchantRuntime` and `MerchantStockProvider` directly; reuses the existing random
   gender/name identity system and the generic `dialogueId`/`mobInteract` path unchanged.
5. **Persistent per-entity Credits** — `currentCredits` (baseline 300, PLAYTEST value) with an
   explicit `creditsInitialized` marker, never inferred from `currentCredits != 0`.
6. **Roll-once assortment generation** — `stockInitialized` marker (never inferred from
   `stock.isEmpty()`), rolled via `finalizeSpawn` (never re-invoked on reload) with a cheap
   per-tick fallback retry in `customServerAiStep` for the "pool was missing at spawn, fixed
   later" case.
7. **NBT persistence** — `CurrentCredits`/`CreditsInitialized`/`StockInitialized`/
   `AssortmentPoolId`/`Stock` via the existing `ValueOutput.store`/`ValueInput.read` pattern;
   all-or-nothing stock-list decode so a corrupted entry can never leave partial/duplicated stock.
8. **`TradeSessionManager` integration** — `ActiveTrade.template()` is now `@Nullable` (a stock-
   backed session has none); every BUY/SELL commit RE-RESOLVES the live NPC entity rather than
   trusting a reference captured at session start (a chunk unload/reload cycle creates a NEW Java
   object with the SAME UUID — a real staleness bug this phase had to design around from the
   start, not discovered later).
9. **Stock-aware BUY** — new `TradeSessionManager.handleStockBuy`, validating index/stock/price/
   affordability/overflow before any mutation; new `BuyResult.Reason.OUT_OF_STOCK`. SELL is
   otherwise unchanged and never adds a sold item to any merchant's BUY stock.
10. **Server shop-state / networking** — `ShowShopStatePayload` gained `merchantCredits`;
    `ShopEntryDisplayData` gained `limitedStock`/`availableStock` (+ `soldOut()`); a 3-argument
    constructor preserves every pre-Phase-3 call site. `TradingScreen.java` was **not touched at
    all** — the new fields are purely additive and compile-safe for a client that doesn't read
    them yet.
11. **Verification** — new `api/shop/ProvisionerVerification`, 45 checks.

---

## 2. Every file created or modified

### Created

| Path | Purpose |
|---|---|
| `src/main/java/zcylas/totality/api/shop/assortment/AssortmentItemEntry.java` | Authored item+stock template |
| `src/main/java/zcylas/totality/api/shop/assortment/WeightedAssortmentEntry.java` | Template + selection weight |
| `src/main/java/zcylas/totality/api/shop/assortment/AssortmentSelectionGroup.java` | "Choose N [distinct]" group + weighted-without-replacement `pick` |
| `src/main/java/zcylas/totality/api/shop/assortment/ChanceAssortmentEntry.java` | Independent chance roll |
| `src/main/java/zcylas/totality/api/shop/assortment/ProvisionerAssortmentPool.java` | Pool definition, pure `validate()`, `roll(RandomSource)` |
| `src/main/java/zcylas/totality/api/shop/assortment/ProvisionerAssortmentRegistry.java` | `data/totality/provisioner_assortments/*.json` loader |
| `src/main/java/zcylas/totality/api/shop/MerchantStockEntry.java` | Immutable, defensive runtime stock entry |
| `src/main/java/zcylas/totality/api/shop/MerchantStockProvider.java` | Per-entity stock contract |
| `src/main/java/zcylas/totality/entity/npc/ProvisionerNpcEntity.java` | The Provisioner NPC |
| `src/main/java/zcylas/totality/api/dialogue/actions/OpenProvisionerShopAction.java` | Dialogue → entity-backed trade bridge |
| `src/main/java/zcylas/totality/api/shop/ProvisionerVerification.java` | Dev self-test suite (45 checks) |
| `src/main/resources/data/totality/provisioner_assortments/generic_provisioner.json` | Adopted pool data |
| `src/main/resources/data/totality/dialogues/provisioner_greeting.json` | Provisioner greeting dialogue |

### Modified

| Path | Change |
|---|---|
| `src/main/java/zcylas/totality/api/dialogue/DialogueAction.java` | Registers `open_provisioner_shop` |
| `src/main/java/zcylas/totality/api/shop/BuyResult.java` | New `Reason.OUT_OF_STOCK` |
| `src/main/java/zcylas/totality/api/shop/TradeSessionManager.java` | Nullable `template`; new `stockProvider` field; `startEntityBackedTrade`/`startStockBackedTradeForVerification`; live entity re-resolution (`currentNpc`/`currentMerchant`/`currentStockProvider`); `handleStockBuy`; `sendState` stock/Credits fields |
| `src/main/java/zcylas/totality/init/ModEntities.java` | Registers `totality:provisioner` |
| `src/main/java/zcylas/totality/networking/shop/ShopEntryDisplayData.java` | `limitedStock`/`availableStock`/`soldOut()` + updated `STREAM_CODEC` |
| `src/main/java/zcylas/totality/networking/shop/ShowShopStatePayload.java` | `merchantCredits` field + updated `STREAM_CODEC` |
| `src/main/java/zcylas/totality/Totality.java` | Registers `ProvisionerAssortmentRegistry`, `ProvisionerVerification`, Provisioner attributes |
| `src/main/java/zcylas/totality/TotalityClient.java` | Registers Provisioner entity renderer (reuses `TotalityNpcRenderer`) |
| `Context/Audit/TOTALITY_ECONOMY_PRICING_AND_PROVISIONER.md` | New Section 12g |

**Not touched:** `screen/shop/TradingScreen.java` (deliberately — Phase 4 scope), `ModTags.java`
(the existing `PROVISIONER_BUYS` tag/policy is reused unchanged), all `item_values/*.json` (every
item in the adopted pool already had a matching Phase 1/2 value entry — confirmed before authoring
the pool, no new pricing data needed).

---

## 3. Final assortment architecture

A pool is authored as JSON (`guaranteed` / `selection_groups` / `chance_entries`), loaded once at
`SERVER_STARTED` via the same `RegistryOps` pattern `ShopRegistry`/`ItemValueRegistry` already use
(component-bearing templates — Water Bottle vs. Potion of Healing — need real registry access).
`validate()` is pure (no logging/I/O) and rejects: empty or multi-count item stacks (stock must be
tracked via the separate `stock` field); non-positive stock; a non-positive or empty-pool group
roll count; a distinct group requesting more rolls than it has entries; non-positive weights or a
non-positive group total weight; an out-of-range or non-finite chance; and any item template
(matched via `ItemStack.isSameItemSameComponents`) appearing more than once across the entire
pool — no merge rule exists, so an accidental duplicate is rejected outright.

`AssortmentSelectionGroup.pick(RandomSource)` implements ONE weighted-without-replacement
algorithm that covers every Phase 3 shape: a uniform "choose 4 distinct of 6" group, a uniform
1-of-2 choice, and a non-uniform tiered 1-of-8 choice (the tool slot: four Stone entries at weight
9 and four Iron entries at weight 1 — total weight 40, so any one Stone tool is 9/40 = 22.5%
(×4 = 90%) and any one Iron tool is 1/40 = 2.5% (×4 = 10%), uniform within each tier by
construction, exactly the required 90/10 split).

`ProvisionerAssortmentPool.roll(RandomSource)` produces a `List<MerchantStockEntry>` — guaranteed
entries, then each group's picks, then chance entries, in stable authored order. No price is ever
frozen into this list; every BUY quote resolves live against `ItemValueRegistry`/
`ItemPricingService` at commit time.

---

## 4. Final entity/runtime architecture

`MerchantStockEntry` is an immutable record: its canonical constructor stores its OWN defensive
copy of the item template (normalized to count 1) and its `item()` accessor returns a further
defensive copy on every read — no caller can mutate the internal template. `withStock(int)`
returns a new instance rather than mutating in place. `currentStock` is validated `>= 0` by both
the compact constructor (defense-in-depth) and the CODEC's `Codec.intRange(0, Integer.MAX_VALUE)`
field, so a corrupted NBT value fails to decode as a clean `DataResult` error rather than throwing
mid-decode.

`MerchantStockProvider` is a deliberately separate interface from `MerchantRuntime` — Credits and
stock are different concerns (confirmed by `trade_screen.png` showing them as separate UI
elements). `ProvisionerNpcEntity` implements both directly (a thin `TotalityNpcEntity` subclass,
following the `BankerNpcEntity` precedent), rather than forcing stock into the Credits-only
contract.

Two public test-only hooks (`setCreditsForTest`/`setStockForTest`) exist on `ProvisionerNpcEntity`
for `ProvisionerVerification` to seed known state without depending on a real pool roll — no
production code path calls them.

---

## 5. Persistence format

NBT keys (via the standard `ValueOutput.store`/`ValueInput.read` pattern already used by
`PlayerEquipmentComponent`/`RestStateComponent` elsewhere in this codebase — no new persistence
machinery was invented):

```
CurrentCredits       long
CreditsInitialized   boolean
StockInitialized     boolean
AssortmentPoolId     string  (parsed back via Identifier.tryParse, falls back to the default id)
Stock                MerchantStockEntry.CODEC.listOf()
```

`writePhase3State(ValueOutput)`/`readPhase3State(ValueInput)` are public specifically so
`ProvisionerVerification` can drive a focused, REAL NBT round-trip (via
`TagValueOutput.createWithContext`/`TagValueInput.create`, `ProblemReporter.DISCARDING`) without
needing a full `Entity#save`/`#load` cycle. The stock list decodes all-or-nothing: any single
malformed entry invalidates the whole list rather than silently dropping just that entry, so
corruption can never produce partial/duplicated stock — `StockInitialized` is read independently
either way, so a corruption event degrades to "this Provisioner presents as fully sold out," never
a reroll.

---

## 6. Transaction and networking changes

**The critical correctness decision this phase had to make from the start** (not discovered as a
bug after the fact): `TradeSessionManager`'s `ActiveTrade` previously captured a `MerchantRuntime`
reference once, at session start, and reused it for every subsequent BUY/SELL. That is safe for
the Phase 2 shared, registry-cached `InMemoryMerchantRuntime` (not tied to any Java entity object),
but would be a real staleness bug for an entity-backed Provisioner: a chunk unload/reload cycle
deserializes a brand-new `ProvisionerNpcEntity` Java object sharing the OLD one's UUID, and a
stored reference would silently keep mutating the discarded, orphaned instance instead of the live
one. Every BUY/SELL commit now re-resolves the live NPC via `currentNpc(player, trade)` (built on
the existing UUID-safe `resolveRecordedNpc`), and `currentMerchant`/`currentStockProvider` prefer
that live-resolved entity when it implements the relevant interface, falling back to the session's
originally captured `MerchantRuntime` only for the non-entity-tied shared-registry case (which has
no staleness problem at all).

`handleStockBuy` validates, in order: valid entry index; `MerchantStockProvider
.canPurchaseStock` (current stock ≥ requested quantity); a live retail price resolved against the
entry's OWN item template (never a persisted price); the merchant's balance can safely absorb the
total (`Math.addExact`); and the player can pay. Only once every check passes does anything
mutate — pay, credit the merchant, decrement stock, then deliver items — mirroring the
template-backed path's existing "validate everything first" discipline. SELL is otherwise
unchanged (Phase 2's 11-step validation still applies verbatim); its only mutation is the player's
own inventory — a Provisioner's `MerchantStockProvider`, if it has one, is never touched by SELL.

`ShowShopStatePayload` gained `merchantCredits` (a `long`); `ShopEntryDisplayData` gained
`limitedStock`/`availableStock` (an explicit boolean+int pair, not an ambiguous `-1 = unlimited`
sentinel) plus `soldOut()`. A 3-argument `ShopEntryDisplayData` constructor preserves every
pre-Phase-3 call site. `TradingScreen.java` was not touched — Phase 4 scope.

---

## 7. Verification and manual runtime results

**`gradlew compileJava`: SUCCESSFUL.**

**A real bug was found and fixed by this pass's own verification, not after:** five
`ProvisionerVerification` transaction-integration checks initially failed with `NPC_INVALID` — a
freshly `addFreshEntity`'d Provisioner is not yet visible to `Level#getEntity(int)` at
`ServerLifecycleEvents.SERVER_STARTED` (before any tick has run), the SAME documented
harness-timing limitation the Phase 2 economy correction pass already flagged for
`MerchantSellVerification`'s two entity-backed checks (which only ever exercised the FAILURE
path, so they never actually hit it). A new verification-only entry point,
`TradeSessionManager.startStockBackedTradeForVerification(player, MerchantRuntime,
MerchantStockProvider)`, extends the existing `startTradeForVerification` isolation pattern to
stock-backed sessions — binding directly to an isolated Credits+stock pair with no entity at all.
A real, entity-backed Provisioner session is completely unaffected (`startEntityBackedTrade`
still always re-resolves the live entity). All five checks then passed, exercising the exact same
production `handleBuy`/`handleSell`/`handleStockBuy` logic a real Provisioner uses.

**`gradlew runClient`, "Testing World":**

```
[ItemValueVerification] All 19 self-test checks passed.
[MerchantSellVerification] All 33 self-test checks passed.
[ProvisionerVerification] All 45 self-test checks passed.
Loaded 1 provisioner assortment pool(s), 0 rejected
```

- **97 checks total, zero failures.**
- **Zero unexpected `WARN`/`ERROR` lines** from the `totality` namespace — the only lines present
  are the pre-existing, unrelated missing-texture/missing-block-model warnings (unchanged by this
  phase) and ONE fully expected `ERROR` line:
  `checkMissingPoolDoesNotMarkStockInitialized`'s own intentional-failure scenario logging the
  exact "assortment pool not found" diagnostic it exists to prove happens cleanly.
- **Zero `PASS` lines** printed by default — concise logging remains intact.

**Manual, interactive verification (Part M) — honestly limited:** this environment has no way to
drive the actual Minecraft client window (no input-injection tool available), the same limitation
already documented from the Phase 2 hardening pass. Stefan was present for part of this session
and, unprompted, ran `/summon totality:provisioner` himself, which generated and displayed a
named Provisioner ("Ashby") with no errors — real, observed evidence that entity registration,
random-identity generation, and the client entity renderer registration all work end-to-end.
Beyond that one incidental, real data point, **none of Part M's other listed manual checks were
performed** (two Provisioners' independent Credits/stock in a live world, buy/reopen/no-reroll,
save-and-reload persistence, sold-out-remains-sold-out, SELL not adding to stock, or reading the
live shop-state payload) — not claimed here because they were not actually observed. The Testing
World client was left running at the end of this session for Stefan to drive these manually if
wanted; the automated `ProvisionerVerification` suite already covers the same guarantees at the
code level (persistence via a real NBT round-trip, independence via isolated dual-entity fixtures,
sold-out/no-reroll via the real roll-once guard fields), so manual play-testing would be
confirmatory, not load-bearing.

---

## 8. Known limitations and explicitly deferred scope

- The `SERVER_STARTED` self-test-harness entity-visibility limitation (Section 7 above) is now
  documented for a SECOND, independent case (Phase 3, on top of Phase 2's two checks) — worth
  revisiting generally if this harness's timing ever needs to prove live positive entity
  resolution through `Level#getEntity` directly, rather than working around it as both phases have.
- `TradingScreen.java`'s SELL mode remains the same visible-but-inert stub Phase 2 left it as —
  Phase 4 scope, untouched.
- No natural Provisioner spawning, structures, or villages — `/summon totality:provisioner` only,
  per explicit scope.
- Full list of everything else explicitly out of scope: Trading Screen visual redesign, finished
  SELL visual interaction, BUYBACK, buyback inventory, restocking, assortment rotation, Credit
  replenishment, the tutorial quest, a proximity quest trigger, Relationship, reputation,
  Persuasion modifiers, Investment, Pickpocket, Contacts, Blacksmith, Alchemist, merchant personal
  inventory, a broader transaction ledger, refund history, an idempotency framework, and the
  unrelated dedicated-server client-classloading fix.

---

## 9. Divergence from the task prompt, and why

- **Package choice:** assortment types live in `api/shop/assortment/` (one of the prompt's three
  candidates) since it sits directly beside `ShopRegistry`/`ShopTemplate`, which it structurally
  mirrors most closely. `MerchantStockEntry`/`MerchantStockProvider` live in `api/shop/` directly
  (sibling to `MerchantRuntime`), also a named candidate.
- **`TagValueOutput`/`TagValueInput` for the persistence round-trip test:** the prompt asked to
  "verify signatures against the mapped jar rather than assuming an older NBT API" — no mapped
  sources jar was locatable in this environment's Gradle cache, so the exact API
  (`ProblemReporter.DISCARDING`, `TagValueOutput.createWithContext`, `TagValueInput.create`) was
  written against the pattern already proven correct elsewhere in this codebase
  (`RitualDaisBlockEntity` etc.) plus reasonable, symmetric naming, then verified by actually
  compiling — one real compile error surfaced (`ValueOutput` interface lacks `buildResult()`,
  needed the concrete `TagValueOutput` type instead) and was fixed in one pass. No further
  guessing was needed; the remainder compiled and ran correctly on the first attempt.
- **Verification-only `startStockBackedTradeForVerification`:** not explicitly named in the task
  prompt, but a direct, minimal extension of the ALREADY-established `startTradeForVerification`
  isolation pattern, added specifically because five transaction-integration checks could not
  otherwise be exercised at `SERVER_STARTED` timing (Section 7 above) — this is the same kind of
  isolation the prompt's own Part L asked for ("Test pure helpers wherever possible" /
  "no synthetic entity left in the world" for the checks that don't need one).
- **45 checks, not a specific target count:** the prompt listed 50 illustrative check
  descriptions ("Test at least: 1 ... 50"); several were consolidated where one assertion body
  already covers multiple listed items without weakening any individual guarantee (e.g. the
  tool-tier sweep covers items 8, 9, and 10 in one check; the round-trip helper is reused across
  several persistence items). Every numbered category (assortment validation/generation, runtime
  stock, persistence, per-entity independence, transaction integration) has real, passing
  coverage.
