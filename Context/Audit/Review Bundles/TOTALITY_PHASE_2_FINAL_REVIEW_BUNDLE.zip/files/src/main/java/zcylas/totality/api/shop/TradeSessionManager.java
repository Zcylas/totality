package zcylas.totality.api.shop;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;
import zcylas.totality.api.core.component.ComponentProvider;
import zcylas.totality.api.economy.currency.CreditPaymentHelper;
import zcylas.totality.api.economy.currency.CurrencyComponents;
import zcylas.totality.entity.npc.TotalityNpcEntity;
import zcylas.totality.networking.shop.ShopEntryDisplayData;
import zcylas.totality.networking.shop.ShowShopStatePayload;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Server-side trade session tracking, mirroring {@link zcylas.totality.api.dialogue.DialogueSessionManager}'s
 * shape but without a branching state machine — a shop's catalog is static per session,
 * only the player's Credits/afford status changes between updates.
 */
public final class TradeSessionManager {

    private record ActiveTrade(
            Identifier shopId, ShopTemplate template, MerchantRuntime merchant,
            int npcEntityId, @Nullable UUID npcUuid, @Nullable ResourceKey<Level> npcDimension, Component npcName) {

        /** False for sessions deliberately opened without an NPC (verification, a future remote
         *  shop) — represented explicitly via {@code npcEntityId == -1}, never confused with a
         *  missing/removed NPC on an otherwise entity-backed session. */
        boolean isEntityBacked() { return npcEntityId != -1; }
    }

    private static final Map<UUID, ActiveTrade> SESSIONS = new HashMap<>();

    private TradeSessionManager() {}

    public static void register() {
        // No client connection remains to notify by the time the logical server has fully
        // stopped — just drop every session so nothing leaks into whatever world opens next in
        // the same client JVM (economy hardening pass, Part 3).
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> SESSIONS.clear());
    }

    public static void startTrade(ServerPlayer player, Identifier shopId, @Nullable Entity npc) {
        ShopTemplate template = ShopRegistry.INSTANCE.get(shopId);
        if (template == null) return;
        MerchantRuntime merchant = MerchantRuntimeRegistry.getOrCreate(player.level().getServer(), shopId);
        beginSession(player, shopId, template, merchant, npc);
    }

    /**
     * Verification-only entry point: starts a session against an explicitly supplied, isolated
     * {@link ShopTemplate} and {@link MerchantRuntime} instead of the shared, datapack-loaded
     * {@link ShopRegistry}/{@link MerchantRuntimeRegistry}-backed ones, so self-tests can never
     * create or mutate production shop/merchant state, and can freely fabricate fixtures (e.g. a
     * malformed negative-priced entry) that no real datapack authors (economy hardening pass,
     * Part 2). Non-entity-backed.
     */
    static void startTradeForVerification(ServerPlayer player, Identifier shopId, ShopTemplate template, MerchantRuntime runtime) {
        startTradeForVerification(player, shopId, template, runtime, null);
    }

    /** Entity-backed variant, for verifying {@link #revalidateNpc} itself (economy hardening
     *  pass, Part 4). */
    static void startTradeForVerification(
            ServerPlayer player, Identifier shopId, ShopTemplate template, MerchantRuntime runtime, @Nullable Entity npc) {
        beginSession(player, shopId, template, runtime, npc);
    }

    private static void beginSession(
            ServerPlayer player, Identifier shopId, ShopTemplate template, MerchantRuntime merchant, @Nullable Entity npc) {
        // Replacing an existing session must release ITS npc lock first — otherwise the previous
        // partner stays frozen/staring forever if a second trade opens without the first cleanly
        // ending (economy hardening pass, Part 4).
        releaseTradePartner(player, SESSIONS.get(player.getUUID()));

        Component npcName = npc != null ? npc.getName() : Component.empty();
        int npcId = npc != null ? npc.getId() : -1;
        UUID npcUuid = npc != null ? npc.getUUID() : null;
        ResourceKey<Level> npcDimension = npc != null ? npc.level().dimension() : null;

        SESSIONS.put(player.getUUID(),
                new ActiveTrade(shopId, template, merchant, npcId, npcUuid, npcDimension, npcName));
        if (npc instanceof TotalityNpcEntity totNpc) {
            totNpc.acquireInteractionLock(player);
        }
        sendState(player, false);
    }

    public static BuyResult handleBuy(ServerPlayer player, int index, int quantity) {
        ActiveTrade trade = SESSIONS.get(player.getUUID());
        if (trade == null) return BuyResult.rejected(BuyResult.Reason.NO_SESSION);
        if (!revalidateNpc(player, trade)) return BuyResult.rejected(BuyResult.Reason.NPC_INVALID);

        List<ShopEntry> sells = trade.template().sells();
        if (index < 0 || index >= sells.size()) return BuyResult.rejected(BuyResult.Reason.INVALID_INDEX);

        quantity = Math.max(1, Math.min(100, quantity));

        ShopEntry entry = sells.get(index);
        if (entry.price() < 0) return BuyResult.rejected(BuyResult.Reason.INVALID_PRICE);

        long total;
        try {
            total = Math.multiplyExact(entry.price(), (long) quantity);
        } catch (ArithmeticException overflow) {
            return BuyResult.rejected(BuyResult.Reason.OVERFLOW);
        }

        // Validate the merchant's balance can safely absorb this BEFORE charging the player —
        // a failed BUY must never charge the player, and merchant Credits must never change on
        // a failed attempt (Section 11 step 4 / Part F).
        MerchantRuntime merchant = trade.merchant();
        long newMerchantCredits;
        try {
            newMerchantCredits = Math.addExact(merchant.currentCredits(), total);
        } catch (ArithmeticException overflow) {
            return BuyResult.rejected(BuyResult.Reason.OVERFLOW);
        }

        if (!CreditPaymentHelper.pay(player, total)) return BuyResult.rejected(BuyResult.Reason.CANNOT_AFFORD);

        merchant.setCurrentCredits(newMerchantCredits);

        // Individual copies, not one stack multiplied by count — a full inventory drops
        // the remainder on the ground instead of blocking/rolling back the purchase.
        for (int i = 0; i < quantity; i++) {
            ItemStack gift = entry.stack().copy();
            if (!player.getInventory().add(gift)) {
                player.drop(gift, false);
            }
        }

        sendState(player, false);
        return BuyResult.success(total, quantity);
    }

    /**
     * Server-authoritative SELL — the client only ever supplies a slot index and a quantity;
     * every other fact (the real stack, its count, the merchant's acceptance/value/Credits, and
     * the resulting quote) is re-read and revalidated here, never trusted from the client. See
     * design document Section D for the full validation order this method implements:
     *
     * <ol>
     *   <li>An active trade session exists for the player.
     *   <li>An entity-backed session's NPC is still present, alive, the same entity, in the same
     *       dimension, in range, and still owns the interaction lock ({@link #revalidateNpc}).
     *   <li>{@code quantity} is positive.
     *   <li>{@code slotIndex} is a valid inventory slot.
     *   <li>The real stack in that slot is non-empty.
     *   <li>The real stack holds at least {@code quantity}.
     *   <li>The merchant accepts the item ({@link MerchantSellQuoteView}).
     *   <li>The item has a resolvable central base value ({@link MerchantSellQuoteView}).
     *   <li>A SELL quote can be produced ({@link MerchantSellQuoteView}).
     *   <li>The quote total is valid and does not overflow ({@link MerchantSellQuoteView}).
     *   <li>The merchant has enough {@code currentCredits} ({@link MerchantSellQuoteView}).
     *   <li>The player can safely receive the payout ({@link CreditPaymentHelper#canReceive}).
     * </ol>
     *
     * <p>Every precondition is confirmed before any mutation. The commit itself (remove item,
     * pay player, decrement merchant Credits) uses operations already proven safe by the
     * preceding validation, so no explicit rollback machinery is needed — nothing in the commit
     * step can fail after validation has passed.
     */
    public static SellResult handleSell(ServerPlayer player, int slotIndex, int quantity) {
        ActiveTrade trade = SESSIONS.get(player.getUUID());
        if (trade == null) return SellResult.rejected(SellResult.Reason.NO_SESSION);
        if (!revalidateNpc(player, trade)) return SellResult.rejected(SellResult.Reason.NPC_INVALID);

        if (quantity <= 0) return SellResult.rejected(SellResult.Reason.INVALID_QUANTITY);

        Inventory inventory = player.getInventory();
        if (slotIndex < 0 || slotIndex >= inventory.getContainerSize()) {
            return SellResult.rejected(SellResult.Reason.INVALID_SLOT);
        }

        ItemStack real = inventory.getItem(slotIndex);
        if (real.isEmpty()) return SellResult.rejected(SellResult.Reason.EMPTY_STACK);
        if (real.getCount() < quantity) return SellResult.rejected(SellResult.Reason.INSUFFICIENT_STACK);

        MerchantRuntime merchant = trade.merchant();
        MerchantSellQuoteView quote = MerchantSellQuoteView.compute(player, merchant, real, real.getCount(), quantity);
        if (!quote.sellable()) {
            return SellResult.rejected(SellResult.Reason.NOT_SELLABLE, quote.rejectionReason().orElse("unknown"));
        }

        long payout = quote.totalPayout();
        if (!CreditPaymentHelper.canReceive(player, payout)) {
            return SellResult.rejected(SellResult.Reason.CANNOT_RECEIVE);
        }

        inventory.removeItem(slotIndex, quantity);
        CreditPaymentHelper.receive(player, payout);
        merchant.setCurrentCredits(merchant.currentCredits() - payout);

        sendState(player, false);
        return SellResult.success(payout, quantity);
    }

    public static void endTrade(ServerPlayer player) {
        ActiveTrade removed = SESSIONS.remove(player.getUUID());
        releaseTradePartner(player, removed);
        ServerPlayNetworking.send(player, new ShowShopStatePayload(
                -1, Component.empty(), List.of(), 0, 0, true
        ));
    }

    public static boolean isTrading(ServerPlayer player) {
        return SESSIONS.containsKey(player.getUUID());
    }

    /**
     * Re-validates an entity-backed session's NPC immediately before a BUY/SELL commits (economy
     * hardening pass, Part 4): the entity must still exist, be alive and not removed, be the SAME
     * entity (UUID match, not merely a reused numeric id), share the player's current dimension,
     * be within the existing NPC interaction range, and — for a {@link TotalityNpcEntity} — still
     * have this player holding its interaction lock. Non-entity-backed sessions ({@code npcEntityId
     * == -1}) are exempt — there is deliberately no NPC to go stale for those.
     *
     * <p>On failure, ends the session (releasing any interaction lock and notifying the client)
     * so the caller can simply refuse to mutate anything and return.
     */
    private static boolean revalidateNpc(ServerPlayer player, ActiveTrade trade) {
        if (!trade.isEntityBacked()) return true;

        Entity npc = resolveRecordedNpc(player, trade);
        boolean valid = npc != null
                && npc.isAlive()
                && !npc.isRemoved()
                && player.level() == npc.level()
                && player.distanceToSqr(npc) <= TotalityNpcEntity.INTERACTION_RANGE_SQR
                && (!(npc instanceof TotalityNpcEntity totNpc) || totNpc.isInteractionLockOwnedBy(player));

        if (!valid) {
            endTrade(player);
        }
        return valid;
    }

    /**
     * Resolves the entity an entity-backed {@link ActiveTrade} recorded — but ONLY if the
     * resolved entity's UUID still matches {@code trade.npcUuid()} (economy hardening
     * correction pass, Part 1). A numeric entity id can be reused by an unrelated entity after
     * the original NPC is removed; without this check, {@link #releaseTradePartner} could
     * resolve that REPLACEMENT entity by id alone and release ITS interaction lock instead of
     * correctly finding nothing. Centralizing UUID-safe resolution here means both
     * {@link #revalidateNpc} and {@link #releaseTradePartner} share the same guarantee.
     */
    @Nullable
    private static Entity resolveRecordedNpc(ServerPlayer player, ActiveTrade trade) {
        if (trade.npcDimension() == null || trade.npcUuid() == null) return null;
        Level npcLevel = player.level().getServer().getLevel(trade.npcDimension());
        if (npcLevel == null) return null;
        Entity npc = npcLevel.getEntity(trade.npcEntityId());
        return matchesUuid(npc, trade.npcUuid()) ? npc : null;
    }

    /**
     * True only if {@code candidate} is non-null and its UUID equals {@code expectedUuid} — the
     * exact guarantee {@link #resolveRecordedNpc} enforces before letting a caller (
     * {@link #revalidateNpc}, {@link #releaseTradePartner}) act on a resolved entity at all.
     * Extracted as its own package-visible predicate (economy hardening correction pass, Part 1)
     * so it can be verified directly against two real, distinct entity objects without depending
     * on a numeric id ever genuinely resolving to the wrong one through live level lookup — a
     * real id collision cannot be forced through the public entity-spawning API (ids come from a
     * monotonically increasing counter, never reused within one running server), and this suite
     * runs at {@code SERVER_STARTED}, before any tick has processed a freshly spawned entity into
     * {@code Level#getEntity(int)}'s lookup, so a live end-to-end resolution cannot be exercised
     * deterministically here either. Testing this predicate directly is sound because it is the
     * ONLY gate in {@code resolveRecordedNpc} that depends on comparing two UUIDs — the null and
     * level-lookup guards around it are simple, low-risk delegation to well-established APIs.
     */
    static boolean matchesUuid(@Nullable Entity candidate, UUID expectedUuid) {
        return candidate != null && expectedUuid.equals(candidate.getUUID());
    }

    private static void releaseTradePartner(ServerPlayer player, @Nullable ActiveTrade trade) {
        if (trade == null || !trade.isEntityBacked()) return;
        if (resolveRecordedNpc(player, trade) instanceof TotalityNpcEntity totNpc) {
            totNpc.releaseInteractionLock();
        }
    }

    private static void sendState(ServerPlayer player, boolean ended) {
        ActiveTrade trade = SESSIONS.get(player.getUUID());
        if (trade == null) return;

        long walletBalance = CurrencyComponents.WALLET.get((ComponentProvider) player).getValue();
        long physicalCredits = CreditPaymentHelper.physicalCredits(player);

        List<ShopEntryDisplayData> display = new ArrayList<>();
        for (ShopEntry entry : trade.template().sells()) {
            boolean affordable = CreditPaymentHelper.canAfford(player, entry.price());
            display.add(new ShopEntryDisplayData(entry.stack(), entry.price(), affordable));
        }

        ServerPlayNetworking.send(player, new ShowShopStatePayload(
                trade.npcEntityId(),
                Component.literal(trade.template().name()),
                display,
                walletBalance,
                physicalCredits,
                ended
        ));
    }
}
