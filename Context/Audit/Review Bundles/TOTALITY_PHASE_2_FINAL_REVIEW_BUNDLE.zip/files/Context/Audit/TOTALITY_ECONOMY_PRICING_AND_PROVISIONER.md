TOTALITY — ECONOMY PRICING AND FIRST PROVISIONER
(New document. DOCUMENTATION-ONLY design pass, 2026-07-13. No
implementation code was written or changed while producing this
document — see the Implementation Order section for what comes next.)

STATUS: ADOPTED DECISIONS from Stefan's 2026-07-13 design pass,
reconciled against the actual current codebase and against
TOTALITY_ECONOMY_BANKING_TRADING.txt / TOTALITY_POST_AUDIT_DESIGN_
DECISIONS.md / TOTALITY_DIALOGUE_RELATIONSHIP_DESIGN.md. Sections
marked PLAYTEST VALUE are explicitly non-final balance numbers, not
locked design. Same ADOPTED/PROPOSED/TBD convention as every other
Totality design document.

Precedence: this document extends TOTALITY_ECONOMY_BANKING_TRADING.txt
Sections 7-9 (Item Values, First Ordinary Trader) with the concrete
Provisioner build. Where the two disagree, this document — being the
more recent, code-reconciled pass — wins; TOTALITY_ECONOMY_BANKING_
TRADING.txt should be treated as superseded on those specific points
(noted inline below) rather than silently contradicted.

================================================================================
0. RECONCILIATION SUMMARY (read this first)
================================================================================
Before writing the sections below, the actual codebase was audited.
Key findings that shape every decision here:

  - `ShopEntry` (`api/shop/ShopEntry.java`, `record(ItemStack stack,
    long price)`) and `ShopTemplate` (`api/shop/ShopTemplate.java`,
    `record(String name, List<ShopEntry> sells)`) are IMMUTABLE, JSON-
    authored, and SHARED across every NPC that references the same
    `shop_id` via `ShopRegistry`. There is currently no per-NPC runtime
    state at all — every Provisioner pointing at the same `shop_id`
    would show the IDENTICAL stock. This directly conflicts with
    Section 3's requirement that EACH individual Provisioner rolls and
    persists its OWN assortment. Reconciled in Section 3 below by
    introducing a new per-entity runtime layer rather than trying to
    force individual variation into the shared, immutable
    `ShopTemplate`.

  - No `ItemValue`/base-value/pricing registry exists anywhere in the
    codebase (confirmed by grep — the only hits were unrelated vanilla
    `AttributeInstance.getBaseValue()` calls). `TradingScreen`'s own
    code comment already says the quiet part out loud: "selling
    requires a item-value system that doesn't exist yet." Section 1
    below is genuinely new infrastructure, not a rename of something
    that already exists.

  - `WalletComponent` (`api/economy/currency/WalletComponent.java`) is
    hard-coupled to `ServerPlayer` in its constructor — it is a PLAYER
    account balance, not a general-purpose ledger. It CANNOT be reused
    as-is for a merchant's business Credits (Section 2). A merchant
    balance needs its own field, not a repurposed Wallet.

  - `CreditPaymentHelper.pay`/`canAfford` already implement the
    "spend Wallet first, then physical Credits" resolution the player
    side needs — this is reused unchanged for BUY. It does not yet
    know how to pay a player FROM a merchant's pool (SELL) — that's new
    logic in the same class, not a parallel payment helper.

  - CORRECTION PASS (2026-07-13): the approved Provisioner stock
    contains a Water Bottle (8 Credits) and a Potion of Healing (80
    Credits) — both `minecraft:potion`, distinguished only by the
    `DataComponents.POTION_CONTENTS` data component (confirmed in code,
    already used the same way in `InventoryEquipHelper`/
    `HotbarSlotMap`/`InventoryActionHandler`). A bare item-ID key
    cannot represent this. Both `ItemValueRegistry` (Section 1a) and
    `ProvisionerAssortmentPool` (Section 3a) are corrected to support
    full, component-aware `ItemStack` matching (reusing `ItemStack.
    CODEC`, the same codec `ShopEntry` already uses — no new
    potion-specific field), which also means both now need the SAME
    `RegistryOps`/`ServerLifecycleEvents.SERVER_STARTED` loading
    pattern `ShopRegistry` already uses, not the simpler pattern this
    document originally (incorrectly) proposed for them.

  - The "existing random name and skin/category system" referenced in
    project memory is, in actual code, a RANDOM GENDER + NAME system
    only: `NpcGender` (`MALE`/`FEMALE`) and `NpcNameRegistry` (loads
    `data/totality/npc_names/{male,female,neutral}.json`). **No
    separate "skin category" axis exists in code.** Section 8 below
    corrects the framing to match what's actually implemented — the
    Provisioner's "generic identity" is gender + name only, not a
    richer skin-category system that would need to be invented from
    scratch. If a broader appearance-variation axis is wanted later,
    that's new scope, not something this document should assume exists.

  - `BankerNpcEntity` (`entity/npc/BankerNpcEntity.java`) is the real
    precedent for "a dedicated NPC gets its own entity class": it's a
    THIN subclass of `TotalityNpcEntity` that overrides `mobInteract`
    only, no new persisted fields. The Provisioner (Section 8) follows
    the same shape, plus the new persisted runtime fields Section 2/3
    require (which Banker didn't need).

  - The Quest system (`api/quest/QuestManager.java` etc.) currently
    triggers objective completion via hardcoded per-quest static hooks
    called from specific gameplay events (e.g. `onPhoneEquipped`), not
    from a generic proximity/trigger system. Section 9's "approach a
    Provisioner" trigger is NEW plumbing in that same hardcoded-hook
    style, not an existing generic trigger this document can just
    reference.

================================================================================
1. CENTRAL PRICING
================================================================================
ADOPTED (new infrastructure — see Section 0, no prior art to extend).

  - Ordinary item prices belong to a central, shared item-value
    registry — NOT repeated per shop JSON entry. `ShopEntry.price`
    currently duplicates a price per shop; that field's MEANING
    changes under this design (Section 1d).
  - Value resolution is keyed by MORE than a bare item ID where
    needed: a plain item-ID rule is sufficient and remains convenient
    for ordinary items (bread, coal, planks, leather, tools), but some
    items share one item ID across economically distinct variants
    (Section 1a) — a more specific, component-aware rule must be able
    to win over the plain fallback for those.
  - Normal retail price = 100% of adjusted base value.
  - Normal player sale payout = 50% of adjusted base value. (Matches
    TOTALITY_ECONOMY_BANKING_TRADING.txt Section 7b, which already
    adopted this 50% figure — this document supplies the concrete
    registry that section didn't yet have.)
  - A merchant ACCEPTING an item (Section 5) is a separate question
    from the item HAVING a value — an item can have a base value and
    still be un-sellable to a given merchant.
  - Exceptional authored offers may override the normal price (e.g. a
    quest-specific discount, a unique item with no sensible base
    value). `ShopEntry.price`, reinterpreted, becomes this override
    slot rather than the only source of price.
  - `ItemRarity` (the mob/loot rarity tag) does NOT automatically
    affect economic value — rarity and price are deliberately
    decoupled axes.
  - Condition, quality, freshness, enchantment, trait, specialization,
    Relationship, reputation, and Persuasion modifiers must all modify
    the FINAL computed price without mutating the central base value —
    they are multipliers/adjustments applied at quote time, not writes
    to the registry.
  - All price calculations are server-authoritative — never trust a
    client-supplied price, matching the existing pattern in
    `TradeSessionManager.handleBuy` (server recomputes cost from
    `entry.price() * quantity`, never trusts client math).

--------------------------------------------------------------------------------
1a. Proposed shape — component-aware matching, most-specific wins
--------------------------------------------------------------------------------
  CORRECTED (2026-07-13 pass): a bare item-ID key is NOT sufficient.
  The approved Provisioner stock (Section 3/4) already contains a
  counterexample — a Water Bottle (8 Credits) and a Potion of Healing
  (80 Credits) are BOTH `minecraft:potion`, distinguished only by the
  `minecraft:potion_contents` data component (confirmed in code:
  `net.minecraft.core.component.DataComponents.POTION_CONTENTS`, used
  the same way in `InventoryEquipHelper`/`HotbarSlotMap`/
  `InventoryActionHandler` to tell potion stacks apart). This is not a
  potion-only quirk — enchanted books, filled containers, maps, and
  future custom/component-defined items all share this same "one item
  ID, several economically distinct variants" shape. Rather than
  invent a potion-specific exception, the registry supports two rule
  kinds from day one, with a defined precedence between them:

  PROPOSED — package `api/economy/value/` (sibling to the existing
  `api/economy/currency/`):

    public record ItemValueRule(
        Identifier itemId,
        Optional<ItemStack> componentMatch,   -- ABSENT = plain item-ID
                                                  fallback rule. PRESENT
                                                  = a PARTIAL, REQUIRED-
                                                  COMPONENT predicate,
                                                  authored as a
                                                  reference stack via
                                                  the SAME
                                                  `ItemStack.CODEC`
                                                  `ShopEntry` already
                                                  uses (no new codec
                                                  invented — Section 2
                                                  reuses this exact
                                                  type too).
        long baseValue
    ) {}

  CLARIFIED (2026-07-13, second correction pass) — exact
  `componentMatch` matcher semantics, stated precisely rather than by
  example:

  - The item ID must match (`stack.getItem()` equals the rule's
    `itemId`) — this check always applies, component-aware or not.
  - Every component EXPLICITLY AUTHORED on the reference stack must
    equal the real stack's value for that same component type. A
    Healing-Potion rule that only sets `POTION_CONTENTS` only checks
    `POTION_CONTENTS` — it is a PARTIAL predicate over the components
    it actually declares, not a full-stack equality check.
  - Any component the reference stack does NOT set is IGNORED on the
    real (target) stack — an unrelated component present on the real
    stack (custom name, other future components) never breaks a match
    it would otherwise satisfy.
  - Stack COUNT is ignored entirely by matching — `componentMatch` is a
    components-only predicate; a reference stack authored as count 1
    matches a real stack of any count.
  - A component-aware rule (`componentMatch` present) OUTRANKS a plain
    item-ID fallback rule (`componentMatch` absent) for the same
    `itemId` — most-specific wins, per Section 1.
  - SPECIFICITY IS THE NUMBER OF EXPLICITLY AUTHORED COMPONENT ENTRIES.
    Among every rule that matches a given real stack, the rule with
    MORE declared component entries wins — a rule declaring 2
    components beats one declaring only 1, which beats the plain
    item-ID fallback (0). This is what "most-specific wins" means
    precisely, and it is NOT an error for two DIFFERENTLY-specific
    rules to both be capable of matching the same real stack — that is
    the normal, expected, EXPECTED-TO-COEXIST case (e.g. a plain
    Healing-Potion rule and a more specific "named Healing Potion"
    rule can both legitimately match a custom-named healing potion;
    the more specific one simply wins).
  - AMBIGUITY IS SCOPED TO EQUALLY SPECIFIC RULES ONLY. Two rules for
    the same `itemId` can only conflict with each other if they
    declare the SAME NUMBER of components — a load-time error never
    applies across two rules of different specificity, only between
    ties. Within a tie (same declared-component count), two further
    cases are distinguished:
      - MUTUALLY EXCLUSIVE, NOT AMBIGUOUS, BOTH KEPT: the tied rules
        share at least one declared component key but require
        DIFFERENT values for it (e.g. Water Bottle and Potion of
        Healing both declare only `POTION_CONTENTS`, with different
        required potion types) — no single real stack could ever
        satisfy both simultaneously, so they never actually compete
        and both are kept.
      - AMBIGUOUS, LOAD-TIME ERROR, BOTH REJECTED: the tied rules
        declare DIFFERENT component keys (or the same keys with
        agreeing values) such that a single real stack COULD satisfy
        every declared component from both simultaneously, with
        neither being more specific than the other. `ItemValueRegistry`
        must FAIL VALIDATION for that pair at load time (reject both,
        log a hard error) rather than silently picking whichever rule
        happened to load first or last. Load order must never be a de
        facto tie-breaker.
      - EXACT DUPLICATES (identical declared components AND values,
        including two plain fallbacks) are rejected the same way, as
        the trivial case of a tie.
      - Every pair within an item's rule set is checked for these
        conflicts independently — a rule already rejected against one
        conflicting rule must still be compared against every other
        rule for the same item, so three mutually duplicate/ambiguous
        rules are ALL rejected, not just the first two compared.

    static Optional<ItemValueRule> pickMostSpecificMatch(
        List<ItemValueRule> candidates, ItemStack stack
    ) {
        // among every rule in `candidates` that matches `stack`,
        // returns the one with the most declared component entries;
        // a plain fallback (0 declared entries) is used only if no
        // component-aware rule matches. Ambiguous ties are impossible
        // here — they are rejected at load time by validateAndGroup,
        // so this never needs to break one itself.
    }

    static Map<Item, List<ItemValueRule>> validateAndGroup(
        Map<Identifier, ItemValueRule> parsed
    ) {
        // groups rules by item, then rejects (logs, excludes from the
        // result — never crashes) every rule that is an exact
        // duplicate or an ambiguous tie with another rule for the
        // SAME item, per the rules above. Pure and package-private —
        // directly testable against a hand-built map, no datapack
        // load required.
    }

  Simple entries (bread, coal, planks, leather, tools) author ONLY
  `itemId` + `baseValue`, `componentMatch` absent — exactly as
  convenient as a bare item-ID rule, no forced complexity for the
  common case. Component-sensitive entries (potion variants, and any
  future enchanted book/map/filled-container/custom-food value) add a
  `componentMatch` reference stack. This is the general mechanism the
  instruction asked for — not a hardcoded potion branch.

  REGISTRY LOADING, CORRECTED: because `componentMatch` reuses
  `ItemStack.CODEC` (component-bearing — `PotionContents` resolves a
  `Holder<Potion>`, a registry entry, exactly like the enchantment
  case that already forced `ShopRegistry` off the simple reload-
  listener pattern), `ItemValueRegistry` needs `RegistryOps` built from
  real `RegistryAccess`, the SAME `ServerLifecycleEvents.SERVER_STARTED`
  pattern `ShopRegistry` already uses (`RegistryOps.create(JsonOps.
  INSTANCE, server.registryAccess())`) — NOT the simpler
  `SimplePreparableReloadListener` pattern `QuestRegistry`/
  `NpcNameRegistry` use. The earlier draft of this document claimed the
  simple pattern would suffice specifically because it assumed a bare-
  ID-only key; that assumption no longer holds once component-aware
  rules exist in the SAME registry, so the whole registry adopts the
  more capable loading pattern uniformly rather than trying to split
  rules across two differently-loaded files.

--------------------------------------------------------------------------------
1b. Price resolution service — corrected to accept transaction context
--------------------------------------------------------------------------------
  CORRECTED (2026-07-13 pass): the original two-argument shape
  (`quoteRetailPrice(ItemStack)`/`quoteSellPayout(ItemStack)`) has no
  room for the modifier chain Section 1 already lists (Relationship,
  reputation, Persuasion, condition, quantity, authored override,
  player/merchant identity) without replacing every call site later
  when those modifiers arrive. PROPOSED — a small stateless helper
  (name TBD, candidate `ItemPricingService`), still NOT a new parallel
  payment path — it only computes a quote, `CreditPaymentHelper` still
  moves the money:

    public record PricingContext(
        ServerPlayer player,
        Optional<Identifier> merchantId,        -- e.g. shopId, or a
                                                    Provisioner entity's
                                                    identity once
                                                    Section 8 exists
        TransactionType direction,               -- BUY or SELL, reuses
                                                    (or aligns with) the
                                                    TransactionType enum
                                                    already PROPOSED in
                                                    TOTALITY_ECONOMY_
                                                    BANKING_TRADING.txt
                                                    Section 6
        Optional<Long> authoredOverride          -- Section 1c's
                                                    ShopEntry-supplied
                                                    override, if any
        // future, NOT required to exist yet: relationship/reputation/
        // Persuasion inputs, merchant specialization — added to this
        // record later without touching quoteRetail/quoteSell's own
        // signatures
    ) {}

    public record PriceQuote(
        long unitPrice, int quantity, long total,
        TransactionType direction
        // optional modifier/breakdown info — NOT a full user-facing
        // breakdown UI yet (Section 1f), just enough for the caller to
        // display/validate against
    ) {}

    PriceQuote quoteRetail(ItemStack stack, int quantity, PricingContext context);
    PriceQuote quoteSell(ItemStack stack, int quantity, PricingContext context);

  Exact field list on `PricingContext`/`PriceQuote` is PROPOSED, not
  locked — the ARCHITECTURAL RULE that matters is that pricing calls
  take context and quantity from day one, so adding a modifier later
  (Relationship, Persuasion, etc., all still individually TBD/future
  work) extends the context record rather than requiring every call
  site to be rewritten. Do not build a full user-facing price-breakdown
  UI now — no existing code supports one yet (`TradingScreen` currently
  shows a flat price per entry, see Section 1f).

--------------------------------------------------------------------------------
1c. Authored-offer override
--------------------------------------------------------------------------------
  `ShopEntry.price` (or its future per-entry-stock equivalent, Section
  3) is treated as an EXPLICIT OVERRIDE of the central computed price
  when present, not a duplicate of it. A shop entry with no override
  should be resolvable by item id alone against
  `ItemValueRegistry` — exact "how does an entry OPT OUT of an
  override and fall back to central pricing" field shape is TBD
  (candidate: make `price` `Optional<Long>` for future authored shops,
  while existing `test_trader.json`-style shops keep an explicit price
  for backward compatibility).

--------------------------------------------------------------------------------
1d. Conflict flagged against TOTALITY_ECONOMY_BANKING_TRADING.txt
--------------------------------------------------------------------------------
  That document's Section 7a says items "receive an `ItemValue` at
  registration or equivalent static data" — this document's
  `ItemValueRegistry` is DATA-DRIVEN (JSON) rather than registration-
  time, to match the actual pattern every other Totality registry in
  this codebase uses (`ShopRegistry`, `QuestRegistry`,
  `NpcNameRegistry` — all JSON-datapack-driven, none use compile-time
  registration). Treat that document's "at registration" wording as
  superseded by this document's data-driven approach, consistent with
  Section 0's precedence rule.

--------------------------------------------------------------------------------
1e. Server-authoritative displayed quotes (canonical rule)
--------------------------------------------------------------------------------
  ADOPTED. This is not a new philosophy — it's the SAME pattern
  `TradeSessionManager` already follows for BUY today (confirmed in
  code: `sendState` builds server-computed `ShopEntryDisplayData(stack,
  price, affordable)` and sends it to the client; `handleBuy` then
  recomputes `entry.price() * quantity` itself and never trusts
  anything the client sent back) — this section just states it as an
  explicit canonical rule so it's not lost once pricing becomes
  context-/player-specific:

  - The SERVER computes the price quote (`PriceQuote`, Section 1b)
    displayed by the client.
  - The CLIENT only displays the server-issued quote — it does not
    independently determine the authoritative price.
  - When BUY or SELL is submitted, the server RECALCULATES or
    RE-VALIDATES the current quote before committing the transaction —
    a quote the client is holding may be stale by the time it submits.
  - A stale or manipulated client-supplied quote must never be able to
    produce an invalid price or a duplication exploit.

  This matters MORE once prices become player-specific (Relationship,
  Persuasion, reputation, Section 1b's `PricingContext`) than it does
  today, since two different players could legitimately see two
  different quotes for the identical item at the identical merchant —
  the server, not the client, is what decides which one is honored at
  commit time. No networking is designed/changed in this pass — this
  is a canonical rule for whoever implements Section 11 step 2 to
  build against.

--------------------------------------------------------------------------------
1f. Rounding — TBD
--------------------------------------------------------------------------------
  UNRESOLVED, explicitly flagged rather than decided in this pass.
  Percentage-based modifiers (the 50% sell payout itself, and any
  future condition/Relationship/Persuasion percentage modifier) can
  produce fractional Credit results, and Credits are a whole-number
  currency (`WalletComponent`/`CreditsItem` both use `long`). Open
  questions, none decided here:

  - Whether BUY totals round up, down, or via another rule (e.g.
    banker's rounding) when a modifier produces a fraction.
  - Whether SELL totals round the same way, or deliberately differently
    (e.g. always rounding a payout DOWN and a cost UP, so the merchant
    is never disadvantaged by rounding, is one candidate but NOT
    adopted here).
  - Whether rounding is applied PER UNIT (round each individual item's
    price, then multiply by quantity) or ONCE on the full transaction
    total (compute the exact fractional total, round only at the end)
    — these two approaches can disagree for large quantities and must
    be picked deliberately, not left to fall out of implementation
    order.
  - How to prevent a zero-price or quantity-inflation exploit (e.g. a
    fractional-cent item that rounds down to 0 Credits per unit,
    bought at very high quantity for an effectively free haul) once
    any modifier can push a price below 1 Credit.

  No canonical Totality document currently resolves this — do not
  choose a rule implicitly by whatever the first implementation
  happens to do; decide it explicitly when Section 11 step 2 (context-
  aware pricing service) is actually built.

  STILL UNRESOLVED after Phase 1's implementation (2026-07-13 hardening
  pass) — flagged explicitly rather than quietly settled by what the
  code happens to do today: `ItemPricingService`'s SELL quote computes
  `unitPrice = baseValue / 2` using plain integer division, which
  FLOORS any odd `baseValue`. Every currently-authored base value
  (Section 4) is even, so this floor never actually discards anything
  today — that is a property of the CURRENT DATA, not a rounding
  policy. The following remain explicitly open and MUST be settled
  before functional SELL ships or before any odd base value is
  authored, whichever comes first:
    - Whether an odd base value's SELL payout floors, rounds to
      nearest, or ceilings.
    - How a future percentage modifier (condition/Relationship/
      Persuasion/reputation) composes with the existing 50% split —
      same open per-unit-vs-total-rounding question as above.
    - Whether a minimum positive payout is guaranteed once modifiers
      exist (e.g. a floored-to-zero SELL payout for a genuinely
      valuable item would be a real design problem, not just a
      cosmetic rounding quirk).
  Do NOT read `baseValue / 2` as this document's chosen rounding rule —
  it is a placeholder that happens to be exact for the current data,
  not a decision. Do not introduce floating-point pricing to work
  around this — Credits remain a whole-number `long` currency
  end-to-end; whatever rounding rule is eventually chosen must resolve
  in integer arithmetic.

================================================================================
2. PROVISIONER BUSINESS CREDITS
================================================================================
ADOPTED, PLAYTEST VALUE for the number itself.

  - `baseStartingCredits = 300` Credits. Baseline, not a maximum.
  - Player purchases (BUY) increase the merchant's `currentCredits`.
  - Player sales (SELL) decrease the merchant's `currentCredits`.
  - The merchant cannot buy items beyond its `currentCredits` — a SELL
    that would exceed the pool is rejected or quantity-limited.
  - `currentCredits` may exceed `baseStartingCredits` (no hard ceiling
    from ordinary trading — only Investment (Section 2b/10) permanently
    raises the merchant's BASELINE, distinct from its live balance —
    see Section 2b for the corrected terminology).
  - Replenishment/reset behavior is TBD (ties into
    TOTALITY_ECONOMY_BANKING_TRADING.txt Section 7c's "next restock
    time" concept — whether Credit pool and item restock share one
    timer or are independent is not decided).

  This confirms and reuses the accounting direction already locked in
  TOTALITY_ECONOMY_BANKING_TRADING.txt Section 7d (buy increases pool,
  sell decreases it — the doc's own correction of an earlier backwards
  note). No conflict here, just a concrete number for it.

--------------------------------------------------------------------------------
2a. Where this actually lives (reconciliation, not in the original
    request but required to make it buildable)
--------------------------------------------------------------------------------
  `currentCredits` CANNOT be a `WalletComponent` (Section 0 — that
  class is `ServerPlayer`-coupled). It also is NOT physically-held
  inventory (Section 7 explicitly requires the full business balance
  not exist in the merchant's pocket). PROPOSED: a plain persisted
  field on the Provisioner entity itself (Section 8's
  `ProvisionerNpcEntity`), NBT key candidate `"CurrentCredits"` (long),
  read/written the same way `TotalityNpcEntity` already persists
  `dialogueId`/`shopId`/`Gender` — no new component-framework machinery
  needed for a single per-entity long.

--------------------------------------------------------------------------------
2b. Baseline vs. live balance — corrected terminology
--------------------------------------------------------------------------------
  CORRECTED (2026-07-13 pass): the original draft conflated a
  merchant's live trading balance with its authored/investable
  baseline by saying Investment "permanently increases the
  `currentCredits` floor." That mixes two different concepts. Five
  distinct terms, kept separate:

    baseStartingCredits          Authored baseline, currently 300
                                  Credits (Section 2), a PLAYTEST VALUE.
    permanentInvestmentBonus     FUTURE persisted per-merchant bonus
                                  created by player investment (Section
                                  10) — TBD, not built yet.
    applicablePersuasionMasteryBonus
                                  FUTURE player/merchant-context bonus
                                  from Persuasion masteries (Section
                                  10) — TBD, exact behavior not decided.
    effectiveStartingCredits     CONCEPTUALLY derived:

                                    effectiveStartingCredits =
                                      baseStartingCredits
                                      + permanentInvestmentBonus
                                      + applicable baseline modifiers

                                  This is what a merchant's balance
                                  replenishes TOWARD (Section 2's
                                  "Replenishment/reset behavior is
                                  TBD" — the exact mechanism is still
                                  unresolved, only the TARGET value's
                                  composition is clarified here).
    currentCredits                The LIVE merchant business balance,
                                  changed immediately by every BUY
                                  (increases it) and SELL (decreases
                                  it) — Section 2's existing field,
                                  unchanged by this correction.

  Investment does NOT directly turn `currentCredits` into a permanent
  floor — it raises `permanentInvestmentBonus`, which raises
  `effectiveStartingCredits`, which is a separate concept from whatever
  `currentCredits` happens to be at any given moment from ordinary
  trading. The exact replenishment behavior toward
  `effectiveStartingCredits` remains TBD, as it already was.

================================================================================
3. PROVISIONER RANDOMIZED STOCK
================================================================================
ADOPTED direction, PLAYTEST VALUE for every specific item/price/
quantity/probability below.

  Each individual Provisioner receives a balanced persistent
  assortment, generated ONCE and never rerolled by reopening the shop,
  relogging, restarting the server, or unloading/reloading the NPC.

  Normal assortment (PLAYTEST VALUES):

    Guaranteed:
      Torch x16 — 4 Credits each
      Bread x6 — 12 Credits each
      Water Bottle x4 — 8 Credits each

    Select four distinct common entries from:
      Oak Planks x32 — 2 Credits each
      Coal x16 — 8 Credits each
      String x8 — 10 Credits each
      Leather x6 — 16 Credits each
      Glass Bottle x8 — 6 Credits each
      Apple x8 — 8 Credits each

    Select one cooked-food entry:
      Cooked Beef x6 — 18 Credits each
      Cooked Porkchop x6 — 18 Credits each

    Select one tool entry (Stone tier, stock 2):
      Stone Shovel — 24 Credits / Stone Sword — 28 / Stone Pickaxe —
      32 / Stone Axe — 36

    PLAYTEST VALUE: 10% chance the tool slot uses one Iron tool
    instead (stock 1): Iron Shovel — 72 / Iron Sword — 84 / Iron
    Pickaxe — 96 / Iron Axe — 108.

  Provisioners sell emergency tools but do not BUY tools. Tools,
  weapons, armor, ores, and ingots primarily belong to the future
  Blacksmith market (net-new NPC, not built yet).

--------------------------------------------------------------------------------
3a. Where this lives (the real reconciliation)
--------------------------------------------------------------------------------
  Per Section 0, the existing `ShopTemplate`/`ShopRegistry` are shared,
  immutable, JSON-authored data — they CANNOT hold per-instance
  variation. Two layers are needed, kept deliberately separate:

    1. A STATIC, SHARED "assortment pool" definition — the pick-lists
       and probabilities above — authored once as data, structurally
       similar to `ShopTemplate` but describing CHOICES rather than a
       fixed sell list. PROPOSED name `ProvisionerAssortmentPool`.
       CORRECTED (2026-07-13 pass): this pool's entries do NOT reduce
       to plain item ids — the approved pool itself contains the same
       Water-Bottle-vs-Potion-of-Healing distinction as Section 1a
       (both `minecraft:potion`, distinguished only by
       `DataComponents.POTION_CONTENTS`). Each pool entry is therefore
       authored as a full `ItemStack` via the SAME `ItemStack.CODEC`
       `ShopEntry` already uses (no new codec, no potion-specific
       field — simple entries like coal/bread just happen to have no
       extra components set, so they stay just as compact to author).
       Because of that, `ProvisionerAssortmentPool` needs the SAME
       `ServerLifecycleEvents.SERVER_STARTED` + `RegistryOps` loading
       pattern as `ShopRegistry` (and as `ItemValueRegistry`, Section
       1a) — NOT the simple reload-listener pattern this document
       originally (incorrectly) proposed. The earlier draft's claim
       that "plain item ids resolve fine under `JsonOps.INSTANCE`" is
       WRONG for this pool specifically and is retracted here.

    2. A per-entity PERSISTED runtime result of rolling against that
       pool exactly once — PROPOSED `MerchantStockEntry(ItemStack
       item, int stock)` list, persisted on the `ProvisionerNpcEntity`
       instance (Section 8), NOT stored back into `ShopTemplate`.
       Price is deliberately NOT frozen into this runtime record — it
       resolves LIVE against `ItemValueRegistry`/`ItemPricingService`
       (Section 1) at display time, so a future price modifier
       (Relationship, Persuasion, etc.) applies without needing to
       reroll or rewrite stock. Only WHICH items and HOW MANY are
       rolled once and frozen; PRICE is always live.

  `TradeSessionManager`/`TradingScreen` will need a future extension
  point to read from a Provisioner's per-entity `MerchantStockEntry`
  list instead of (or in addition to) a shared `ShopRegistry` template
  when the NPC in question is a `ProvisionerNpcEntity` — flagged as a
  real code change needed in Implementation Order (Section 11), not
  attempted in this documentation-only pass.

================================================================================
4. RARE SPECIAL STOCK
================================================================================
ADOPTED direction, PLAYTEST VALUE for the numbers.

  - Each Provisioner has a 12.5% chance to carry one normal vanilla
    drinkable Potion of Healing. Stock 1, price 80 Credits.
  - Generated once, persisted, same mechanism as Section 3's roll (not
    a separate system — one roll pass produces the whole assortment
    including this slot).
  - Provisioners do not normally buy potions.
  - The future Alchemist NPC will reliably sell Alchemy API potions
    (the existing `AlchemyPotionItem`/`PotionData` system per project
    memory `project_trading_system.md`'s "Alchemist candidate" note),
    ingredients, and related specialist products — this rare vanilla
    potion on the Provisioner is an incidental extra, not a preview of
    Alchemist stock.

================================================================================
5. PROVISIONER ACCEPTED GOODS
================================================================================
ADOPTED, kept deliberately separate from Section 1's value system, per
the explicit instruction that "a merchant accepting an item is
separate from the item having a value."

  Provisioners may buy common general goods: ordinary foods and
  ingredients; wood and planks; coal; string/fibres/hides and similar
  utility materials.

  Provisioners do NOT normally buy: tools, weapons, armor, potions,
  enchanted equipment, phones, quest items, artifacts, specialist
  machines.

--------------------------------------------------------------------------------
5a. Proposed shape
--------------------------------------------------------------------------------
  Matches (and formally adopts) the `accepts_tags` field ALREADY
  recovered/proposed in TOTALITY_ECONOMY_BANKING_TRADING.txt Section
  7c's shop-definition sketch, previously undecided/unimplemented —
  this document locks it in as a plain item-tag set:

    Set<TagKey<Item>> acceptedTags   -- e.g. #totality:provisioner_buys

  Checked independently of `ItemValueRegistry` at SELL time: an item
  must BOTH have a resolvable base value (Section 1) AND match an
  accepted tag for a given merchant to be sellable to it. Neither
  condition alone is sufficient. Per-merchant-type tag sets (Blacksmith
  accepts different tags than Provisioner) is the natural extension
  point once a second merchant archetype exists — not built here.

================================================================================
6. SELLABLE-STOCK LIQUIDITY CHECK
================================================================================
ADOPTED, PLAYTEST VALUE — arithmetic sanity check only, not a locked
formula.

  At the default 50% sell payout, excluding tools and the Healing
  Potion (which the Provisioner doesn't buy back anyway, Sections 3/4):

    Guaranteed subtotal: 84 Credits
    Four common entries: minimum 128 / average 160 / maximum 184
    Cooked-food slot: 54 Credits

    Total: minimum 266 / average 298 / maximum 322 Credits

  This is why 300 starting Credits is currently considered a suitable
  first-playtest value — a player selling back the entire non-tool,
  non-potion assortment in one sitting lands almost exactly at the
  starting pool, neither trivially draining it nor leaving it
  untouched. Reroll this table if Section 3's item list/prices change.

================================================================================
7. NPC/MERCHANT STATE SEPARATION
================================================================================
ADOPTED. Three distinct concepts must stay distinct:

  - NPC PERSONAL INVENTORY — whatever the entity is notionally
    "carrying" on its person. `TotalityNpcEntity` currently has no
    real inventory of its own (it's a `PathfinderMob`, no `Container`
    implementation) — this is presently a NOTIONAL/future concept for
    Provisioners, not something that exists in code yet.
  - MERCHANT SALE STOCK — Section 3's per-entity
    `MerchantStockEntry` list. This is business inventory, not
    personal property.
  - MERCHANT BUSINESS CREDITS — Section 2's `currentCredits`. The
    merchant's full business balance must NOT physically exist in
    their pocket (i.e. must NOT be represented as physical `CreditsItem`
    stacks the entity is "holding" — it's a plain persisted number,
    Section 2a).

  Future Pickpocket (not designed here) normally exposes PERSONAL
  inventory and any carried physical Credits, NOT the complete
  business balance — this document only reserves that distinction, it
  does not design Pickpocket. Stealing actual merchant stock (a future
  Pickpocket interaction) must remove it from the merchant's runtime
  stock list (Section 3a), not conjure a duplicate.

================================================================================
8. GENERIC PROVISIONER IDENTITY
================================================================================
ADOPTED, REWORDED to match what actually exists in code (Section 0).

  - The first Provisioner is a generic NPC archetype, not a unique
    named character — same distinction `TotalityNpcEntity.
    usesRandomIdentity()` already encodes (`true` by default, `false`
    for hand-crafted named characters).
  - It uses the EXISTING random gender + name system:
    `NpcGender`/`NpcNameRegistry` (`entity/npc/`). There is currently
    no separate "skin category" axis in code — do not design against
    one that doesn't exist; if broader appearance variation is wanted
    later, that is new scope on top of this document, not something
    it assumes.
  - Its generated identity (name/gender) AND its generated assortment
    (Section 3) AND its `currentCredits` (Section 2) must all persist
    on the same entity instance across relog/restart/reload — this is
    a superset of what `TotalityNpcEntity` already persists
    (`dialogueId`, `shopId`, `Gender`), extended with the new fields.
  - PROPOSED entity shape, following the `BankerNpcEntity` precedent
    (thin subclass, Section 0):

      public class ProvisionerNpcEntity extends TotalityNpcEntity {
          // new persisted fields: List<MerchantStockEntry> stock,
          // long currentCredits
          // roll-once-on-first-spawn logic (mirrors finalizeSpawn's
          // existing random-gender/name roll, extended to also roll
          // Section 3's assortment + Section 2's starting Credits
          // exactly once, guarded so a reload/respawn never rerolls
          // an already-generated instance)
      }

  - Stable identity will later support individual Relationship,
    Investment (Section 10), Contacts, personal inventory (Section 7),
    and Pickpocket state — none of that is designed here, just kept
    possible by giving the Provisioner a real, persistent per-instance
    identity now instead of a stateless/interchangeable one.

================================================================================
9. FIRST TRADING TUTORIAL QUEST
================================================================================
ADOPTED DIRECTION, mechanics TBD. Reconciles with, and partially
supersedes on NAMING, TOTALITY_ECONOMY_BANKING_TRADING.txt Section 9's
"First Sale" quest concept — same intent, this document's name takes
precedence per Section 0's precedence rule (recency).

  - Approaching a Provisioner for the first time starts a global,
    player-specific trading tutorial quest.
  - Any Provisioner may advance it — not tied to one specific NPC
    instance (contrast with Section 8's per-instance identity, which
    is about STOCK/CREDITS, not quest gating).
  - It should teach: Dialogue-gated trading (the ECON-13 Interact ->
    Dialogue -> Trade flow, already implemented and playtest-verified
    per TOTALITY_POST_AUDIT_DESIGN_DECISIONS.md Section 5), buying,
    selling, accepted categories (Section 5), the 50% resale value
    (Section 1), and limited merchant Credits (Section 2).
  - Exact trigger distance, text, reward, and stages remain TBD.
  - Do NOT implement this quest until a functional SELL exists
    (Section 1/5's central pricing + accepted-categories work) —
    teaching a mechanic that doesn't work yet is worse than not having
    the tutorial.

--------------------------------------------------------------------------------
9a. Reconciliation: how this would actually hook in
--------------------------------------------------------------------------------
  Follows the existing `QuestManager` hardcoded-hook pattern (Section
  0) used by `FIRST_SIGNAL`/`MOBILE_BANKING` — a new quest identifier
  plus a new static hook (candidate `onProvisionerApproached(player)`)
  called from wherever proximity is actually detected. Proximity-based
  triggering is NEW plumbing relative to the current quest system's
  existing triggers (which fire on discrete actions like equipping the
  phone, not continuous distance checks) — should be throttled (e.g.
  checked on a slow tick interval or only while a Provisioner is
  loaded/ticking near a player), not a naive per-tick distance scan
  across every player/NPC pair. Exact throttle mechanism is TBD,
  deferred to implementation time per Section 9's "not until SELL
  exists" gate anyway.

================================================================================
10. FUTURE INTEGRATIONS (recorded, not designed)
================================================================================
  - Persuasion masteries may raise `applicablePersuasionMasteryBonus`
    (Section 2b), and therefore a merchant's `effectiveStartingCredits`
    for a given player's trades — not `currentCredits` directly.
  - A Friend-tier Relationship may unlock an Investment dialogue
    option.
  - Investment may permanently increase an individual merchant's
    `permanentInvestmentBonus` (Section 2b), raising its
    `effectiveStartingCredits` baseline — NOT a direct, permanent floor
    on the live `currentCredits` balance (Section 2b corrects this
    wording; the two concepts are related but distinct).
  - Contacts may later display known merchants and relationship state.
  - Restocking, assortment rotation, Credit replenishment, buyback
    (already flagged TBD in TOTALITY_ECONOMY_BANKING_TRADING.txt
    Section 8), Relationship, Pickpocket (Section 7), and specialist
    merchants (Blacksmith, Alchemist) all remain future work, not
    scoped by this document.

================================================================================
11. IMPLEMENTATION ORDER
================================================================================
CORRECTED (2026-07-13 pass) to be consistent with
TOTALITY_POST_AUDIT_DESIGN_DECISIONS.md — the earlier draft's 8-step
order didn't match that document's Phase 3 listing (Economy Transaction
API before Item Value/Merchant Runtime). This is now the single
reconciled order for both documents (see also the clarifying note added
to that document's Section 9c):

  1. Component-aware `ItemValueRegistry`/value-rule system (Section
     1/1a) — central item-value registry, `ItemValueRule` with
     item-ID fallback AND component-aware matching. New package
     `api/economy/value/`.
  2. Context-aware `ItemPricingService` and server-authoritative quote
     representation (Section 1b/1e) — `PricingContext`/`PriceQuote`,
     `quoteRetail`/`quoteSell`.
  3. Minimal merchant transaction/runtime foundation required by SELL
     (Section 2/5): `baseStartingCredits`/`currentCredits`;
     `acceptedTags` or equivalent accepted-category rules; authoritative
     server-side validation; ATOMIC exchange of item and Credits (never
     "remove item, then attempt payment" or "pay player, then attempt
     item removal" — validate fully before any mutation, commit both
     sides together or neither). This is a MINIMAL, purpose-built
     contract for SELL specifically — it does NOT require the full
     future Economy Transaction API (ledger, refund history,
     idempotency, rollback — TOTALITY_POST_AUDIT_DESIGN_DECISIONS.md
     Section 9c) to be finished first; that broader API can still be
     built later without redoing this minimal contract, only extending
     it.
  4. Functional server-side SELL transaction — EXTENDS
     `TradeSessionManager` (new `handleSell` alongside existing
     `handleBuy`), `CreditPaymentHelper` (new merchant-pays-player
     path), built on steps 1-3.
  5. `TradingScreen` SELL UI and server-issued quote display — wires up
     the currently-inert SELL mode (`screen/shop/TradingScreen.java`)
     to step 4, following Section 1e's server-authoritative-quote rule.
  6. Persistent randomized Provisioner assortment (Section 3/3a) — new
     `ProvisionerAssortmentPool` (static data, component-aware per
     Section 3a's correction) + `MerchantStockEntry` (per-entity
     persisted runtime).
  7. Generic `ProvisionerNpcEntity`/profile (Section 8) and its
     persisted identity, stock, and Credits — EXTENDS
     `TotalityNpcEntity`, thin subclass per the `BankerNpcEntity`
     precedent, plus the roll-once-on-first-spawn logic tying steps
     3/6 together.
  8. First trading tutorial quest (Section 9) — new `QuestManager`
     hook + quest JSON, gated on step 5 being functional first.
  9. Later: restocking, Credit replenishment, buyback, investment,
     Relationship, Pickpocket, Contacts, and specialist merchants
     (Section 10) — not scheduled yet.

All prices, quantities, and probabilities in Sections 2-6 are PLAYTEST
VALUES, not permanent balance — expect them to move once real
playtesting happens against a working SELL implementation.

================================================================================
12. IMPLEMENTATION STATUS
================================================================================
Tracks ONLY what has actually been built against this document. Update
this section, not the numbered design sections above, as each
Implementation Order step lands.

--------------------------------------------------------------------------------
12a. Phase 1 — COMPLETE (2026-07-13): Section 11 steps 1-2
--------------------------------------------------------------------------------
  Built, compiled clean (`gradlew compileJava`), package
  `api/economy/value/`:

  - `ItemValueRule` (`ItemValueRule.java`) — `record(ItemStack
    referenceStack, long baseValue)`, reuses `ItemStack.CODEC` exactly
    as Section 1a specifies. A rule matches an item-ID-only fallback
    when its reference stack's `getComponentsPatch()` is empty;
    otherwise every declared component must equal the real stack's
    value for that component type (components the rule doesn't
    declare are never checked; stack count is never compared).
  - `ItemValueRuleConflicts` (package-private) — pure duplicate/
    ambiguity detection, isolated so it's directly exercisable without
    a full datapack load.
  - `ItemValueRegistry` — loads `data/totality/item_values/*.json` (one
    rule per file), using the SAME `ServerLifecycleEvents.
    SERVER_STARTED` + `RegistryOps` pattern as `ShopRegistry` (no live
    `/reload`, same known trade-off). Rejects negative `base_value`s;
    rejects duplicate/ambiguous rules for the same item at load time
    with a diagnostic log error naming both conflicting resource IDs
    (conflicting rules are excluded from the resolved registry, not
    crash-on-load). Zero is an ALLOWED base value — no sellability
    meaning is attached to it (Section 5 still owns "is this item
    accepted," untouched by this phase).
  - `PricingDirection` (`RETAIL`/`SELL`) — a minimal, deliberately NOT
    the broader `TransactionType` TOTALITY_ECONOMY_BANKING_TRADING.txt
    Section 6 proposes; align them later if that broader API is built.
  - `PricingContext`/`PriceQuote` — as Section 1b, with `player`/
    `merchantId` carried but unused this phase (future Relationship/
    reputation/Persuasion/specialization extend the context record
    without touching call sites), `authoredOverride` fully functional
    (bypasses `ItemValueRegistry` and becomes the quote's unit price
    directly).
  - `ItemPricingService.quoteRetail`/`quoteSell` — 100%/50% of
    resolved base value; checked `Math.multiplyExact` (throws
    `ArithmeticException` on overflow, never wraps); throws
    `IllegalArgumentException` for non-positive quantity or a
    direction/context mismatch. Rounding beyond exact integer division
    remains Section 1f's unresolved TBD — not decided by this
    implementation.
  - 20 `data/totality/item_values/*.json` files for every Section 4
    value, including the two component-aware `minecraft:potion` rules
    (Water Bottle, Potion of Healing) — no plain-`minecraft:potion`
    fallback rule was authored, and no splash/lingering potion values
    were added.
  - `ItemValueVerification` (package-private, dev-environment-gated
    self-test at `SERVER_STARTED`, since the project has no JUnit/test
    source set at all) — covers every case the phase required: Bread
    -> 12, Stone Axe -> 36, Water Bottle -> 8, Potion of Healing -> 80,
    each potion doesn't resolve as the other, a custom-named Healing
    Potion still resolves to 80, an unauthored potion variant resolves
    to nothing, quantity overflow throws, invalid quantity throws, and
    direct duplicate/genuine-ambiguity/mutually-exclusive-not-ambiguous
    cases are all detected correctly.

  NOT implemented (unchanged from design, explicitly out of scope for
  Phase 1): SELL transactions, merchant Credits
  (`baseStartingCredits`/`currentCredits`), `acceptedTags`,
  `ProvisionerNpcEntity`, randomized Provisioner assortment,
  `TradingScreen` SELL UI, the tutorial quest, restocking, and buyback.
  `ShopEntry.price`'s override semantics (Section 1c) are NOT yet
  wired to `PricingContext.authoredOverride` — the field exists and
  works, but nothing calls it with a real `ShopEntry` value yet.

  KNOWN PRE-EXISTING ISSUE, unrelated to this phase: `gradlew
  runServer` (dedicated server) currently fails during mod init —
  `EnergyItems`/`ModItems` load a client-only `Screen` class in a path
  that also runs on the dedicated server, which crashes before
  `ItemValueRegistry` even registers. This predates this phase (neither
  file has been touched) and was not fixed here — full runtime
  self-test output requires launching via `gradlew runClient`
  (integrated server) instead.

  RUNTIME-VERIFIED (2026-07-13, via `gradlew runClient`, integrated
  server, world startup log): 20 item value rules loaded across 19
  item IDs; all 11 self-test checks above PASSED — Bread/Stone Axe/
  Water Bottle/Healing Potion all resolved correctly, Water and Healing
  did not cross-match, a custom-named Healing Potion still matched,
  Night Vision had no value, quantity overflow and invalid quantities
  were rejected, and the pairwise duplicate/ambiguity helper checks
  passed.

--------------------------------------------------------------------------------
12b. Phase 1 hardening pass — COMPLETE (2026-07-13)
--------------------------------------------------------------------------------
  Corrected a real bug found by re-review, and hardened validation
  without touching the matcher itself (`getComponentsPatch()`-based
  matching is unchanged and stays runtime-verified correct):

  - FIXED: `ItemValueRegistry.validateAndGroup`'s pairwise conflict
    scan used to SKIP a pair once either side was already marked
    rejected (`if (rejected.contains(idA) || rejected.contains(idB))
    continue;`). This under-rejected a genuine three-or-more-way
    conflict — e.g. three identical duplicate rules A/B/C: comparing
    (A,B) rejected both, then (A,C) and (B,C) were skipped entirely,
    so C was never actually checked against anything and could survive
    by accident. The skip is removed — every pair in an item's group is
    now evaluated unconditionally, so the result no longer depends on
    comparison order. `validateAndGroup` and the new
    `pickMostSpecificMatch` (extracted from `resolveBaseValue`, same
    behavior) are now package-private `static` methods, directly
    testable against a hand-built map/list without a datapack load.
  - HARDENED: `PricingContext` now validates in its canonical
    constructor — `player`, `merchantId`, `direction`, and
    `authoredOverride` must all be non-null (`Optional` fields use
    `Optional.empty()`, never a null reference), and a present
    `authoredOverride` must not be negative. Zero remains a legal
    override. Invalid state is now impossible to construct, not just
    unlikely.
  - `ItemValueVerification` updated to match: constructs a real
    `TotalityFakePlayer` (via `server.overworld()`) instead of passing
    `null` as the player, since `player` is no longer nullable. Six new
    registry-level checks exercise `validateAndGroup` directly on
    isolated, hand-built maps (never touching the real loaded data):
    three identical component-aware rules all rejected; three
    identical plain fallbacks all rejected; one valid rule survives
    untouched alongside three mutually-duplicate conflicting rules for
    the same item; a lower- and a compatible higher-specificity rule
    both load, and the higher-specificity one wins when a stack
    matches both; two equal-specificity mutually exclusive rules
    (Water vs. Healing) both load; two equal-specificity overlapping
    rules that could both match one stack are both rejected. Two new
    checks cover `PricingContext`'s override validation: a negative
    override throws at construction; a zero override produces a valid
    zero-price quote and a positive override becomes the exact unit
    price (with the total still computed via `Math.multiplyExact`).
    Total self-test check count: 11 (original) + 6 (registry-level) +
    2 (override validation) = 19.
  - Registry load-reporting log message corrected to distinguish
    parsed/accepted/rejected counts instead of implying every parsed
    definition is active: `"Parsed {N} item value rules: {accepted}
    accepted, {rejected} rejected, across {M} items"` (previously
    worded as if `loaded.size()` were already the accepted count).
  - Design text (Section 1a) corrected: the canonical rule is that
    ONLY equally-specific rules can conflict with each other — two
    rules of DIFFERENT specificity are never in conflict and both load
    unconditionally, with the more specific one winning at match time.
    The earlier wording's resolveBaseValue pseudocode imprecisely
    implied any two component-aware rules capable of matching the same
    stack were an authoring error; that was wrong once different-
    specificity coexistence was required, and is corrected in place.
  - Section 1f (rounding) reinforced: the current `baseValue / 2` SELL
    calculation is explicitly documented as a placeholder correct only
    because all current data is even, not a chosen rounding policy —
    odd-value rounding, modifier-rounding composition, and minimum
    positive payout all remain open and must be settled before
    functional SELL or an odd base value ships.

  `gradlew compileJava`: SUCCESSFUL. `gradlew runClient` launched
  clean to the main menu with no startup errors (proving the hardening
  changes introduced no client-side regression).

  RUNTIME-VERIFIED (2026-07-13, via `gradlew runClient`, integrated
  server, world startup log, confirmed twice on separate loads): 20
  item value rules parsed, 20 accepted, 0 rejected, across 19 items;
  all 19 self-test checks passed, including all 6 new registry-level
  conflict cases and both new override-validation cases; no unexpected
  `ERROR` lines (only the intentional synthetic ones from the
  registry-validation self-tests, each immediately followed by its
  expected PASS).

  Still NOT implemented (unchanged): SELL transactions, merchant
  Credits, `acceptedTags`, `ProvisionerNpcEntity`, randomized stock,
  `MerchantStockEntry`, `TradingScreen` SELL UI, buyback, restocking,
  tutorial quest, Relationship/reputation/Persuasion/investment
  modifiers, the broader Economy Transaction API. The dedicated-server
  `EnergyItems`/`Screen` issue remains unfixed and out of scope.

--------------------------------------------------------------------------------
12c. Phase 2 — Minimal merchant runtime and SELL foundation (2026-07-13)
--------------------------------------------------------------------------------
  Implements Section 11 steps 3-4 (a minimal merchant transaction
  contract and a functional server-side SELL), plus the BUY-side half
  of step 3 (merchant Credits increase on BUY). Steps 5 (TradingScreen
  SELL UI), 6 (randomized assortment), 7 (`ProvisionerNpcEntity`), and
  8 (tutorial quest) remain untouched, per explicit scope.

  MERCHANT RUNTIME (Section 2, new `api/shop/` classes):
  - `MerchantRuntime` — interface: `merchantId()`, `currentCredits()`,
    `setCurrentCredits(long)` (throws on negative — a merchant balance
    can never go negative by construction, not by clamping), and
    `acceptedTags()` with a default `accepts(ItemStack)` that checks
    membership across all accepted tags (an EMPTY tag set correctly
    rejects everything — no implicit "accepts anything" fallback).
  - `InMemoryMerchantRuntime` — the PLACEHOLDER implementation Section
    2a/11 anticipated: non-persistent, resets on server restart,
    explicitly documented as something `ProvisionerNpcEntity` replaces
    later without changing any code written against the
    `MerchantRuntime` interface.
  - `MerchantRuntimeRegistry` — lazily creates one
    `InMemoryMerchantRuntime` per `shopId` (the only merchant identity
    that exists before per-entity Provisioners), seeded with Section
    2's `baseStartingCredits = 300` PLAYTEST VALUE and the single
    current Provisioner accepted-tag policy (every merchant currently
    uses the same policy, since only one merchant archetype exists).

  ACCEPTED GOODS (Section 5): `ModTags.PROVISIONER_BUYS`
    (`#totality:provisioner_buys`), backed by a real new tag data file
    `data/totality/tags/item/provisioner_buys.json` populated with
    real vanilla items only: bread, apple, carrot, cooked beef, cooked
    porkchop, oak planks, coal, string, leather. `carrot` is
    deliberately included with NO `item_values` rule authored, to
    give the self-test a genuine "accepted but unvalued" case. Tools,
    weapons, armor, potions, and anything ore/ingot-shaped are
    deliberately absent, per Section 5's exclusion list. Sellability
    requires BOTH a resolvable base value (Section 1, unchanged from
    Phase 1) AND this tag — checked independently, exactly as
    Section 5a specifies.

  SERVER-ISSUED SELL STATE (Section G): new `MerchantSellQuoteView`
    record — `accepted`, `hasValue`, `unitPayout`,
    `maxQuantityByStack`, `maxQuantityByMerchant`,
    `effectiveMaxQuantity`, `requestedQuantity`, `totalPayout`,
    `rejectionReason`. Its static `compute(...)` is the SAME pure
    logic used by both `TradeSessionManager.handleSell`'s validation
    and the self-test — one implementation, not two. No new
    client-facing networking carries this yet (Part G explicitly
    allows deferring the full SELL UI).

    `Context/Audit/Image References/trade_screen.png` (initially
    mis-searched under a typo'd filename, located after Stefan
    corrected it) was reviewed after this section was first written.
    It confirms the shape chosen here without requiring any changes:
    it shows Merchant Credits displayed alongside the player's own
    Credits (confirming `ShowShopStatePayload` will need an additive
    `merchantCredits` field later — trivially available already via
    `MerchantRuntime.currentCredits()`), a bottom "YOUR INVENTORY" row
    the player clicks to SELL (confirming `SellItemPayload`'s choice
    to identify the sold stack by inventory `slotIndex` rather than by
    item identity), a BUY/SELL/BUYBACK three-tab layout (confirming
    BUYBACK is real future scope, not invented), and per-item Stock
    counts (the future `ProvisionerAssortmentPool`/`MerchantStockEntry`
    work, cleanly separable from `MerchantRuntime`). The detail panel's
    Price Each / Stock / Quantity / Total Cost fields map directly onto
    `MerchantSellQuoteView`'s `unitPayout`/`effectiveMaxQuantity`/
    `totalPayout`. Nothing built this phase needed to change as a
    result of reviewing it.

  SELL TRANSACTION (Section D, `TradeSessionManager.handleSell`,
    new): validates, in order — active session; positive quantity;
    valid slot; non-empty real stack at that slot; stack holds enough;
    then delegates accepted/valued/quotable/affordable-by-merchant
    checks to `MerchantSellQuoteView.compute` (steps 7-11 collapse
    into one reused check); finally confirms the player can safely
    receive the payout (`CreditPaymentHelper.canReceive`). Every check
    happens before any mutation. Commit is three operations already
    proven safe by validation — remove the exact quantity, pay the
    player the exact payout, decrement the merchant's Credits by the
    exact payout — so no rollback machinery was needed (nothing in the
    commit step can fail once validation has passed). New C2S
    `SellItemPayload(slotIndex, quantity)` / `SellItemHandler`, mirrors
    `BuyItemPayload`/`BuyItemHandler` exactly.

  MERCHANT-TO-PLAYER PAYMENT (Section E, `CreditPaymentHelper`, new
    `receive`/`canReceive`): credits the player's Wallet directly —
    the SAME established mechanism `BankTellerHandler.deposit` already
    uses to give a player Credits it didn't take from elsewhere in the
    same operation (distinct from `pay`, which SPENDS existing player
    funds). Rejects negative amounts, treats zero as a trivial no-op,
    and checks for overflow before mutating rather than relying on
    `WalletComponent.modify`'s own clamp.

  BUY INTEGRATION (Section F, `TradeSessionManager.handleBuy`,
    modified): computes the merchant's prospective new balance via
    `Math.addExact` and rejects (before charging the player) if it
    would overflow. Merchant Credits are only actually incremented
    after the player has been successfully charged — a failed BUY
    changes neither the player's funds nor the merchant's Credits.

  ROUNDING (Section H, `ItemPricingService`, modified): the Phase 1
    accidental-behavior placeholder is replaced with the explicit
    Phase 2 CANONICAL INTERIM rule —
    `baseValue == 0 ? 0 : Math.max(1L, baseValue / 2L)` — floor half,
    but never below 1 Credit for a positive base value. Exposed as
    public `ItemPricingService.sellUnitPayout(long)` so the rule can
    be verified directly against values no real item currently has
    (5, 1). Still explicitly INTERIM — modifier-composition and
    per-unit-vs-transaction-total rounding remain open per Section 1f.

  VERIFICATION LOGGING CLEANUP (Part A, new
    `api/core/util/VerificationReporter`): shared PASS/FAIL/summary
    helper now used by both `ItemValueVerification` and the new
    `MerchantSellVerification`. Concise by default — one summary line
    per suite; `-Dtotality.verboseVerification=true` also prints every
    individual PASS; failures always print individually either way.
    `ItemValueRegistry`'s conflict validation was split into a PURE
    `validate(...)` (returns a structured `ValidationResult`, logs
    nothing) and the production `load()` path that turns
    `ValidationResult.conflicts()` into real `ERROR` log lines — the
    registry self-tests now call `validate(...)` directly, so
    synthetic `totality:selftest/...` conflicts no longer produce any
    log output at all (previously they produced real-looking `ERROR`
    lines with an explanatory disclaimer). Real datapack conflicts
    still log as `ERROR` exactly as before — confirmed by the real
    `test_trader`/`item_values` data still loading and logging
    normally.

  NEW SELF-TEST SUITE (Part I, `MerchantSellVerification`, 22
    checks): checks 1-13 exercise `MerchantSellQuoteView`/
    `ItemPricingService` directly against isolated
    `InMemoryMerchantRuntime` fixtures (accepted+valued sellable;
    valued-but-unaccepted rejected; accepted-but-unvalued rejected;
    tool and potion rejected by policy; base value 12 -> payout 6;
    odd value 5 -> floored payout 2; value 1 -> minimum payout 1;
    value 0 -> payout 0; quantity multiplication; quantity overflow;
    exact-Credits and insufficient-Credits merchant affordability).
    Checks 14-22 drive the REAL `TradeSessionManager` session/commit
    path against the existing `totality:test_trader` shop and a
    `TotalityFakePlayer` (successful SELL removes the exact quantity,
    pays the exact amount, and decreases merchant Credits by the exact
    amount; a failed SELL changes nothing at all; successful/failed
    BUY correctly does/doesn't change merchant Credits; invalid
    session/slot/quantity/empty-stack SELL attempts are all safely
    rejected; selling part of a stack leaves the correct remainder;
    an item with an irrelevant extra component still resolves its
    correct base value). Every check is wrapped so an unexpected
    exception becomes a reported FAILURE rather than aborting the rest
    of the suite.

  `gradlew compileJava`: SUCCESSFUL on first attempt.

  RUNTIME-VERIFIED (2026-07-13, via `gradlew runClient`, integrated
  server, world startup log): `Parsed 20 item value rules: 20
  accepted, 0 rejected, across 19 items`; `[ItemValueVerification] All
  19 self-test checks passed.`; `[MerchantSellVerification] All 22
  self-test checks passed.` — 41 checks total, zero failures. Zero
  unexpected `ERROR` lines (confirming the logging-cleanup fix:
  synthetic conflict data no longer logs at all) and zero `PASS` lines
  printed by default (confirming concise-mode works as designed) — the
  only other log lines were expected `WARN`s from
  `MerchantSellVerification`'s own intentional-rejection checks
  (invalid session/slot/quantity/empty-stack), which are genuine
  `TradeSessionManager` rejection messages, not verification noise.
  `-Dtotality.verboseVerification=true` was not independently
  re-confirmed by Claude Code this pass (the concise-mode result above
  already demonstrates the default path correctly); flip it on to see
  every individual PASS line if wanted.

  NOT implemented, unchanged from scope: `ProvisionerNpcEntity`,
  persistent per-entity merchant NBT, randomized assortment,
  `ProvisionerAssortmentPool`, `MerchantStockEntry`, stock
  depletion/restocking, Credit replenishment, buyback, the full
  `TradingScreen` SELL visual redesign, the tutorial quest,
  Relationship/reputation/Persuasion/investment modifiers,
  Pickpocket, Contacts, Blacksmith/Alchemist NPCs, the broader Economy
  Transaction API, ledger history, refunds, an idempotency framework,
  and the unrelated dedicated-server `Screen`-classloading bug.

12d. Phase 2 hardening pass (2026-07-14)
--------------------------------------------------------------------------------
  A focused hardening pass over 12c's Phase 2 work, driven by a review-
  bundle audit. Preserves every check that already passed; does not
  touch Phase 3 scope (`ProvisionerNpcEntity`, randomized stock,
  TradingScreen SELL redesign — still explicitly deferred).

  1. BUY OVERFLOW / NEGATIVE-PRICE / NEGATIVE-PAYMENT DEFENSES
     `TradeSessionManager.handleBuy` now computes `price * quantity`
     via `Math.multiplyExact` (was raw `*`, which could silently wrap
     negative, e.g. `Long.MAX_VALUE * 100`) and rejects an entry with
     `price() < 0` before any payment attempt. `CreditPaymentHelper`
     had two real bugs fixed: `canAfford(player, negative)` and
     `canAffordPhysical(player, negative)` both previously returned
     `true` for a negative amount (the negative collapsed to 0 via
     `Math.max(0, ...)` in `canAfford`, and `physicalCredits(player) >=
     negativeAmount` is trivially true in `canAffordPhysical`) — both
     now explicitly reject `amount < 0` up front, which transitively
     fixes `pay`/`payPhysical` since both delegate to the afford check
     first. `receive`/`canReceive` already rejected negative amounts
     correctly and were left alone. `physicalCredits(player)` now sums
     with saturating (not wrapping) addition, so multiple large
     `totality:credits` stacks can never flip the total negative.
     `ItemPricingService.sellUnitPayout(long)` now throws
     `IllegalArgumentException` on a negative input instead of
     silently returning a positive minimum payout of 1; `quote(...)`
     guards its one call site so a negative authored base value
     degrades to "no resolvable value" rather than propagating the
     exception into a live transaction. `ShopRegistry.load` now drops
     (logs `ERROR`, does not load) any catalog entry with a negative
     authored price as a datapack authoring error — defense-in-depth
     alongside, not instead of, `handleBuy`'s own transaction-time
     rejection.

  2. VERIFICATION ISOLATION FROM PRODUCTION MERCHANT STATE
     `MerchantSellVerification` previously called
     `MerchantRuntimeRegistry.getOrCreate(TEST_TRADER_SHOP_ID)` and
     mutated the SAME runtime real gameplay would use, and the final
     shared-runtime check left `totality:test_trader` at 282 Credits
     instead of the intended 300 — a real test-pollution bug.
     `TradeSessionManager` gained package-private
     `startTradeForVerification(player, shopId, ShopTemplate,
     MerchantRuntime[, npc])` entry points that accept an explicitly
     supplied `ShopTemplate` and `MerchantRuntime` instead of resolving
     them from `ShopRegistry`/`MerchantRuntimeRegistry` — the public
     `startTrade` is unchanged and still resolves production state
     normally. Every session-based self-test now builds its own
     isolated `ShopTemplate` fixture (a self-authored "Verification
     Shop", not the real `totality:test_trader` JSON) and a fresh
     `InMemoryMerchantRuntime` per check, so no check can create or
     mutate `MerchantRuntimeRegistry`'s real per-server map at all — a
     stronger isolation than save/restore. A new `runSessionCheck`
     helper wraps every session-based check's session start/action/
     assert in `try {...} finally { TradeSessionManager.endTrade(...);
     <slot cleared> }`, so a check that throws unexpectedly can never
     leave a dangling session or leftover inventory state behind for
     the next one. A new check (`checkVerificationNeverTouchesProduc
     tionRuntime`, run last) asserts `MerchantRuntimeRegistry.peek(
     server, TEST_TRADER_SHOP_ID).isEmpty()` — a non-creating registry
     lookup added specifically to prove this — and that no session
     remains dangling for the fake player.

  3. MERCHANT-RUNTIME / TRADE-SESSION LOGICAL-SERVER LIFECYCLE
     `MerchantRuntimeRegistry`'s single process-global `Map<Identifier,
     InMemoryMerchantRuntime>` is now `Map<MinecraftServer,
     Map<Identifier, InMemoryMerchantRuntime>>`, with a new
     `MerchantRuntimeRegistry.register()` hooking
     `ServerLifecycleEvents.SERVER_STOPPED` to drop the entire
     per-server entry — a client that closes one integrated world and
     opens another in the same JVM can no longer see merchant Credits
     left over from the previous world. `MerchantRuntimeRegistry.
     getOrCreate`/`peek` both now take an explicit `MinecraftServer`;
     `TradeSessionManager.startTrade` supplies it via
     `player.level().getServer()` (the existing codebase convention,
     see `RestSessionManager`/`BlessSpell` for precedent). A new
     `TradeSessionManager.register()` hooks the same `SERVER_STOPPED`
     event to clear `SESSIONS` outright (no client connection remains
     by then to notify, unlike the per-player `DISCONNECT` cleanup
     already in `PlayerConnectionEvents`, which was already correct
     and untouched). A new pure lifecycle check
     (`checkServerStoppedClearsMerchantRuntimeToBaseline`) exercises
     `getOrCreate` -> mutate -> `clearForServer` -> `getOrCreate` again
     against a dedicated probe shop id and asserts the second call
     returns the 300-Credit baseline, without needing to actually stop
     and restart a real server mid-test.

  4. ENTITY-BACKED TRADE SESSION REVALIDATION
     `ActiveTrade` now stores the NPC's `UUID` and dimension
     (`ResourceKey<Level>`) alongside its numeric entity id, and
     exposes `isEntityBacked()` (`npcEntityId != -1`) so a
     deliberately non-entity-backed session (verification, a future
     remote shop) is never confused with a missing/removed NPC on an
     otherwise entity-backed one. A new private
     `TradeSessionManager.revalidateNpc` runs at the top of both
     `handleBuy` and `handleSell`, before any other check: for an
     entity-backed session it re-resolves the entity by id in its
     recorded dimension and requires ALL of — non-null, `isAlive()`,
     `!isRemoved()`, `getUUID().equals(recordedUuid)` (not just a
     reused numeric id), `player.level() == npc.level()`, distance
     within `TotalityNpcEntity.INTERACTION_RANGE_SQR` (a new public
     constant — the number itself is unchanged, 8 blocks/64.0 squared,
     extracted from `customServerAiStep`'s existing per-tick safety-net
     check so there is exactly one interaction-distance rule, not two
     that could drift apart), and — for a `TotalityNpcEntity`
     specifically — a new `isInteractionLockOwnedBy(player)` confirming
     the lock hasn't been superseded. On failure, `revalidateNpc` calls
     `endTrade` itself (releasing the lock, notifying the client) and
     the caller performs no economic mutation. `startTrade`/`beginSes
     sion` now also releases a REPLACED session's previous NPC lock
     before installing the new one (previously only `endTrade` did
     this, so opening a second trade without closing the first left
     the original NPC frozen). `releaseTradePartner` was fixed to
     resolve the NPC via the trade's recorded dimension rather than
     `player.level()` — previously, if the player had already changed
     dimension, the old NPC's lock could never be found and released.
     Two new checks exercise this against a real spawned
     `TotalityNpcEntity` (`server.overworld().addFreshEntity(...)`):
     discarding the NPC mid-session (which independently also proves
     `TotalityNpcEntity.remove()`'s own proactive session-end still
     works) and moving the NPC out of range WITHOUT a server tick
     running, so only `revalidateNpc` itself (not the entity's own
     per-tick safety net) can catch it — both assert the session ends
     and no mutation occurs. A wrong-dimension case was not added
     separately ("where practical") since it exercises the exact same
     `player.level() == npc.level()` branch as the distance check, and
     the dev harness has no second populated level readily available
     to move a fake player into.

  5. STRUCTURED TRANSACTION RESULTS, NO REJECTION-WARNING SPAM
     `TradeSessionManager.handleBuy`/`handleSell` no longer return
     `void` or call `LOGGER.warn`/`LOGGER.error` for any validation
     rejection — they return new `BuyResult`/`SellResult` records
     (`success`, a `Reason` enum, and payout/quantity detail) that the
     caller inspects instead. Ordinary gameplay rejections (item not
     accepted, merchant can't afford it, empty/stale slot, player
     can't afford a BUY, a session that raced closed, an NPC that
     wandered out of range) produce no log output anywhere, by design
     — they are normal outcomes a future SELL/BUY UI will display, not
     warnings. `BuyItemHandler`/`SellItemHandler` (the actual
     production network path) now log a `WARN` ONLY for reason values
     that indicate a packet the real UI could never send on its own —
     `INVALID_INDEX`/`OVERFLOW` for BUY, `INVALID_SLOT`/
     `INVALID_QUANTITY` for SELL. `MerchantSellVerification` asserts
     directly against the returned `Reason` values (e.g.
     `SellResult.Reason.NOT_SELLABLE`, `BuyResult.Reason.CANNOT_AFFORD`)
     instead of relying on log output at all.

  6. SMALL DEFENSIVE CLEANUP
     `InMemoryMerchantRuntime`'s constructor now rejects a null
     `merchantId` or `acceptedTags`, and stores `Set.copyOf(
     acceptedTags)` so a caller's original mutable `Set` reference can
     never change a merchant's accepted-goods policy after
     construction. `ItemPricingService.sellUnitPayout` — see Part 1
     above. This document's own Part I count in 12c ("checks 14-22")
     is corrected by this section: see the new count below.

  7. VERIFICATION SUITE — 31 checks (was 22)
     Checks 1-14 are pure `MerchantSellQuoteView`/`ItemPricingService`
     checks (13 unchanged from 12c, plus 1 new: negative base value
     rejected by `sellUnitPayout`). Checks 15-23 are the original 9
     real-session checks, refactored onto isolated fixtures per Part 2
     above but otherwise unchanged in intent. Checks 24-27 are new
     hardening checks for Part 1 (negative `pay`/`payPhysical`
     rejected without mutation; BUY multiplication overflow rejected
     without mutation; a negative authored shop price cannot complete
     a BUY). Check 28 is Part 3's lifecycle check. Checks 29-30 are
     Part 4's entity-backed revalidation checks. Check 31 (Part 2) runs
     last and asserts production merchant-runtime isolation.

  `gradlew compileJava`: SUCCESSFUL.

  RUNTIME-VERIFIED (2026-07-14, `gradlew runClient`, two consecutive
  logical-server starts in the same client process — "Testing World"
  loaded, fully quit ("Stopping server", all three dimensions saved),
  then reloaded): BOTH starts logged identically —
  `Parsed 20 item value rules: 20 accepted, 0 rejected, across 19
  items`; `[ItemValueVerification] All 19 self-test checks passed.`;
  `[MerchantSellVerification] All 31 self-test checks passed.` — 50
  checks total, zero failures, on EACH start. Zero unexpected `WARN`
  or `ERROR` lines from the `totality` namespace on either start
  (confirmed by grep across the full session log) — this is the
  concrete proof of Part 5's fix: the previous pass's expected
  intentional-rejection `WARN`s are gone entirely, not just
  suppressed by log level. Zero `PASS` lines printed by default
  (concise-mode still correct). The identical result on the second
  start — reached only after a real `MinecraftServer` instance fully
  stopped and a new one started — is the practical confirmation of
  Part 3's server-scoping fix: nothing carried over/leaked from the
  first logical server into the second (check 31 additionally proves
  no production `totality:test_trader` runtime entry was ever created
  by verification on either start).

  NOT implemented, unchanged from scope (Phase 3 and later, still
  explicitly deferred): `ProvisionerNpcEntity`, persistent per-entity
  merchant NBT, randomized assortment, `ProvisionerAssortmentPool`,
  `MerchantStockEntry`, stock depletion/restocking, Credit
  replenishment, buyback, the full `TradingScreen` SELL visual
  redesign, the tutorial quest, Relationship/reputation/Persuasion/
  investment modifiers, Pickpocket, Contacts, Blacksmith/Alchemist
  NPCs, the broader Economy Transaction API, ledger history, refunds,
  an idempotency framework, and the unrelated dedicated-server
  client-classloading fix.

12e. Phase 2 correction pass (2026-07-14, later same day)
--------------------------------------------------------------------------------
  A narrowly-scoped follow-up to 12d, fixing four issues found by a
  second review pass over the hardening pass itself. Preserves every
  check that already passed; still does not begin Phase 3.

  1. UUID-SAFE LOCK RELEASE. `revalidateNpc` already compared the
     resolved entity's UUID against `ActiveTrade.npcUuid()`, but
     `releaseTradePartner` resolved the recorded NPC by dimension +
     numeric entity id ALONE (a private `resolveNpc` helper, no UUID
     check) before calling `releaseInteractionLock()` — so if that
     numeric id ever resolved to a DIFFERENT entity than the one the
     session actually started with, ending the session could release
     the WRONG entity's lock. Fixed by centralizing UUID-safe
     resolution into one helper, `resolveRecordedNpc(player, trade)`,
     used by BOTH `revalidateNpc` and `releaseTradePartner` — it
     returns an entity only when the recorded dimension exists, the
     numeric id resolves, `npcUuid` is non-null, AND the resolved
     entity's UUID matches the recorded one (via a new extracted
     package-visible predicate, `matchesUuid(candidate, expectedUuid)`
     — see below for why it is a separate function). `revalidateNpc`'s
     own redundant UUID check was removed since the helper now
     guarantees it; every other check it performed (liveness,
     dimension, range, lock ownership) is unchanged.

     A new verification check (`checkReusedEntityIdWithWrongUuidLock
     NotReleased`) proves the guarantee, but NOT by forcing a live
     numeric-id collision through `Level#getEntity(int)` — two earlier
     attempts at exactly that both failed for reasons specific to this
     self-test harness, not to the fix: first via `Entity.setId` called
     before a second `addFreshEntity`, which was empirically observed
     to have no effect (the id the level actually indexes did not
     change); then via forcing the target chunk to load synchronously
     first, which still left `getEntity` returning null. The root cause
     confirmed by that second attempt's diagnostic: this suite runs at
     `SERVER_STARTED`, before the server has processed a single tick —
     and `Level#getEntity(int)`'s lookup is populated by tick-driven
     entity-section processing, so a freshly spawned entity is never
     visible to it yet, regardless of chunk-load state. (This is a
     characteristic of testing at `SERVER_STARTED` specifically, not a
     bug — a real Provisioner in actual gameplay is always resolvable
     by the time a player can interact with it, many ticks after
     spawn.) Given a live end-to-end resolution genuinely cannot be
     exercised deterministically in this harness, `matchesUuid` was
     extracted as its own package-visible predicate — the ONLY part of
     `resolveRecordedNpc` that depends on comparing two UUIDs, with the
     null/level-lookup guards around it being simple, low-risk
     delegation to well-established APIs that do not need the same
     scrutiny. The check drives `matchesUuid` directly against two
     real, distinct, never-added-to-the-level `TotalityNpcEntity`
     objects (a positive control that a real UUID matches itself, and
     an "impostor" that must not match) and confirms the impostor's own
     unrelated interaction lock is never touched by the mismatched call.

  2. LIFECYCLE VERIFICATION NO LONGER TOUCHES THE PRODUCTION REGISTRY.
     `checkServerStoppedClearsMerchantRuntimeToBaseline` called
     `MerchantRuntimeRegistry.getOrCreate`/`clearForServer` directly
     against the REAL development `MinecraftServer` — exactly the
     production-state mutation this suite's own Part 2 isolation work
     otherwise goes out of its way to avoid. Removed outright rather
     than refactored into an isolated instance: the two-consecutive-
     logical-server runtime test already documented in 12d (load,
     fully quit, reload; both starts identical) is real, end-to-end
     proof of the exact same `SERVER_STOPPED` behavior, achieved
     without mutating anything live. Verification check count is 1
     lower from this removal alone; see item 7 below for the net
     total after this pass's additions.

  3. VERIFICATION CLEANUP NOW MATCHES ITS OWN DOCUMENTATION.
     `runSessionCheck` previously restored the session and the test
     inventory slot in `finally`, but wallet restoration was left to
     each individual check body — a body that threw before reaching
     its own `setWallet(player, 0)` line would leave the fake player's
     wallet mutated for whatever check ran next. `runSessionCheck` now
     captures the player's wallet value AND the original stack in the
     test slot BEFORE the check body runs, and restores both in
     `finally` unconditionally — the four check bodies that previously
     reset the wallet manually at their own end
     (`checkSuccessfulBuyIncreasesMerchantCredits`,
     `checkBuyOverflowRejectedWithoutMutation`,
     `checkNegativeShopPriceCannotCompleteBuy`, plus
     `checkFailedBuyDoesNotChangeMerchantCredits`'s setup-only
     `setWallet(player, 0)`, which was already setup rather than
     cleanup and is unchanged) had their now-redundant manual resets
     removed. The two standalone checks that mutate the fake player
     outside `runSessionCheck`
     (`checkNegativePaymentRejectedWithoutMutation`,
     `checkNegativePhysicalPaymentRejectedWithoutMutation`) gained
     their own `try/finally` for the same reason. The fake player
     finishes the suite with no active trade session, its original
     wallet value, no leftover test inventory, and no production
     merchant-runtime entries created by verification — the last of
     these already had its own dedicated check
     (`checkVerificationNeverTouchesProductionRuntime`, unchanged,
     still runs last).

  4. MALFORMED PHYSICAL CREDITS HARDENED. `CreditPaymentHelper.
     physicalCredits` already saturated instead of overflow-wrapping
     for a large POSITIVE stored amount (12d), but its guard
     (`amount > 0 && total > Long.MAX_VALUE - amount`) only gated the
     saturation branch, not the addition itself — a zero-or-negative
     stored amount (safely constructible via `CreditsItem.setAmount`,
     which performs no validation of its own) fell through to
     `total + amount`, actually SUBTRACTING from the running total.
     Fixed by skipping any stack with a non-positive stored amount
     entirely (`if (amount <= 0) continue;`) before the saturating-add
     branch runs at all — a malformed Credits item can now only ever
     be worth nothing, never a negative contribution. A new check
     (`checkMalformedNegativePhysicalCreditsStackIgnoredNotSubtracted`)
     constructs exactly this malformed stack alongside a legitimate
     one and proves the computed total is unaffected either way.

  5. `gradlew compileJava`: SUCCESSFUL.

  6. RUNTIME-VERIFIED (2026-07-14, `gradlew runClient`, "Testing
     World" reloaded): `Parsed 20 item value rules: 20 accepted, 0
     rejected, across 19 items`; `[ItemValueVerification] All 19
     self-test checks passed.`; `[MerchantSellVerification] All 32
     self-test checks passed.` — 51 checks total, zero failures. Zero
     unexpected `WARN`/`ERROR` lines from the `totality` namespace
     (confirmed by grep across the full session log) and zero `PASS`
     lines printed by default — concise logging remains intact. This
     confirmation took several attempts on the entity-backed UUID
     check specifically (see item 1's design note above) before
     landing on the pure-predicate approach that finally passed
     cleanly on the first try once implemented; every other check
     (including the 3 carried over unchanged from 12d's entity-backed
     work) passed on every attempt.

  7. VERIFICATION SUITE — 32 checks (was 31): net +1 from 12d (-1 for
     removing the lifecycle check per item 2 above, +2 for the new
     UUID-collision check per item 1 and the malformed-Credits check
     per item 4). Checks 1-14 unchanged (pure quote/pricing checks,
     including 12d's negative-base-value addition). Checks 15-23
     unchanged (the original 9 real-session checks). Checks 24-28 are
     12d's Part 1 hardening checks, now including
     `checkMalformedNegativePhysicalCreditsStackIgnoredNotSubtracted`
     as check 26. Checks 29-30 are 12d's entity-backed revalidation
     checks (discarded NPC, out-of-range NPC); check 31 is this pass's
     new reused-entity-id/wrong-UUID check. Check 32 (production-
     runtime isolation) still runs last.

  NOT implemented, unchanged from scope (Phase 3 and later, still
  explicitly deferred): identical list to 12d — `ProvisionerNpcEntity`,
  persistent per-entity merchant NBT, randomized assortment,
  `ProvisionerAssortmentPool`, `MerchantStockEntry`, stock
  depletion/restocking, Credit replenishment, buyback, the full
  `TradingScreen` SELL visual redesign, the tutorial quest,
  Relationship/reputation/Persuasion/investment modifiers, Pickpocket,
  Contacts, Blacksmith/Alchemist NPCs, the broader Economy Transaction
  API, ledger history, refunds, an idempotency framework, and the
  unrelated dedicated-server client-classloading fix.

12f. Phase 2 final correction (2026-07-14, later still)
--------------------------------------------------------------------------------
  A single, narrowly-scoped fix to a gap left by 12e's item 4. Phase 3
  still not begun.

  1. `shrinkPhysicalCredits` NOW HONORS THE SAME NON-POSITIVE GUARD AS
     `physicalCredits`. 12e's item 4 hardened `physicalCredits`'s
     read-only total against a malformed (zero-or-negative stored
     amount) Credits stack, but `shrinkPhysicalCredits` — the private
     helper both `payPhysical` and `pay`'s physical-remainder branch
     use to actually SPEND physical Credits — still processed such a
     stack exactly like a legitimate one. For a negative `stackAmount`,
     `take = Math.min(stackAmount, remaining)` came out negative, and
     `remaining -= take` then INCREASED the amount still owed rather
     than leaving it untouched. A malformed negative Credits stack
     sitting in an inventory slot earlier than a player's legitimate
     Credits could therefore make a physical payment consume MORE
     legitimate Credits than the requested amount, while `pay`/
     `payPhysical` still reported success. Fixed by adding the
     identical guard `physicalCredits` already uses
     (`if (stackAmount <= 0) continue;`), placed before `take` is
     computed, so a malformed stack is now skipped outright by both
     the totaling and the spending path. Because `shrinkPhysicalCredits`
     is the single method both `payPhysical` (physical-only) and
     `pay`'s remainder step (mixed Wallet + physical) call, this one
     guard protects both payment paths — no separate fix was needed
     for `pay`.

  2. NEW CHECK. `checkShrinkPhysicalCreditsIgnoresMalformedNegativeStack`
     constructs a malformed −9,999-Credits stack in an earlier
     inventory slot (slot 4) and a legitimate 100-Credit stack in a
     later slot (slot 6), then calls `payPhysical(player, 50)` and
     asserts: the payment succeeds; exactly 50 legitimate Credits
     remain (`physicalCredits` afterward, and the good stack's own
     stored amount, both read back as 50); and — implicitly, by that
     exact remaining amount — the malformed stack neither inflated the
     amount owed nor caused any extra legitimate Credits to be
     removed. Both inventory slots are captured before mutation and
     restored in `finally`, matching every other check's cleanup
     convention (12e item 3).

  3. `gradlew compileJava`: SUCCESSFUL.

  4. RUNTIME-VERIFIED (2026-07-14, `gradlew runClient`, "Testing
     World" reloaded): `[ItemValueVerification] All 19 self-test
     checks passed.`; `[MerchantSellVerification] All 33 self-test
     checks passed.` — 52 checks total, zero failures, on the first
     attempt. Zero unexpected `WARN`/`ERROR` lines from the `totality`
     namespace (the only `totality`-tagged `WARN` lines present are
     the pre-existing, unrelated missing-texture/missing-block-model
     warnings for `ritual_dais_active`, `blessed_incense`, `incense`,
     `zanpakuto`, and `platinum_coin` — unchanged by this correction)
     and zero `PASS` lines printed by default — concise logging
     remains intact.

  5. VERIFICATION SUITE — 33 checks (was 32): net +1, the new check
     from item 2 above. Checks 1-14 and 15-23 unchanged. Checks 24-26
     unchanged (12e's Part 1 hardening checks, including check 26,
     `checkMalformedNegativePhysicalCreditsStackIgnoredNotSubtracted`).
     Check 27 is this pass's new
     `checkShrinkPhysicalCreditsIgnoresMalformedNegativeStack`. Checks
     28-29 are the BUY-overflow/negative-price checks (12e's former
     27-28, shifted by one). Checks 30-31 are the entity-backed
     revalidation checks (12e's former 29-30). Check 32 is the reused-
     entity-id/wrong-UUID check (12e's former 31). Check 33
     (production-runtime isolation) still runs last.

  NOT implemented, unchanged from scope (Phase 3 and later, still
  explicitly deferred): identical list to 12e.

================================================================================
END OF DOCUMENT
================================================================================
