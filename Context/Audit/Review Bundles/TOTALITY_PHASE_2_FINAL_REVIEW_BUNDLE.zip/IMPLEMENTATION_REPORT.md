# Totality — Phase 2 Economy Hardening Pass — Implementation Report

**Scope:** a focused hardening pass over Phase 2's merchant runtime / SELL foundation
(`Context/Audit/TOTALITY_ECONOMY_PRICING_AND_PROVISIONER.md`, Section 12c), driven by a
review-bundle audit — **plus a narrowly-scoped correction pass** over that hardening pass
itself, driven by a second review pass — **plus one final narrowly-scoped correction** to a
single gap the correction pass itself left behind. Preserves all 19 `ItemValueVerification` +
`MerchantSellVerification` checks that already passed at every stage. Does **not** implement
`ProvisionerNpcEntity`, randomized stock, or the TradingScreen SELL redesign (Phase 3,
explicitly out of scope, at every stage).

**Canonical design document:** `Context/Audit/TOTALITY_ECONOMY_PRICING_AND_PROVISIONER.md`,
Sections 12d (hardening pass), 12e (correction pass), and 12f (final correction).

**Date:** 2026-07-14 (hardening pass), 2026-07-14 later the same day (correction pass), 2026-07-14
later still (final correction).

---

## 1. Summary of what was implemented

### Hardening pass (Section 12d)

1. **BUY overflow / negative-price / negative-payment defenses** — `handleBuy` now uses
   `Math.multiplyExact` for `price * quantity` (was raw `*`, which could wrap negative) and
   rejects a negative authored price before any payment. `CreditPaymentHelper.canAfford` and
   `canAffordPhysical` had real bugs — both previously returned `true` for a negative amount —
   now both explicitly reject `amount < 0`. `physicalCredits` sums with saturating (not
   wrapping) addition. `ItemPricingService.sellUnitPayout` throws on a negative input instead
   of returning a positive minimum payout. `ShopRegistry.load` drops negative-priced catalog
   entries as a datapack authoring error, in addition to (not instead of) the transaction-time
   defense.
2. **Verification isolated from production runtime** — `TradeSessionManager` gained
   package-private `startTradeForVerification(...)` entry points accepting an explicitly
   supplied `ShopTemplate` and `MerchantRuntime`. Every session-based self-test uses an
   isolated fixture instead of the real `totality:test_trader` shop / shared registry-cached
   runtime, wrapped in `try/finally` cleanup.
3. **Merchant-runtime / trade-session logical-server lifecycle** — `MerchantRuntimeRegistry` is
   keyed by `MinecraftServer`, cleared on `SERVER_STOPPED`; `TradeSessionManager` also clears
   all sessions on `SERVER_STOPPED`. Prevents state leaking from one integrated world into the
   next in the same client JVM.
4. **Entity-backed trade session revalidation** — `ActiveTrade` stores the NPC's UUID and
   dimension. A `revalidateNpc` check runs before every BUY/SELL commit: entity exists, alive,
   not removed, same UUID, same dimension, in range (reusing the existing 8-block interaction
   constant, now named `TotalityNpcEntity.INTERACTION_RANGE_SQR`), and still owns the
   interaction lock. `startTrade` releases a replaced session's previous NPC lock.
5. **Structured transaction results, no rejection-warning spam** — `handleBuy`/`handleSell`
   return `BuyResult`/`SellResult` records instead of logging `WARN` for every rejection.
6. **Small defensive cleanup** — `InMemoryMerchantRuntime` rejects null `merchantId`/
   `acceptedTags` and stores `Set.copyOf(acceptedTags)`.
7. **Verification suite grew from 22 to 31 checks.**

### Correction pass (Section 12e) — 4 further, narrower fixes found by a second review

1. **UUID-safe lock release.** `releaseTradePartner` resolved the recorded NPC by dimension +
   numeric id ALONE (no UUID check) before releasing its lock — `revalidateNpc` already checked
   the UUID, but `releaseTradePartner` did not, so a numeric id that resolved to an unrelated
   entity could have its lock incorrectly released. Fixed by centralizing UUID-safe resolution
   into `resolveRecordedNpc`, used by both. A new `matchesUuid(candidate, expectedUuid)`
   predicate was extracted and is what the new verification check drives directly (see Section 3
   for why a live end-to-end repro turned out not to be possible in this self-test harness).
2. **Lifecycle verification no longer mutates the production registry.** A synthetic check
   previously called `MerchantRuntimeRegistry.getOrCreate`/`clearForServer` directly against the
   REAL development server. Removed outright — the documented two-consecutive-logical-server
   runtime test already proves the same `SERVER_STOPPED` behavior for real, without that side
   effect.
3. **Verification cleanup now matches its own documentation.** `runSessionCheck` previously
   left wallet restoration to each check body individually (skippable by a thrown exception); it
   now captures and restores the wallet value and the test slot's original contents in `finally`
   unconditionally. The two standalone checks that mutate the fake player outside
   `runSessionCheck` gained their own `try/finally` for the same reason.
4. **Malformed physical Credits hardened.** `physicalCredits`'s saturation guard
   (`amount > 0 && ...`) only gated the saturating branch, not the addition itself — a
   zero-or-negative stored amount (safely constructible; `CreditsItem.setAmount` performs no
   validation) fell through to `total + amount`, actually SUBTRACTING from the total. Fixed by
   skipping any non-positive stored amount entirely before the addition runs.

**Verification suite: 32 checks** (net +1 from 31: −1 for removing the lifecycle check, +2 for
the new UUID-match check and the new malformed-Credits check).

### Final correction pass (Section 12f) — 1 further, narrower fix

1. **`shrinkPhysicalCredits` hardened against the same malformed stack `physicalCredits` was
   already fixed against.** The correction pass's item 4 fixed `physicalCredits`'s read-only
   total, but `shrinkPhysicalCredits` — the private helper both `payPhysical` and `pay`'s
   physical-remainder branch use to actually SPEND physical Credits — still processed a
   zero-or-negative stored amount like a legitimate one: `take = Math.min(stackAmount,
   remaining)` came out negative, and `remaining -= take` then INCREASED the amount still owed.
   A malformed negative Credits stack sitting before legitimate stacks could make a payment
   consume MORE legitimate Credits than requested while still reporting success. Fixed with the
   identical guard `physicalCredits` already uses (`if (stackAmount <= 0) continue;`), placed
   before `take` is computed. Because `shrinkPhysicalCredits` is the one method both payment
   paths share, this single guard covers physical-only (`payPhysical`) and mixed Wallet+physical
   (`pay`) payments alike — no separate fix was needed for `pay`.

**Verification suite: 33 checks** (net +1 from 32: the new
`checkShrinkPhysicalCreditsIgnoresMalformedNegativeStack` check).

---

## 2. Every file created or modified (cumulative across both passes)

### Created (hardening pass only; untouched by the correction pass)

| Path | Purpose |
|---|---|
| `src/main/java/zcylas/totality/api/shop/BuyResult.java` | Structured `handleBuy` outcome |
| `src/main/java/zcylas/totality/api/shop/SellResult.java` | Structured `handleSell` outcome |

### Modified

| Path | Hardening pass | Correction pass | Final correction |
|---|---|---|---|
| `src/main/java/zcylas/totality/api/shop/TradeSessionManager.java` | Checked BUY arithmetic; `BuyResult`/`SellResult` returns; `startTradeForVerification`; entity-backed `revalidateNpc`; `ActiveTrade` carries NPC UUID+dimension; replaced-session lock release; `SERVER_STOPPED` session clear | `resolveRecordedNpc` centralized and used by `releaseTradePartner` too; new `matchesUuid` predicate | — unchanged — |
| `src/main/java/zcylas/totality/api/shop/MerchantRuntimeRegistry.java` | Keyed by `MinecraftServer`; `SERVER_STOPPED` clears per-server state; new non-creating `peek(...)` | — unchanged — | — unchanged — |
| `src/main/java/zcylas/totality/api/shop/InMemoryMerchantRuntime.java` | Null checks; `Set.copyOf(acceptedTags)` | — unchanged — | — unchanged — |
| `src/main/java/zcylas/totality/api/shop/MerchantSellVerification.java` | Isolated fixtures; `try/finally` session cleanup; 9 new hardening checks (31 total) | Removed the production-mutating lifecycle check; `runSessionCheck` now restores wallet+slot in `finally`; 2 standalone checks gained `try/finally`; 2 new checks (malformed Credits, UUID-match) — 32 total | 1 new check, `checkShrinkPhysicalCreditsIgnoresMalformedNegativeStack` — 33 total |
| `src/main/java/zcylas/totality/api/shop/ShopRegistry.java` | Drops negative-priced catalog entries at load | — unchanged — | — unchanged — |
| `src/main/java/zcylas/totality/api/economy/currency/CreditPaymentHelper.java` | `canAfford`/`canAffordPhysical` reject negative amounts; `physicalCredits` saturates | `physicalCredits` also skips non-positive stored amounts entirely (was still subtracting them) | `shrinkPhysicalCredits` now skips non-positive stored amounts too (was still inflating the amount owed) |
| `src/main/java/zcylas/totality/api/economy/value/ItemPricingService.java` | `sellUnitPayout` throws on negative input; `quote(...)` guards its call site | — unchanged — | — unchanged — |
| `src/main/java/zcylas/totality/entity/npc/TotalityNpcEntity.java` | New public `INTERACTION_RANGE_SQR` constant; new `isInteractionLockOwnedBy(Player)` | — unchanged — | — unchanged — |
| `src/main/java/zcylas/totality/networking/shop/BuyItemHandler.java` | Inspects `BuyResult`; logs `WARN` only for `INVALID_INDEX`/`OVERFLOW` | — unchanged — | — unchanged — |
| `src/main/java/zcylas/totality/networking/shop/SellItemHandler.java` | Inspects `SellResult`; logs `WARN` only for `INVALID_SLOT`/`INVALID_QUANTITY` | — unchanged — | — unchanged — |
| `src/main/java/zcylas/totality/Totality.java` | Registers `MerchantRuntimeRegistry.register()`, `TradeSessionManager.register()` | — unchanged — | — unchanged — |
| `Context/Audit/TOTALITY_ECONOMY_PRICING_AND_PROVISIONER.md` | New Section 12d | New Section 12e | New Section 12f |

**Not included (unmodified by either pass):** `MerchantRuntime` (interface, untouched),
`MerchantSellQuoteView`, `ShopEntry`, `ShopTemplate`, `ShowShopStatePayload`,
`ShopEntryDisplayData`, `BuyItemPayload`, `SellItemPayload`, `CloseTradePayload`,
`CloseTradeHandler`, `ItemValueRegistry`, `ItemValueVerification`, `ItemValueRule`,
`PricingContext`, `PriceQuote`, `PricingDirection`, `VerificationReporter`,
`item_values/*.json`, `provisioner_buys.json`.

---

## 3. Key implementation decisions

**Checked arithmetic, not clamped.** `Math.multiplyExact`/`Math.addExact` throw
`ArithmeticException` on overflow rather than silently saturating.

**Verification isolation via dependency injection, not save/restore.** A check that throws
mid-body still can't leave a mutated production runtime behind, because it was never touching
one to begin with. The correction pass extended this same discipline to wallet/slot state that
the hardening pass had left to individual check bodies.

**One interaction-distance constant, not two.** `TotalityNpcEntity.INTERACTION_RANGE_SQR` is
extracted from the existing per-tick safety-net check in `customServerAiStep` rather than
inventing a second number for `TradeSessionManager.revalidateNpc` to use.

**A live numeric-id collision cannot be forced through the public entity-spawning API, and this
self-test harness cannot exercise live entity resolution at all.** The correction pass's UUID
check went through three real design iterations, documented honestly rather than glossed over:
  1. First attempt: force two `TotalityNpcEntity` instances to share a numeric id via
     `Entity.setId()` called before the second `addFreshEntity`. **Failed** — empirically,
     `addFreshEntity` assigns its own id regardless of what was pre-set (ids come from a
     monotonically increasing counter and are never reused within one running server).
  2. Second attempt: keep the (working, in principle) `resolveRecordedNpc(player, dimension,
     id, uuid)` overload, but suspect a chunk-loading gap — force the target chunk to load
     synchronously via `ServerLevel#getChunk` before spawning. **Failed** — the diagnostic
     (`rawGetEntity=null`) proved the entity was still unresolvable even after that.
  3. Root cause, confirmed by that diagnostic: this suite runs at `SERVER_STARTED`, before the
     server has processed a single tick. `Level#getEntity(int)`'s lookup is populated by
     tick-driven entity-section processing — a freshly spawned entity is never visible to it at
     this point in server startup, independent of chunk-load state. This is a characteristic of
     testing at `SERVER_STARTED` specifically, not a bug in the fix under test (a real
     Provisioner is always resolvable by the time a player can interact with it, many ticks
     after spawn).
  4. **Final, working design:** extracted `matchesUuid(candidate, expectedUuid)` as its own
     package-visible predicate — the ONLY part of `resolveRecordedNpc` that depends on comparing
     two UUIDs, with the null/level-lookup guards around it being simple, low-risk delegation to
     well-established APIs that don't need the same scrutiny. The check drives this predicate
     directly against two real, distinct, never-added-to-a-level `TotalityNpcEntity` objects (a
     positive control and an "impostor"), which needs no chunk/tick machinery at all and passed
     cleanly on the first attempt once implemented.

This also revealed (but this pass did **not** fix, as out of its narrow scope) that the
hardening pass's two existing entity-backed checks (`checkDiscardedNpc...`,
`checkOutOfRangeNpc...`) likely also can't exercise live id-based entity resolution in this
harness — they still pass, but for the weaker reason that "no session mutation occurs" holds
whether the NPC is correctly resolved-then-rejected or simply never resolved at all. Not
addressed here per the task's explicit "do not redesign the broader interaction-lock system"
instruction; worth revisiting if this harness's `SERVER_STARTED` timing ever needs to prove
positive entity resolution again.

---

## 4. Networking changes

None beyond the hardening pass (no new payloads either pass).

---

## 5. Persistence changes

None (unchanged from the hardening pass).

---

## 6. Verification and runtime results

**`gradlew compileJava`: SUCCESSFUL** (all three passes).

**Hardening pass, `gradlew runClient`, TWO consecutive logical-server starts** ("Testing World"
loaded, fully quit, reloaded) — both starts logged identically:

```
Parsed 20 item value rules: 20 accepted, 0 rejected, across 19 items
[ItemValueVerification] All 19 self-test checks passed.
[MerchantSellVerification] All 31 self-test checks passed.
```

**Correction pass, `gradlew runClient`, "Testing World" reloaded** (after 3 implementation
iterations on the UUID-match check specifically, as described in Section 3 — every OTHER check
passed on every attempt, including the first):

```
Parsed 20 item value rules: 20 accepted, 0 rejected, across 19 items
[ItemValueVerification] All 19 self-test checks passed.
[MerchantSellVerification] All 32 self-test checks passed.
```

**Final correction, `gradlew runClient`, "Testing World" reloaded** (passed on the first
attempt):

```
[ItemValueVerification] All 19 self-test checks passed.
[MerchantSellVerification] All 33 self-test checks passed.
```

- **52 checks total, zero failures**, in the final confirmed run.
- **Zero unexpected `WARN`/`ERROR` lines from the `totality` namespace** (confirmed by grep; the
  only `totality`-tagged `WARN` lines present are pre-existing, unrelated missing-texture/
  missing-block-model warnings — `ritual_dais_active`, `blessed_incense`, `incense`,
  `zanpakuto`, `platinum_coin` — unchanged by this correction).
- **Zero `PASS` lines** printed by default (concise mode intact).
- **No self-test merchant runtime remained in the production registry after verification**
  (`checkVerificationNeverTouchesProductionRuntime`, run last, passed).

Every world load/reload across all three passes was driven directly against the "Testing World"
save while watching the log live.

---

## 7. Known limitations and explicitly deferred scope

Unchanged from the hardening pass, still explicitly out of scope: `ProvisionerNpcEntity`,
persistent per-entity merchant NBT, randomized assortment, `ProvisionerAssortmentPool`,
`MerchantStockEntry`, stock depletion/restocking, Credit replenishment, buyback, the full
`TradingScreen` SELL visual redesign, the tutorial quest, Relationship/reputation/Persuasion/
investment modifiers, Pickpocket, Contacts, Blacksmith/Alchemist NPCs, the broader Economy
Transaction API, ledger history, refunds, an idempotency framework, and the unrelated
dedicated-server client-classloading fix.

A wrong-dimension entity-backed session case still has no dedicated check (same reasoning as
the hardening pass: it exercises the same `player.level() == npc.level()` branch the
out-of-range check already covers). The entity-resolution-timing limitation of the
`SERVER_STARTED` self-test harness described in Section 3 is also an acknowledged, unaddressed
gap in the two pre-existing entity-backed checks, left as-is per this pass's narrow scope.

---

## 8. Reviewer notes on this bundle's patch

`phase_changes.patch` is ONE cumulative diff against the ORIGINAL pre-hardening baseline (Phase
2's own final, playtest-confirmed state, captured to disk before the hardening pass's first
edit) — so it reflects the hardening pass, the correction pass, AND this final correction
together, not three separate patches to reconcile. 10 files diff against that saved baseline;
`BuyItemHandler.java` (untouched by any uncommitted Phase 1/2 work, cleanly git-tracked) diffs
against `git show HEAD:...`; `BuyResult.java`/`SellResult.java` (new in the hardening pass,
untouched by either correction) diff against `/dev/null`. `files/` in this bundle always
contains the current, real, authoritative content — post-final-correction — regardless of patch
derivation.
