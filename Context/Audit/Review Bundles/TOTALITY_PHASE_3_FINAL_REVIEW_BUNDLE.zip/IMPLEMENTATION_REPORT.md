# Totality — Phase 3 Provisioner Hardening Pass — Implementation Report

**Scope:** a focused hardening pass over Phase 3's Provisioner assortment / per-entity stock /
entity-backed BUY-SELL work (`Context/Audit/TOTALITY_ECONOMY_PRICING_AND_PROVISIONER.md`,
Section 12g), driven by Stefan's manual finding that `/summon totality:provisioner` generated a
named Provisioner correctly, but right-clicking it did nothing. Preserves every check that
already passed (97/97 at the start of this pass). Does **not** begin Phase 4 (Trading Screen
visual redesign, BUYBACK, restocking, the tutorial quest, natural Provisioner spawning, or any of
Section 10's future integrations).

**Canonical design document:** `Context/Audit/TOTALITY_ECONOMY_PRICING_AND_PROVISIONER.md`,
Section 12h.

**Date:** 2026-07-14.

**Pre-hardening baseline:** commit `c54eadb` ("Phase 3: Provisioner assortment, per-entity stock,
stock-aware BUY (pre-hardening baseline)") — a snapshot of Phase 1-3 work, committed at the start
of this session specifically so this pass's changes could be diffed cleanly (`phase_changes.patch`
in this bundle is `git diff c54eadb -- src/main`, plus a reconstructed diff of the canonical
document, which is untracked in git).

---

## 1. Summary of what was implemented

### 1. Root cause found and fixed: dedicated Provisioner default dialogue/assortment configuration

Audited the existing manually-configured test-NPC flow first, per task instruction, before
assuming `TotalityNpcEntity.mobInteract` was broken — it wasn't. The actual bug: `/summon` (and
any other command/structure spawn) routes through `EntityType.loadEntityRecursive`, which ALWAYS
calls `Entity#load` — even with no explicit NBT argument — and
`TotalityNpcEntity.readAdditionalSaveData` read `DialogueId` via `getStringOr(key, "")`,
unconditionally resetting `dialogueId` to `null` whenever the key was absent. `ProvisionerNpcEntity`'s
constructor set the dialogue via `setDialogueId(GREETING_DIALOGUE)`, but that default was silently
overwritten moments later by the load call. Natural mob spawning never hit this (`finalizeSpawn`
never calls `load`), which is why the bug was easy to miss.

**Fix:** new `protected @Nullable Identifier defaultDialogueId()` hook on `TotalityNpcEntity`
(returns `null` — unchanged behavior for the plain `totality:totality_npc` test NPC, which still
requires manual configuration by design). `readAdditionalSaveData` now falls back to this hook
ONLY when the NBT key is genuinely absent; an explicitly authored value always wins, and once the
default is applied it gets written back out on the next save, so it never needs re-defaulting.
`ProvisionerNpcEntity` overrides the hook to return `provisioner_greeting`.

**Merchant/shop/profile ID:** audited and found not applicable — `OpenProvisionerShopAction` takes
no parameters and calls `TradeSessionManager.startEntityBackedTrade` directly; a Provisioner never
resolves a `ShopRegistry` `shop_id`. Its merchant identity, `MerchantRuntime.merchantId()`
(`"provisioner/" + getUUID()`), is always well-formed by construction — nothing to default.
`AssortmentPoolId` already defaulted correctly (confirmed by a new test, no code change needed).

**New checks (6):** default `dialogueId` when NBT absent (the real regression test, via new
test-only `simulateFullLoadForTest`/`simulateFullSaveForTest` hooks driving the REAL
`readAdditionalSaveData` chain against a genuinely empty `ValueInput`); `merchantId()` always
well-formed; default `AssortmentPoolId` when absent; explicit custom IDs never overwritten; a
defaulted `dialogueId` survives a real save/load round-trip; `provisioner_greeting` has a valid
Trade choice using `open_provisioner_shop`, verified against the real `DialogueRegistry`.

### 2. Negative persisted merchant Credits / invalid merchant state

`ProvisionerNpcEntity.readPhase3State`: negative persisted `CurrentCredits` sanitizes to `0` (one
clear `ERROR` log), without touching `CreditsInitialized` — never re-rolls the 300 baseline merely
because a corrupted value was sanitized. `setCurrentCredits` now also marks `creditsInitialized =
true` on every successful call, including `setCurrentCredits(0)` — previously that specific case
left the marker false and a later re-initialization would silently replace the caller's explicit 0
with 300. `TradeSessionManager.handleBuy` (template-backed) and `handleStockBuy` (stock-backed)
both now reject with new `BuyResult.Reason.INVALID_MERCHANT_STATE` if
`merchant.currentCredits() < 0`, before any payment or mutation.

**New checks (4):** negative persisted Credits sanitize without restoring the baseline;
`setCurrentCredits(0)` marks initialized and blocks the later baseline; a stock-backed BUY against
a corrupt-negative merchant is rejected and changes nothing; the same for a template-backed BUY.

### 3. Missing-assortment-pool retry throttling

`customServerAiStep` previously called the pool-init/roll logic (which logs `ERROR` on a missing
pool) unconditionally every tick — up to ~20 log lines/second for a genuinely missing pool. Fixed
with two new transient (NOT NBT-persisted) fields: `stockInitFailureLogged` (logs once, clears on
success) and `ticksUntilNextStockInitAttempt` (throttles the actual retry — not just the log — to
once every 200 ticks). Documented as protection against initialization ordering/future
compatibility, not a promise of live `/reload`.

**New check (1):** drives a new test-only `runAiStepForTest` hook through the full throttle
lifecycle — bad pool fails once, 5 further ticks do not retry, switching to a valid pool and
advancing through the remaining window initializes exactly once. Runtime-confirmed: the same
throttled entity, driven through 205 total simulated ticks, produced exactly one `ERROR` line.

### 4. Assortment weight overflow / excessive roll count

`ProvisionerAssortmentPool.validate()` already summed a group's weights via checked `long`
arithmetic but never compared the total against `Integer.MAX_VALUE` — generation
(`AssortmentSelectionGroup.pick`) uses `int`/`random.nextInt(int)`, so a valid-looking sum past
that ceiling would silently wrap during rolling. Now rejected at validation time. Added
`MAX_GROUP_ROLLS = 1000`, a documented datapack-safety bound (not gameplay balance) guarding
especially against a malformed `distinct = false` group generating an unbounded list.

**New checks (2):** two entries at `Integer.MAX_VALUE` weight each rejected; a `distinct = false`
group requesting 1,000,000 rolls rejected.

### 5. Assortment definitions made immutable

`AssortmentItemEntry` now rejects null and stores/returns defensive `ItemStack` copies (without
normalizing the authored count, so `validate()` can still catch a malformed count as an authoring
error). `WeightedAssortmentEntry`/`ChanceAssortmentEntry` reject null `entry`.
`AssortmentSelectionGroup`/`ProvisionerAssortmentPool` reject null lists and store
`List.copyOf(...)` snapshots.

**Incidental fix found while writing these tests:** `MerchantStockEntry`'s constructor called
`item.setCount(1)` unconditionally — but `ItemStack#copy()`'s fast path for an EMPTY stack returns
the SHARED `ItemStack.EMPTY` singleton, not a fresh instance. Calling `setCount(1)` on it (exactly
what Section 7's "empty item template" tests need to construct) would have mutated that singleton
in place for the rest of the JVM session — a real, previously-latent landmine. Fixed by guarding
with `!item.isEmpty()`.

**New checks (3):** mutating a returned `ItemStack` doesn't affect a later read; mutating the
original constructor list doesn't affect an already-built pool; a pool's exposed lists all throw
`UnsupportedOperationException` on `.add()`.

### 6. Explicit BUY quantity validation (not clamped)

Both `handleBuy` and `handleStockBuy` used `Math.max(1, Math.min(100, quantity))`, silently
coercing 0/negative to 1 and anything above 100 to 100. Replaced with an explicit
`if (quantity < 1 || quantity > 100) return BuyResult.rejected(BuyResult.Reason.INVALID_QUANTITY);`
in both, checked before price calculation, affordability, payment, delivery, and any
merchant/stock mutation. `BuyItemHandler` now also warns on `INVALID_QUANTITY` (the real UI
already clamps client-side and can never produce this).

**New checks (2):** one per BUY path, each driving `0`, `-1`, `101`, and `Integer.MAX_VALUE` in one
session, asserting every one is rejected and changes nothing.

### 7. All-or-nothing persisted stock validation

The CODEC's own list decode already failed as a whole for a structurally malformed entry. Added a
second, semantic pass (`isValidPersistedStock`, new `public` method) over a structurally-valid-but-
corrupt list: an empty item template, or a duplicate item+components entry. Either violation
discards the entire persisted list (never a partial subset); `StockInitialized` is preserved
exactly as persisted either way, so corruption degrades to "sold out," never a reroll or
duplication.

**New checks (4):** empty item template rejected; duplicate entries rejected while distinct ones
are accepted; a mixed valid+invalid list rejected in its entirety; a full NBT round-trip with
corrupt (duplicate) persisted stock confirms the reload ends up empty but still `stockInitialized`.

### 8. Live-entity re-resolution — confirmed unchanged, not regressed

`revalidateNpc`/`currentNpc`/`currentMerchant`/`currentStockProvider`/`resolveRecordedNpc`/
`matchesUuid`/`releaseTradePartner` were not modified. The new `INVALID_MERCHANT_STATE`/
`INVALID_QUANTITY` checks were added strictly after the existing revalidation/resolution calls in
both `handleBuy` and `handleStockBuy`. Confirmed by re-reading every call site and by every
pre-existing entity-backed check still passing unchanged.

### 9. Delayed real entity-backed transaction smoke test — added

Every pre-existing check runs at `SERVER_STARTED`, before a single tick — a freshly spawned entity
is provably not yet visible to `Level#getEntity(int)` at that point. A new suite,
`ProvisionerEntityBackedSmokeTest`, uses the pre-existing (previously unused) `ServerScheduler` to
queue a genuine one-shot check 40 ticks (~2s) after server start. It spawns a real
`ProvisionerNpcEntity`, confirms it resolves via the same production entity lookup
`DialogueSessionManager` uses, then drives one real BUY and one real SELL via the actual
`TradeSessionManager.startEntityBackedTrade`/`handleBuy`/`handleSell` entry points — confirming
Credits/stock change on the live entity and a sold item never becomes ordinary stock. Cleans up
fully in `finally`. Does not simulate an actual mouse click or dialogue UI (no input-injection tool
exists in this environment) — the still-manual step remains Stefan physically right-clicking the
NPC.

### 10-11. Compile / runtime verification

`gradlew compileJava`: SUCCESSFUL on first attempt.

`gradlew runClient --args="--quickPlaySingleplayer \"Testing World\""`: world auto-loaded, player
joined.
```
Parsed 20 item value rules: 20 accepted, 0 rejected, across 19 items
[ItemValueVerification] All 19 self-test checks passed.
[MerchantSellVerification] All 33 self-test checks passed.
Loaded 1 provisioner assortment pool(s), 0 rejected
[ProvisionerVerification] All 67 self-test checks passed.
[ProvisionerEntityBackedSmokeTest] All 4 self-test checks passed.
```
123 checks total, zero failures. Exactly four `ERROR` lines in the entire log, all expected and
self-generated by this pass's own synthetic negative-tests (negative-Credits sanitize,
corrupt-duplicate-stock discard, and two missing-pool retry checks) — no unrelated, unexpected
`WARN`/`ERROR`. The two missing-pool `ERROR` lines each fired exactly once despite one of them
being driven through 205 simulated tick attempts, directly confirming the retry throttle. Zero
`PASS` lines by default.

### 12. Manual, interactive verification

Same standing limitation as every prior phase: this environment cannot drive the actual Minecraft
client window (no input-injection tool). The 15-item manual checklist (Section 10 of the task
instruction) was **not** performed by Claude Code and must not be claimed as passed. The "Testing
World" client was left running (world loaded, player joined, all automated suites green) so Stefan
can drive it manually without relaunching.

---

## 2. Verification counts

| Suite | Before this pass | After this pass |
|---|---|---|
| ItemValueVerification | 19 | 19 (unchanged) |
| MerchantSellVerification | 33 | 33 (unchanged) |
| ProvisionerVerification | 45 | 67 (+22) |
| ProvisionerEntityBackedSmokeTest | — (did not exist) | 4 (new suite) |
| **Total** | **97** | **123** |

## 3. Files changed

See `MANIFEST.txt` for the full annotated list. Summary: 11 files modified in `src/main/java`
(no new files), plus the canonical design document (`Context/Audit/TOTALITY_ECONOMY_PRICING_AND_
PROVISIONER.md`, new Section 12h). No files deleted. No datapack JSON changed.

## 4. Explicitly out of scope / deferred (unchanged)

Phase 4 Trading Screen visual redesign, BUYBACK, buyback inventory, restocking, assortment
rotation, Credit replenishment, the tutorial quest, a proximity quest trigger, Relationship,
reputation, Persuasion modifiers, Investment, Pickpocket, Contacts, Blacksmith, Alchemist, natural
Provisioner spawning, the Provisioner Trading Post structure, village integration, home
position/wander-radius, a broader transaction ledger, refund history, an idempotency framework, and
the unrelated dedicated-server client-classloading fix.

## 5. Manual checks still required (Stefan)

1. `/summon totality:provisioner`
2. Confirm generated name and gender.
3. Right-click the Provisioner.
4. Confirm Dialogue opens.
5. Confirm a Trade option is present.
6. Select Trade.
7. Confirm the existing Trading Screen opens.
8. Buy one item; verify Provisioner Credits increase and stock decreases.
9. Close and reopen the shop; verify stock does not reroll.
10. Save and reload the world; verify stock, Credits, identity, and dialogue configuration persist.
11. Confirm a second Provisioner has independent stock and Credits.

None of these have been reported as passed by Stefan as of this bundle's creation.
