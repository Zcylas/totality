# Totality — Minecraft 26.1.2 → 26.2 Migration Report

Branch: `migration/minecraft-26.2` (based on checkpoint `953a677`, migration baseline `46a3591`)
Date: 2026-07-16

## 15.1 Environment

| Component | Final version |
|---|---|
| Minecraft | 26.2 |
| Fabric Loader | 0.19.3 |
| Fabric API | 0.154.2+26.2 |
| Fabric Loom (property / resolved) | 1.17-SNAPSHOT / 1.17.14 |
| Gradle | 9.5.1 |
| Java | 25 (Eclipse Adoptium 25.0.2.10-hotspot) |

## 15.2 Changed files, grouped by cause

**Screen API** (`Minecraft.screen`/`setScreen` → `Minecraft.gui.screen()`/`gui.setScreen`):
`client/dialogue/ClientDialogueManager.java`, `client/economy/ClientBankTellerManager.java`,
`client/item/AttunementClientManager.java`, `client/quest/ClientQuestManager.java`,
`client/renderer/hud/context/AbilityContextHud.java`, `client/shop/ClientTradeManager.java`,
`init/TotalityKeybindHandlers.java`, `init/TotalityMovementHandler.java`,
`item/energy/PhoneItem.java`, `networking/TotalityClientPacketHandlers.java`,
`networking/dice/DiceRollResultClientHandler.java`, `mixin/client/LocalPlayerContainerMixin.java`,
`screen/ability/AbilityRadialScreen.java`, `screen/ability/SpellRadialScreen.java`,
`screen/ancestry/ConfirmAncestryScreen.java`, `screen/ancestry/OriginSelectionScreen.java`,
`screen/ancestry/SpeciesSelectionScreen.java`, `screen/character/CharacterScreen.java`,
`screen/character/tabs/ClassTab.java`, `screen/economy/BankTellerScreen.java`,
`screen/equipment/AccessoryInventoryButton.java`, `screen/inventory/TotalityInventoryScreen.java`,
`screen/magic/GrimoireRadialScreen.java`, `screen/menu/AbilitiesScreen.java`,
`screen/phone/BankScreen.java`, `screen/phone/PhoneAppGridScreen.java`,
`screen/phone/PhoneScreens.java`, `screen/phone/PhoneSetupScreen.java`,
`screen/quest/QuestScreen.java`,
plus `screen/classes/ClassSelectionScreen.java`, `ConfirmClassScreen.java`,
`CovenantSelectionScreen.java`, `SubclassSelectionScreen.java` (revealed after the first 100-error cap cleared).

**HUD/options API** (`Options.hideGui` → `Minecraft.gui.hud.isHidden()`):
`client/hud/resource/SecondaryResourceHud.java`, `client/hud/rest/RestHud.java`,
`client/quest/QuestTrackerHud.java`, `client/renderer/hud/MobHealthBarHud.java`,
`client/renderer/hud/TotalityHudRenderer.java`, `client/renderer/hud/notification/NotificationManager.java`.

**Tags** (removed `BlockTags` ore/log constants → `ModTags.VANILLA_*` passthrough constants):
`init/ModTags.java` (new constants added), `api/ability/impl/VeinminerAbility.java`,
`api/ability/kryptonian/HeatVisionAbility.java`, `api/rpg/skills/mining/MiningXpTable.java`,
`api/rpg/skills/mining/ProspectorGemTable.java`.

**Mappings** (renamed/moved vanilla symbols):
`item/magic/rune/effect/HarvestEffect.java` (`BlockPos.getBottomCenter()` → `Vec3.atBottomCenterOf`),
`item/magic/rune/effect/LightningEffect.java` (`EntityType.LIGHTNING_BOLT` → `EntityTypes.LIGHTNING_BOLT`),
`worldgen/ModBiomes.java` (`EntityType.FROG`/`SLIME` → `EntityTypes.FROG`/`SLIME`).

**Datagen**:
`datagen/ModBlockTagProvider.java`, `datagen/ModItemTagProvider.java`
(`valueLookupBuilder` → `builder`, block/item `.add(X)` → `.add(key(X))` since
`BlockItemTagAppender.add` now takes a `ResourceKey`, not the registry object),
`datagen/ModBlockLootTableProvider.java` (`StatePropertiesPredicate` moved
`net.minecraft.advancements.criterion` → `net.minecraft.advancements.predicates`).

**Rendering**:
`api/client/gui/TotalityGuiRenderer.java`, `client/renderer/ability/HeatVisionBeamRenderer.java`,
`client/renderer/energy/SidedOverlayRenderer.java` (full GPU-pipeline rewrite, see §15.3).

**Mixins**:
`mixin/client/ItemInHandRendererMixin.java` (retargeted renamed methods),
`mixin/GameRendererMixin.java` (dropped now-invalid injection),
`mixin/client/GuiExtractRenderStateMixin.java` (**new file** — the injection moved here),
`mixin/client/LocalPlayerContainerMixin.java` (redirect target moved `Minecraft`→`Gui`),
`src/main/resources/totality.mixins.json` (registered the new mixin).

**Worldgen** (genuine vanilla behavior change, not a syntax migration):
`worldgen/TotalityOverworldClimate.java` (`EXPECTED_VANILLA_POINT_COUNT`/`_FINGERPRINT` bumped for
vanilla's new Sulfur Caves biome — see §15.6),
`worldgen/TotalityOverworldSurfaceRules.java` (`SurfaceRules.isBiome`/`noiseCondition` signature changes).

**Generated resources** (datagen re-run output — see §15.6 for why these changed):
`src/main/generated/data/minecraft/worldgen/noise_settings/overworld.json`,
17 files under `src/main/generated/data/totality/loot_table/blocks/*.json`,
4 files under `src/main/generated/data/totality/recipe/*.json`.

## 15.3 API migration table

| Old (26.1.2) | New (26.2) | Files | Syntactic/Semantic | Runtime verification | Remaining uncertainty |
|---|---|---|---|---|---|
| `Minecraft.screen` field | `Minecraft.gui.screen()` | 30 files (§15.2) | Syntactic (field moved onto `Gui`, identical semantics — confirmed by reading `Gui.java`) | Verified: dev client opened dialogue via join, quest screen loaded, no crash | None |
| `Minecraft.setScreen(x)` | `Minecraft.gui.setScreen(x)` | Same 30 files | Syntactic | Verified in same client run | None |
| `Minecraft.getInstance().getMainRenderTarget()` | `Minecraft.getInstance().gameRenderer.mainRenderTarget()` | `HeatVisionBeamRenderer`, `SidedOverlayRenderer` | Syntactic | Not visually confirmed (no beam/overlay cast during the bounded playtest) | Heat Vision beam and energy overlay visuals need a manual pass (see §15.8) |
| `Options.hideGui` | `Minecraft.gui.hud.isHidden()` | 6 HUD files | Syntactic (field relocated from `Options` onto the new `Hud` class) | Not manually toggled during the bounded playtest | HUD-hide behavior needs manual confirmation (F1 toggle) |
| `BlockTags.COAL_ORES`/`DIAMOND_ORES`/`EMERALD_ORES`/`LAPIS_ORES`/`REDSTONE_ORES`/`LOGS_THAT_BURN` | Removed as Java constants; underlying `data/minecraft/tags/block/*.json` files still ship — referenced directly via `TagKey.create(Registries.BLOCK, Identifier.withDefaultNamespace(...))` in new `ModTags.VANILLA_*` constants | `VeinminerAbility`, `HeatVisionAbility`, `MiningXpTable`, `ProspectorGemTable` | Semantic-preserving (same underlying vanilla tag data, just no compile-time constant) | Not runtime-verified (no ore mining / Heat Vision block-burn test performed) | Veinminer ore recognition and Heat Vision log-burning need a manual pass |
| `BlockPos.getBottomCenter()` | `Vec3.atBottomCenterOf(BlockPos)` | `HarvestEffect.java` | Syntactic (confirmed identical vanilla implementation via decompile diff) | Not runtime-verified | Harvest rune drop-position needs a manual pass |
| `EntityType.LIGHTNING_BOLT` / `.FROG` / `.SLIME` (and all other `EntityType.X` constants) | `EntityTypes.LIGHTNING_BOLT` / `.FROG` / `.SLIME` (constants moved to new class `net.minecraft.world.entity.EntityTypes`) | `LightningEffect.java`, `ModBiomes.java` | Syntactic | Not runtime-verified (no lightning rune cast) | Lightning rune effect needs a manual pass |
| `FabricTagsProvider.valueLookupBuilder(tag)` | `FabricTagsProvider.builder(tag)`, returning `BlockItemTagAppender` whose `.add()` takes a `ResourceKey`, not the registry object | `ModBlockTagProvider`, `ModItemTagProvider` | Semantic-preserving, but required wrapping every `.add(X)` as `.add(key(X))` via a new `key()` helper | Verified: datagen ran clean, generated block/item tag JSON is byte-identical to pre-migration output | None |
| `net.minecraft.advancements.criterion.StatePropertiesPredicate` | `net.minecraft.advancements.predicates.StatePropertiesPredicate` | `ModBlockLootTableProvider.java` | Syntactic (package move only) | Verified: `true_wheat_crop.json` loot table regenerated with the block-state condition intact | None |
| `VertexFormat.Mode` / `RenderPipeline.getVertexFormatMode()`/`getVertexFormat()` | `PrimitiveTopology` / `RenderPipeline.getPrimitiveTopology()`/`getVertexFormatBinding(0)`; pipeline builder now uses `.withVertexBinding(int, VertexFormat)` + `.withPrimitiveTopology(PrimitiveTopology)` instead of one `.withVertexFormat(fmt, mode)` call | `TotalityGuiRenderer`, `HeatVisionBeamRenderer`, `SidedOverlayRenderer` | Semantic-preserving rename (confirmed via `RenderPipelines`/`DebugCrosshairRenderer` vanilla source) | GUI rendering (borders, panels, HUD) visually confirmed working during the client run; Heat Vision beam and side overlay compile-correct but not visually confirmed | Beam/overlay visuals need a manual pass |
| `CommandEncoder.mapBuffer(slice, r, w)` returning `GpuBuffer.MappedView` | `GpuBufferSlice.map(r, w)` returning `GpuBufferSlice.MappedView` (mapping moved onto the slice itself, no encoder needed) | `HeatVisionBeamRenderer`, `SidedOverlayRenderer` | Syntactic (confirmed via vanilla `CloudRenderer` source) | Not visually confirmed | See above |
| `RenderSystem.getSequentialBuffer(VertexFormat.Mode)` | `RenderSystem.getSequentialBuffer(PrimitiveTopology)` | Same 2 renderers | Syntactic | Not visually confirmed | See above |
| `RenderPass.setVertexBuffer(int, GpuBuffer)` | `RenderPass.setVertexBuffer(int, GpuBufferSlice)` — call `.slice()` on the buffer | Same 2 renderers | Syntactic | Not visually confirmed | See above |
| `RenderPass.drawIndexed(firstIndex, baseVertex, indexCount, instanceCount)` (4 args) | `RenderPass.drawIndexed(indexCount, instanceCount, firstIndex, baseVertex, firstInstance)` (5 args, Vulkan-style) | Same 2 renderers | **Semantic** — argument order and count both changed; confirmed against vanilla `DebugCrosshairRenderer`/`CloudRenderer` usage | Not visually confirmed | See above |
| `VertexFormat.uploadImmediateIndexBuffer(ByteBuffer)` (for sorted translucent quads) | Removed; `MeshData.sortQuads(...)` now returns a `SortState`, and the sorted index bytes must be uploaded manually via `RenderSystem.getDevice().createBuffer(label, GpuBuffer.USAGE_INDEX, byteBuffer)` — an ephemeral buffer we now explicitly `.close()` after the draw | `SidedOverlayRenderer.java` | Semantic — required a small manual buffer-lifetime addition (`ownsIndices` flag) not present in the old code, since the fixed helper method no longer manages its own buffer lifetime | Not visually confirmed | Side overlay visuals need a manual pass |
| `Minecraft.getMainRenderTarget()` (used in `createRenderPass`) + `OptionalInt.empty()` for the clear-color param | `gameRenderer.mainRenderTarget()` + `Optional.empty()` (the clear-color param is `Optional<Vector4fc>`, not `OptionalInt` — this was silently wrong before too, just masked by the `getMainRenderTarget()` compile error) | Same 2 renderers | Semantic (type correction) | Not visually confirmed | See above |
| `ItemInHandRenderer.renderArmWithItem(...)` / `.renderHandsWithItems(...)` | `.submitArmWithItem(...)` / `.submitHandsWithItems(...)` (renamed, identical parameter lists) | `mixin/client/ItemInHandRendererMixin.java` | Syntactic (confirmed via javap — same descriptors, new names) | **Verified at runtime** — this exact mismatch crashed the dev client twice before the fix; the third launch succeeded | None — but the dual-wield/block-arm-pose *visual* behavior itself wasn't manually re-tested (see §15.8) |
| `GameRenderer.extractGui()` (had a local `graphics` var, called `Gui.extractRenderState(graphics, deltaTracker)`) | Folded into `GameRenderer.extract(DeltaTracker, boolean)`, which now calls `Gui.extractRenderState(DeltaTracker, boolean, boolean)` — the `graphics` local moved *inside* that `Gui` method | `mixin/GameRendererMixin.java` (injection removed), new `mixin/client/GuiExtractRenderStateMixin.java` (injection re-created, now targeting `Gui` instead of `GameRenderer`) | **Semantic retarget** — the injection had to move to a different class entirely, since the local it captures no longer exists in `GameRenderer` | **Verified at runtime** — crashed the dev client, fixed, confirmed the third launch reaches gameplay | Floating combat text (`CombatTextRenderer.onExtractGui`) itself wasn't manually re-triggered in combat during this session |
| `Minecraft;setScreen(Screen)` (mixin `@Redirect` target for `LocalPlayer.clientSideCloseContainer`) | `Gui;setScreen(Screen)` (vanilla's own `clientSideCloseContainer()` now calls `this.minecraft.gui.setScreen(null)` directly) | `mixin/client/LocalPlayerContainerMixin.java` | Syntactic | Not manually re-tested (accessory-inventory↔inventory screen swap) | Needs a manual pass (see §15.8) |
| `SurfaceRules.isBiome(ResourceKey<Biome>...)` | `SurfaceRules.isBiome(HolderGetter<Biome>, ResourceKey<Biome>...)` | `TotalityOverworldSurfaceRules.java` | Semantic (new required parameter) — resolved via `provider.lookupOrThrow(Registries.BIOME)`, already in scope at the call site | Verified: datagen regenerated `overworld.json` with the Flooded Forest condition block intact | None |
| `SurfaceRules.noiseCondition(key, threshold)` | Split into `noiseCondition2d`/`noiseCondition3d`; confirmed 2D is correct by finding vanilla's own analogous Swamp-puddle rule (`SurfaceRules.noiseCondition2d(Noises.SWAMP, 0.0)`) uses the same pattern | `TotalityOverworldSurfaceRules.java` | Syntactic once the correct overload was identified | Verified via datagen | None |
| `OverworldBiomeBuilder.addBiomes(...)` point count | 7593 → 7594 (vanilla added a new **Sulfur Caves** underground biome — one new `addUndergroundBiome(..., Biomes.SULFUR_CAVES)` call, confirmed by diffing decompiled `OverworldBiomeBuilder` between 26.1.2 and 26.2) | `TotalityOverworldClimate.java` (`EXPECTED_VANILLA_POINT_COUNT`, `EXPECTED_VANILLA_FINGERPRINT` constants bumped) | **Genuine vanilla behavior change**, not a migration bug — the guard fired exactly as designed | Verified: datagen succeeded after the constants were corrected using the real captured fingerprint (not guessed) | Flooded Forest's own placement is unaffected (Sulfur Caves is an underground, non-Swamp biome, so `remapSwampSubrangeToFloodedForest` passes it through untouched) |
| `PhoneItem.use()` constructing two different `Screen` subtypes in a ternary | Moved into the existing client-only `PhoneScreens` helper (`openFromHand`) | `item/energy/PhoneItem.java`, `screen/phone/PhoneScreens.java` | **Latent pre-existing bug, not a 26.2 API change** — a ternary between two `Screen` subtypes inside a class loaded on both sides (`Item`) forces the JVM verifier to resolve the client-only `Screen` class merely by loading the class, crashing a dedicated server even though the branch is `isClientSide()`-guarded | **Verified at runtime** — this crashed the dedicated server on first launch; fixed, confirmed dedicated server reaches `Done` after the fix | Confirmed no other Item/Block class in the codebase has this pattern (grepped for `new *Screen(` construction outside `client`/`screen` packages) |

## 15.4 Build results

| Stage | Error count | Result |
|---|---|---|
| Baseline (`TOTALITY_26.2_FIRST_COMPILE.log`, pre-existing) | 100 (javac display cap) | FAILED |
| Reproduction (`TOTALITY_26.2_REPRO_COMPILE.log`) | 100 (identical) | FAILED — confirms reproducibility |
| After screen/HUD/tags/mappings/datagen groups (`COMPILE_GROUP1`) | 39 (new ones revealed past the 100-cap: `screen/classes/*`, `worldgen/ModBiomes.java`, `worldgen/TotalityOverworldSurfaceRules.java`) | FAILED |
| After worldgen + remaining screen-API stragglers (`COMPILE_GROUP2`) | 26 (all in the 3 rendering files) | FAILED |
| After GPU rendering pipeline rewrite (`COMPILE_GROUP3`) | 0 | **BUILD SUCCESSFUL** |
| `gradlew.bat clean build` (`CLEAN_BUILD.log`) | 0 | **BUILD SUCCESSFUL** — jar assembled, no Mixin/AP errors, no remap failures |
| `runDatagen` (`DATAGEN_FINAL.log`) | 0 | **BUILD SUCCESSFUL** — all 9 providers ran, 349 files written |

Warnings remaining: `Note: Some input files use or override a deprecated API` (pre-existing, not investigated — out of scope for this migration), Gradle 10-incompatibility deprecation notice (Loom-internal, not Totality code).

## 15.5 Runtime results

| Test | Status | Notes |
|---|---|---|
| Dedicated-server startup | **Passed** (after one fix) | First attempt crashed (`PhoneItem` client-classloading bug, §15.3). Second attempt: reached `Done (2.382s)!`, fresh world generated, all registries/reload-listeners initialized, 4 of 5 in-game self-test suites passed (`ItemValueVerification` 19/19, `MerchantSellVerification` 33/33, `ProvisionerVerification` 67/67, `TradingScreenVerification` 14/14). `ProvisionerEntityBackedSmokeTest` failed 3/4 checks on a **truly empty** server (no connected player) — see §15.6, this is not a migration regression. |
| Development-client startup | **Passed** (after two fixes) | First two attempts crashed on Mixin target mismatches (`ItemInHandRenderer`, `GameRenderer` — §15.3). Third attempt: reached the title screen, joined the existing dev world, ticked normally, rendered chunks/entities, and `ProvisionerEntityBackedSmokeTest` passed 4/4 with a real connected player — confirming the server-side "failure" above was an environment condition, not a bug. |
| Fresh-world smoke test | **Partially verified** | World generation, join, HUD rendering, and GUI primitives (dialogue/quest text, panel borders) were observed working during the bounded client run. Deep interactive checks (opening every screen, casting spells, Heat Vision, energy overlays, rest, dialogue choices, BUY/SELL) were **not driven** — no input-injection mechanism was available in this environment to click through screens or move the player. See the manual checklist (§15.8). |
| Copied-old-save test | **Not tested — no fixture available** | The only save present (`run/saves/New Testing World`) was found to already be a 26.2-native world (its `level.dat_old` backup already records version `26.2`), meaning no genuine untouched 26.1.2 save exists in this environment. Confirmed with Stefan: no separate 26.1.2 backup exists. This gate could not be exercised and is not claimed as passing. |
| Mixin validation | **Partially verified** | 2 of ~28 Mixins had broken targets from vanilla renames, found and fixed by actually launching the client (compilation cannot catch Mixin target-string breakage). All Mixins now apply cleanly (client and server both reach a running state with no Mixin errors). Behavioral correctness of each Mixin's effect (dual-wield arm pose, block-arm pose, accessory-inventory screen-swap flash suppression, floating combat text) was **not individually re-verified in gameplay** — see §15.8. |
| Rendering validation | **Partially verified** | `TotalityGuiRenderer` (borders/panels/HUD primitives) confirmed rendering correctly during the client run (dialogue/quest UI visible and legible). `HeatVisionBeamRenderer` and `SidedOverlayRenderer` compile and follow the correct new GPU-pipeline pattern (confirmed against vanilla `DebugCrosshairRenderer`/`CloudRenderer` source), but neither Heat Vision nor an energy side overlay was actually triggered during the bounded playtest, so their visuals are **not confirmed**. |
| Networking validation | **Passed (indirectly)** | All client↔server payload handlers that changed (screen-opening, dialogue, trading, quests, banking) compile against the new screen API and were exercised implicitly by the dev-client join sequence (quest state synced, dialogue manager loaded). BUY/SELL, rest start/cancel, and ability/spell activation packets were not individually driven. |

## 15.6 Behavior changes

Unavoidable/intentional differences from 26.1.2, all confirmed via decompiled-source diffing (not guessed):

1. **Vanilla loot-table/recipe JSON no longer serializes default values** (`bonus_rolls: 0.0`, `add: false`, `category: "misc"` are now omitted instead of written explicitly). Purely a codec/serialization format change; loaded values are identical. Affects the 17 regenerated loot tables and 4 recipes.
2. **Vanilla `biome_is` condition now serializes as a bare string instead of a single-element array** (`"biome_is": "minecraft:swamp"` instead of `"biome_is": ["minecraft:swamp"]`), and vanilla's noise-router JSON gained a new `cache_once` wrapper node type. Both are vanilla codec changes in `overworld.json`, unrelated to Totality's own surface-rule logic (which is unchanged and still present in the diff).
3. **Vanilla added a new Sulfur Caves underground biome** in `OverworldBiomeBuilder`, changing its real point count from 7593 to 7594. `TotalityOverworldClimate`'s self-verification guard (designed exactly for this scenario) caught it; the guard's expected constants were updated to the real, captured values — not guessed. Sulfur Caves is not a Swamp point, so Flooded Forest's own placement logic is unaffected.
4. **`RenderPass.drawIndexed`'s argument order changed** from `(firstIndex, baseVertex, indexCount, instanceCount)` to `(indexCount, instanceCount, firstIndex, baseVertex, firstInstance)` — a real semantic change in the rendering pipeline, not just a rename. Both custom renderers were updated to match.

No other intentional behavior changes were introduced. Everywhere a 26.2 API required a different call shape, the smallest change that preserved the original semantics was used (documented per-row in §15.3).

## 15.7 Deferred issues

Explicitly out of scope for this migration, per the task's exclusion list — none of these were touched:

- Generic Player Resource API completion
- Unlock/Access/Entitlement API implementation
- Spell API redesign
- Class/origin completion, multiclass redesign
- Equipment death-policy redesign, Soulbound implementation
- Merchant runtime persistence redesign (see the `ProvisionerEntityBackedSmokeTest` note below)
- Provisioner Phase 4 GUI redesign
- Fluid API redesign, Thirst, Farming/Cooking, Medicine/Disease, Alchemy ecosystem redesign
- Enchantment/Smithing architecture
- Broad networking hardening, component schema migration architecture
- Broad performance optimization
- Future Fluid API, future system redesigns, performance profiling

**Findings surfaced during this migration that belong to separate, later work** (not fixed here, since fixing them would exceed migration scope):

- **Pre-existing "deprecated API" compiler notes** (`Note: Some input files use or override a deprecated API`) were not enumerated or investigated — they predate this migration and aren't new.
- **`ProvisionerEntityBackedSmokeTest` on a player-less dedicated server**: appears to require a connected player/session context to resolve the freshly-spawned NPC via the "real production entity lookup" — passed cleanly once a real player joined. Worth a look if Stefan ever runs this self-test suite on an empty dedicated server as part of CI, but it is not a 26.2 regression (confirmed: same test, same code, passes with a player present).

## 15.8 Manual checklist for Stefan

Automated/Claude-run testing covered compilation, build, datagen, dedicated-server startup, and a bounded (~60s, non-interactive) client launch. It could **not** drive mouse/keyboard input into the game window, so everything below needs a real, short manual pass:

**Screens & HUD**
- [ ] Open and close: Character screen, Phone (equip slot + held-item use), Grimoire (radial + full), Ability radial, Spell radial, Accessory inventory (and confirm it returns to the vanilla inventory screen correctly, not a flash of the wrong screen)
- [ ] Toggle F1 (hide GUI) — confirm the Totality HUD (resource bars, rest HUD, quest tracker, mob health bars, notifications) disappears and reappears correctly
- [ ] Confirm keybinds (Z/X/C/V) are correctly blocked while any Totality screen is open

**Dialogue & economy**
- [ ] Talk to an NPC, pick a dialogue choice, confirm dice-roll UI still works
- [ ] Open Provisioner trading, run one BUY and one SELL, confirm Credits update on both sides
- [ ] Open the Bank Teller screen, confirm deposit/withdraw still works

**Rest**
- [ ] Start a Rest session, cancel it, start a Short Rest and let it complete — confirm no time-desync or crash

**Spells & abilities**
- [ ] Cast one cantrip (e.g. Eldritch Blast) and one leveled spell, confirm slot consumption
- [ ] Activate Heat Vision — **confirm the beam is actually visible**, correctly positioned/oriented, and cleans up on release (this renderer was rewritten for the new GPU pipeline and was not visually confirmed this session)
- [ ] Veinminer-mine a vein of coal, iron, redstone, lapis, diamond, and emerald ore — confirm all still trigger correctly (the underlying tag lookup changed, though output data is confirmed identical)
- [ ] Point Heat Vision at logs/planks/wool — confirm they still ignite (`LOGS_THAT_BURN` tag)

**Equipment**
- [ ] Confirm dual-wielding (two one-handed weapons) still shows an independent offhand swing animation, and blocking with the offhand shows the correct blocking arm pose (both Mixins were retargeted this session)

**Energy/fluids**
- [ ] Place a fluid tank and an Electric Furnace, open their screens, view side configuration
- [ ] **Confirm the energy side-overlay actually renders** on a configured machine face (this renderer was rewritten for the new GPU pipeline and was not visually confirmed this session)

**World**
- [ ] Generate/visit a fresh Flooded Forest biome, confirm water coverage still looks right
- [ ] Punch a Provisioner NPC's rune-effect chain if reachable (Harvest + Lightning rune effects both changed a vanilla method call)

## 15.9 Review bundle

See `Context/Audit/Review Bundles/totality-26.2-migration-review.zip`, containing this report, the original and final compile logs, the clean-build log, both server-startup logs, all three client-startup logs (2 crashes + 1 success), all three datagen logs, the changed-file list, and this API table (embedded in the report). Gradle caches, `build/`, `run/` worlds, and `/Inspiration Mods` are excluded.
