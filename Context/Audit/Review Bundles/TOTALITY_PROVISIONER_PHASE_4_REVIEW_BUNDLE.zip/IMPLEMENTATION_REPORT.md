# TOTALITY PROVISIONER / ECONOMY PHASE 4 — IMPLEMENTATION REPORT

**Branch:** `feature/provisioner-phase-4`
**Baseline:** `d8c194aa04cf72bd0706023d682dc7f23524126b`
**Final HEAD:** `a77ed12c9188d7c98029d1f048c1ea7e94267cb5`
**Phase 4 commit count:** 6

This report is self-contained for the entire Phase 4 vertical slice — the
Provisioner merchant NPC, its BUY/SELL economy, the native Trading Screen
GUI, and the combat-input/HUD corrections found and fixed alongside it —
not only the final correction commit.

---

## 1. Purpose and scope

Phase 4 delivers the first playable Provisioner merchant: a persistent,
per-entity-state NPC with a randomized assortment, real Credits-backed
BUY and SELL economy, and a native-rendered Trading Screen GUI matching
Stefan's reference designs. It also closes out a set of combat-input and
HUD regressions (Power Attack targeting, Ability/Spell/Grimoire/Block key
handling, notification and flash timing) discovered during Phase 4's own
manual testing and the Minecraft 26.2 migration that preceded it.

Explicitly **out of scope** for Phase 4 and not implemented: restocking,
Credit replenishment, BUYBACK, investment, disposal/donation/gifting,
quote-token/stack-fingerprint hardening, dialogue-check XP, Quest skill
XP, map/compass/waypoints, and any redesign of Trading Screen layout
beyond what is documented below.

---

## 2. Phase 4 commits (chronological)

| # | Commit | Subject |
|---|--------|---------|
| 1 | `efd89f227f5b0d084c0da5c16936fad664b45e60` | Phase 4 checkpoint: Trading Screen redesign + Provisioner textures (pre-correction-pass) |
| 2 | `cb27327d1c5e1cfc130921ab00dac026ff3482f7` | Fix Provisioner, input, and HUD timing issues |
| 3 | `00db16a05321e3ef9a45d951be0c673126a399cd` | Refine Trading Screen GUI to match reference design |
| 4 | `c7960a6985477e66f078950c76b0847c7183307f` | Finalize Provisioner Phase 4 corrections |
| 5 | `6e62aeed4c548115edb77f64d2fdf59df7d0402a` | Fix final Phase 4 review findings |
| 6 | `a77ed12c9188d7c98029d1f048c1ea7e94267cb5` | Finalize Provisioner Phase 4 documentation |

Five Minecraft 26.2 migration commits interleaved between commit 1 and
commit 2 (`953a677`, `46a3591`, `c673238`, `a4503f9`, `0d2612b`) are
**excluded** from Phase 4 evidence — they are migration/infrastructure
work, documented separately in `documents/TOTALITY_26.2_MIGRATION_REPORT.md`
and `documents/TOTALITY_26.2_MANUAL_SMOKE_TEST_RESULTS.md`.

Full patch series: `PHASE_4.patch` (six `git format-patch` entries, one
per commit above, in chronological order). Full metadata and diffstat
per commit: `COMMITS.txt`.

---

## 3. Provisioner NPC — identity, textures, persistence

- New generic `ProvisionerNpcEntity`/profile with male/female texture
  variants (`ProvisionerNpcRenderer`, `ProvisionerNpcRenderState`,
  `assets/totality/textures/entity/npc/provisioner/{male,female}.png`).
- **Persistent per-entity Credits, stock, and assortment** — each
  Provisioner's `currentCredits`, stock list, and randomized assortment
  roll are saved/loaded per-entity (`MerchantRuntime`), not shared
  global state. Malformed persisted data is sanitized defensively:
  negative persisted Credits are clamped to 0, corrupt persisted stock
  (empty item template or duplicate entries) discards the entire list
  rather than partially recovering it, and assortment definitions are
  immutable once loaded.
- Assortment weight overflow and excessive roll counts are guarded
  against; a missing/invalid assortment pool retries silently on a
  throttle rather than failing hard or spamming.
- **Provisioner no-despawn behavior**: Provisioners are exempt from
  natural despawning, matching persistent-merchant expectations (a
  Provisioner that vanishes because no player was nearby would silently
  destroy its persisted Credits/stock).
- Live-entity re-resolution for in-flight trade sessions confirmed
  unchanged/not regressed across this work — a trade session revalidates
  against the real entity, never a stale reference.

---

## 4. BUY and SELL economy

### 4a. BUY
- BUY quantity is explicitly validated (0/negative/>100 rejected).
- SOLD OUT is an **explicit, presented state** — sold-out catalog
  entries are dimmed but remain selectable (view-only), not hidden or
  silently disabled, so the player can still see what a Provisioner
  once stocked.
- BUY overflow, negative-price, and negative-payment defenses are in
  place at the transaction boundary.

### 4b. SELL
- **Accountless physical-Credit payout**: a player without a linked
  economy account is paid in physical Credit items placed directly into
  their inventory.
- **Account-holder Wallet payout**: a player with a linked account is
  paid directly into their `WalletComponent` balance instead.
- **Full value / payable amount / forfeited value**: every SELL quote
  (`MerchantSellQuoteView`) computes and exposes all three — the
  goods' true total value, what the merchant can actually afford right
  now (`payableAmount`), and the difference the player would forfeit by
  accepting a reduced payout (`forfeitedValue`).
- **Underfunded merchant confirmation**: if a merchant cannot afford the
  full value, SELL is not silently clamped — the quote is flagged
  `requiresConfirmation()` and the client must show the reduced-payout
  popup and obtain explicit player confirmation before the server will
  execute a reduced sale.
- **Zero-Credit merchant behavior**: a merchant with `currentCredits <= 0`
  rejects SELL outright — there is no confirmation path for a merchant
  that can pay nothing.
- **Structured SELL rejection reasons** (`SellRejectionReason` enum:
  `NONE`, `NOT_ACCEPTED`, `NO_VALUE`, `MERCHANT_ZERO_CREDITS`,
  `INVALID_QUANTITY`, `OVERFLOW`, `GENERIC`) replace prose/string
  matching entirely — `SellResult.quoteReason` and
  `TradeRejectionKeys.forSell` switch on the real enum, never inspect
  English text. Rejected items produce clear, structured player-facing
  feedback in the Trading Screen rather than a generic failure.
- **Stale-confirmation protection**: a confirmed reduced-payout SELL is
  re-validated against the CURRENT quote, never trusted as authoritative
  from the client. It is rejected as `STALE_CONFIRMATION` if the quote
  no longer requires confirmation (the merchant became fully funded or
  overfunded before the server processed the confirmation) OR if the
  confirmed total value or payable amount differ from the current
  quote's — covering both a merchant getting WORSE and a merchant
  getting BETTER while a confirmation is in flight. Rejection is fully
  atomic: no items removed, no Wallet/physical-Credit/merchant-Credit
  mutation, no partial transaction. No quote-token or stack-fingerprint
  protocol was introduced — this is a pure re-validation of existing
  quote fields against existing request fields; a token/fingerprint
  protocol remains a possible **future** hardening idea only, not
  scheduled work.
- **BUYBACK remains unavailable** — explicitly deferred, not
  implemented this phase; the Trading Screen's mode surface reserves
  space for it but no BUYBACK transaction path exists.

### 4c. Networking
All additive/trimmed, not a new protocol: `SellItemPayload` gained
`confirmedReducedPayout`/`confirmedTotalValue`/`confirmedPayableAmount`;
`SellQuoteResultPayload` dropped the no-longer-meaningful
`maxQuantityByMerchant`; `ShowShopStatePayload`/`RequestSellQuotePayload`
are unchanged. Both changed payloads have direct `STREAM_CODEC`
round-trip verification.

---

## 5. Trading Screen GUI

- **Native-rendered Trading Screen** (`screen/shop/TradingScreen.java`) —
  a full redesign matching Stefan's reference mockups
  (`references/trade_screen_buy_v1.png`, `trade_screen_buy_v2.png`,
  `trade_screen_sell_v1.png`, `trade_screen_sell_v2.png`), built on
  `GuiGraphics` primitives, no Tesselator pipeline dependency.
- BUY mode: catalog cards show icon, enchantment-aware naming, price,
  and stock state (including the explicit SOLD OUT presentation above).
- SELL mode: fully wired to the server-authoritative quote/confirmation
  model above — the player's own inventory drives the sell selection.
- **GUI Scale 4 layout** — root-caused and fixed: geometry (regions,
  catalog cards, inventory slots) is computed from actual screen
  dimensions with a defined minimum, not hardcoded pixel offsets that
  broke at non-default GUI scale.
- UI-state safety: no item selected shows hint text; both BUY and SELL
  modes handle the empty-selection case without a broken/blank state.
- Various resilience/interaction fixes: each a real found defect during
  manual testing (documented individually in
  `documents/TOTALITY_ECONOMY_PRICING_AND_PROVISIONER.md` Section 15d).
- Localization: all new user-visible strings added to the English lang
  file via `ModEnglishLangProvider` / generated `en_us.json`.

---

## 6. Combat input and HUD corrections

These were found and fixed during Phase 4's own manual testing pass and
the immediately preceding 26.2 migration, and are tracked in
`documents/TOTALITY_COMBAT_INPUT_AND_HUD.md`.

### 6a. Power Attack — valid-target requirement
`MinecraftAttackMixin` previously began the Power Attack hold-charge
whenever a weapon-tagged item was held, regardless of what was under the
crosshair — chopping wood could trigger a Power Attack charge and spend
Stamina. Fixed with an upstream target-validity gate
(`PowerAttackManager.isValidTarget`) before any hold-charge begins.

### 6b. Power Attack — target and attacker-legality corrections
Two related, separately-fixed defects:
- **Target validity** (mainhand and offhand): a Power Attack now
  requires a real, live, in-range target before any charge/Stamina is
  committed.
- **Attacker legality** (`PowerAttackManager.isAttackerLegal` —
  PvP-disabled, team friendly-fire, invulnerability): an offhand request
  flagged as Power Attack against an attacker-illegal target is now
  **rejected outright** before the normal-vs-power damage decision, any
  Stamina cost (ordinary or Power), any durability change, or attack
  execution — no downgrade, no accepted flash/sound/success state. This
  exactly mirrors the mainhand `PowerAttackPayload` handler's existing
  gate. The insufficient-Power-Stamina case remains a SEPARATE,
  unchanged, intentional graceful downgrade to a legal normal attack —
  it only ever runs once attacker legality has already passed.

### 6c. Ability/Spell/Grimoire modifier chords and rebindable Blocking
- Ability and Spell keys are read via their registered, rebindable
  `ModKeybinds.USE_ABILITY`/`USE_SPELL` mappings
  (`ModKeybinds.isPhysicallyDown`, immune to `KeyMapping.releaseAll()`),
  not literal GLFW key codes. Rebinding fully moves activation,
  channeled hold/release, and the Modifier+key radial-open/retain
  behavior to the new key; the old default key stops working.
- **Physical-key radial lifetime handling**: the Ability/Spell radial
  previously closed immediately after a rebind because it depended on
  `KeyMapping.isDown()`, which `Gui.setScreen(Screen)` unconditionally
  zeroes on every screen open. Fixed by driving radial retention off the
  same `isPhysicallyDown` raw-GLFW-state read used for activation, so a
  held Modifier+key chord keeps a radial open across the screen-open
  transition regardless of rebinding.
- **Grimoire modifier chord**: Grimoire moved onto the same
  Modifier+key chord model as Ability/Spell, reusing the existing
  `ModKeybinds.OPEN_GRIMOIRE` mapping (no second mapping created). The
  Grimoire key alone still opens the normal Grimoire screen; Modifier +
  the bound Grimoire key opens and retains the Grimoire radial without
  also opening the normal screen. Grimoire rebinding works. The default
  Grimoire radial chord is Left Alt (Radial Modifier default) + C
  (Grimoire's own default key).
- **Rebindable Blocking**: Block now reads
  `ModKeybinds.isPhysicallyDown(ModKeybinds.BLOCK)` — the registered,
  rebindable mapping — instead of a raw `GLFW_KEY_V` poll. Default
  remains V; rebinding moves ALL blocking behavior (start, re-apply-
  while-held, stop) to the new key; V stops blocking once rebound away
  from it. Mainhand/offhand blocking, the block animation, packet flow,
  and Stamina cost are unaffected. V remains exclusively the default
  Blocking key and is not used by the Grimoire in any form.

### 6d. Notification duration and Power Attack flash — tick timing
Two instances of the same root-cause bug class (authoritative-lifetime
state read from the wrong clock after the 26.2 migration changed tick
sourcing): notification duration and the Power Attack screen-corner
flash both computed their remaining lifetime against a tick counter that
no longer advanced the way the pre-migration code assumed, causing
notifications/flashes to persist far longer (or vanish immediately) than
intended. Both fixed by anchoring lifetime to the correct authoritative
tick source; covered by `NotificationTimingVerification` (9 checks) and
`PowerAttackFlashVerification` (7 checks).

---

## 7. Verification — 213/213 across 11 suites

| Suite | Checks |
|---|---|
| NotificationTimingVerification | 9 |
| PowerAttackFlashVerification | 7 |
| ProvisionerRendererVerification | 4 |
| KeybindVerification | 13 |
| ItemValueVerification | 19 |
| MerchantSellVerification | 47 |
| ProvisionerVerification | 71 |
| TradingScreenVerification | 22 |
| PowerAttackVerification | 12 |
| ProvisionerEntityBackedSmokeTest | 4 |
| OffhandAttackVerification | 5 |
| **Total** | **213** |

**213/213 checks passed, zero failures**, confirmed via a clean
`gradlew runClient --args="--quickPlaySingleplayer \"New Testing World\""`
boot against the final Phase 4 HEAD. `gradlew compileJava` and
`gradlew build`: **SUCCESSFUL**.

---

## 8. Manual testing evidence

### 8a. Manually confirmed (Stefan, 2026-07-16 – 2026-07-17)
- Power Attack valid-target requirement (chopping wood no longer
  triggers Power Attack or spends Stamina; a valid combat target still
  permits it normally).
- Radial Modifier chord input model.
- Ability/Spell/Grimoire radial rebind checklist in full: rebound
  Ability/Spell keys activate/cast normally, old Z/X stop working after
  rebinding, Modifier + the rebound key opens and retains each radial,
  channeled-Ability hold/release follows the rebound key, the Grimoire
  key alone opens the normal screen, Modifier + Grimoire opens and
  retains its radial, Grimoire rebinding works, default Grimoire chord
  is Left Alt + C.
- Block: default V blocking, rebinding Block to a new key, the old V
  binding stops blocking after rebinding, holding/releasing the rebound
  key correctly starts/stops blocking, resetting Block back to default
  V.
- Grimoire input remains unaffected by Block changes.
- Ordinary fully funded SELL, underfunded SELL confirmation, zero-Credit
  merchant SELL prevention, BUY regression (unchanged).
- Ordinary legal offhand attacks, legal offhand Power Attacks, and
  manually testable invalid-target behavior (no Power Attack, no
  unexpected Stamina/durability loss).

### 8b. Automated-only (not manually tested)
The underfunded-to-fully-funded stale-confirmation transition (a
confirmed reduced payout becoming stale because the merchant became
fully funded before the server processed it) is verified **only** by
automated `MerchantSellVerification` session/commit checks — reproducing
the exact race by hand is impractical in a solo GUI session, since
merchant/session locking prevents concurrently mutating merchant state
mid-confirmation from a single client. This is recorded as
**automated-only, not manually tested**, not as an unverified gap.

### 8c. Manually deferred
PvP-disabled and team-friendly-fire-protected Power Attack legality
(mainhand and offhand) remain **manually untested and deferred** —
Stefan currently has no second player/account to set up either scenario.
The server-side legality checks (`PowerAttackManager.isAttackerLegal`)
and their automated coverage (`PowerAttackVerification`,
`OffhandAttackVerification`) are preserved unchanged and fully exercised
by the automated suites. **This is explicitly not a Phase 4 blocker.**
No claim is made that these deferred multiplayer checks passed.

---

## 9. Deferred / explicitly out-of-scope work

Restocking, Credit replenishment, BUYBACK, investment, disposal/
donation/gifting, quote-token/stack-fingerprint hardening, dialogue-check
XP, Quest skill XP, Codex/Relationship-gated trades, map/compass/
waypoints, and any further Trading Screen layout redesign beyond what is
documented in Section 5. PvP-disabled and team-friendly-fire manual
testing (Section 8c) is the one remaining manual-test gap and is not a
blocker.
